"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const paystack_client_1 = __importDefault(require("../../../../providers/paystack/services/paystack-client"));
const currency_1 = require("../../../../providers/paystack/utils/currency");
async function GET(req, res) {
    try {
        const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        let dynamicSecret = "";
        let storeCurrency = "KES";
        try {
            const { data: stores } = await query.graph({
                entity: "store",
                fields: ["metadata", "default_currency_code", "supported_currencies.*"]
            }).catch(() => ({ data: [] }));
            if (stores?.[0]) {
                const storeObj = stores[0];
                if (storeObj.metadata?.paystack_secret_key) {
                    dynamicSecret = storeObj.metadata.paystack_secret_key;
                }
                const defaultCurr = storeObj.supported_currencies?.find((c) => c.is_default)?.currency_code ||
                    storeObj.supported_currencies?.[0]?.currency_code ||
                    storeObj.default_currency_code;
                if (defaultCurr) {
                    storeCurrency = defaultCurr.toUpperCase();
                }
            }
        }
        catch { }
        if (!dynamicSecret) {
            try {
                const storeService = req.scope.resolve(utils_1.Modules.STORE);
                if (storeService && typeof storeService.listStores === "function") {
                    const stores = await storeService.listStores({}, { take: 1 });
                    if (stores?.[0]) {
                        const storeObj = stores[0];
                        if (storeObj.metadata?.paystack_secret_key) {
                            dynamicSecret = storeObj.metadata.paystack_secret_key;
                        }
                        const defaultCurr = storeObj.supported_currencies?.find((c) => c.is_default)?.currency_code ||
                            storeObj.supported_currencies?.[0]?.currency_code ||
                            storeObj.default_currency_code;
                        if (defaultCurr) {
                            storeCurrency = defaultCurr.toUpperCase();
                        }
                    }
                }
            }
            catch { }
        }
        const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
        if (!secretKey) {
            return res.status(200).json({
                success: false,
                message: "Paystack secret key is not configured. Please set PAYSTACK_SECRET_KEY in environment or Settings.",
                data: {
                    balance: null,
                    balanceError: "Secret key not configured",
                    configured: false,
                },
            });
        }
        const client = new paystack_client_1.default(secretKey);
        const balanceRes = await client.balance.get();
        if (!balanceRes || !balanceRes.status) {
            const errorMsg = balanceRes?.message || "Failed to retrieve balance from Paystack";
            return res.status(400).json({
                success: false,
                message: errorMsg,
                data: {
                    balance: null,
                    balanceError: errorMsg,
                    configured: true,
                },
            });
        }
        const normalizedBalances = (0, currency_1.normalizePaystackBalances)(balanceRes.data, storeCurrency);
        return res.status(200).json({
            success: true,
            message: "Paystack balances retrieved successfully",
            data: {
                balance: normalizedBalances,
                balanceError: null,
                configured: true,
            },
        });
    }
    catch (error) {
        const errorMsg = error?.response?.data?.message || error.message || "Failed to fetch Paystack balance";
        console.error("[Paystack Balance Route Error]:", error);
        return res.status(500).json({
            success: false,
            message: errorMsg,
            data: {
                balance: null,
                balanceError: errorMsg,
                configured: true,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3BheXN0YWNrL2JhbGFuY2Uvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxrQkEyR0M7QUEvR0QscURBQStFO0FBQy9FLDhHQUFxRjtBQUNyRiw0RUFBb0g7QUFFN0csS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFakUsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLElBQUksYUFBYSxHQUFHLEtBQUssQ0FBQztRQUUxQixJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDekMsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFLENBQUMsVUFBVSxFQUFFLHVCQUF1QixFQUFFLHdCQUF3QixDQUFDO2FBQ3hFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFL0IsSUFBSSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNoQixNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFRLENBQUM7Z0JBQ2xDLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsRUFBRSxDQUFDO29CQUMzQyxhQUFhLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxtQkFBNkIsQ0FBQztnQkFDbEUsQ0FBQztnQkFDRCxNQUFNLFdBQVcsR0FDZixRQUFRLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsYUFBYTtvQkFDNUUsUUFBUSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsYUFBYTtvQkFDakQsUUFBUSxDQUFDLHFCQUFxQixDQUFDO2dCQUNqQyxJQUFJLFdBQVcsRUFBRSxDQUFDO29CQUNoQixhQUFhLEdBQUcsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM1QyxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO1FBRVYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25CLElBQUksQ0FBQztnQkFDSCxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3RELElBQUksWUFBWSxJQUFJLE9BQU8sWUFBWSxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUUsQ0FBQztvQkFDbEUsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUM5RCxJQUFJLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7d0JBQ2hCLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQVEsQ0FBQzt3QkFDbEMsSUFBSSxRQUFRLENBQUMsUUFBUSxFQUFFLG1CQUFtQixFQUFFLENBQUM7NEJBQzNDLGFBQWEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLG1CQUE2QixDQUFDO3dCQUNsRSxDQUFDO3dCQUNELE1BQU0sV0FBVyxHQUNmLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxhQUFhOzRCQUM1RSxRQUFRLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhOzRCQUNqRCxRQUFRLENBQUMscUJBQXFCLENBQUM7d0JBQ2pDLElBQUksV0FBVyxFQUFFLENBQUM7NEJBQ2hCLGFBQWEsR0FBRyxXQUFXLENBQUMsV0FBVyxFQUFFLENBQUM7d0JBQzVDLENBQUM7b0JBQ0gsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7UUFDWixDQUFDO1FBRUQsTUFBTSxTQUFTLEdBQUcsSUFBQSxtQ0FBd0IsRUFBQyxhQUFhLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsS0FBSztnQkFDZCxPQUFPLEVBQUUsbUdBQW1HO2dCQUM1RyxJQUFJLEVBQUU7b0JBQ0osT0FBTyxFQUFFLElBQUk7b0JBQ2IsWUFBWSxFQUFFLDJCQUEyQjtvQkFDekMsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2FBQ0YsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLElBQUkseUJBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3QyxNQUFNLFVBQVUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUM7UUFFOUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN0QyxNQUFNLFFBQVEsR0FBRyxVQUFVLEVBQUUsT0FBTyxJQUFJLDBDQUEwQyxDQUFDO1lBQ25GLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxLQUFLO2dCQUNkLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixJQUFJLEVBQUU7b0JBQ0osT0FBTyxFQUFFLElBQUk7b0JBQ2IsWUFBWSxFQUFFLFFBQVE7b0JBQ3RCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjthQUNGLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCxNQUFNLGtCQUFrQixHQUFHLElBQUEsb0NBQXlCLEVBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztRQUVyRixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxJQUFJO1lBQ2IsT0FBTyxFQUFFLDBDQUEwQztZQUNuRCxJQUFJLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLGtCQUFrQjtnQkFDM0IsWUFBWSxFQUFFLElBQUk7Z0JBQ2xCLFVBQVUsRUFBRSxJQUFJO2FBQ2pCO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksa0NBQWtDLENBQUM7UUFDdkcsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4RCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxLQUFLO1lBQ2QsT0FBTyxFQUFFLFFBQVE7WUFDakIsSUFBSSxFQUFFO2dCQUNKLE9BQU8sRUFBRSxJQUFJO2dCQUNiLFlBQVksRUFBRSxRQUFRO2dCQUN0QixVQUFVLEVBQUUsSUFBSTthQUNqQjtTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7QUFDSCxDQUFDIn0=