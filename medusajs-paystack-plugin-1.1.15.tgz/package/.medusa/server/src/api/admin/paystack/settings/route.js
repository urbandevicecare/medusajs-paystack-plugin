"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
async function GET(req, res) {
    try {
        const storeService = req.scope.resolve(utils_1.Modules.STORE);
        const stores = await storeService.listStores({}, { take: 1 });
        if (!stores || stores.length === 0) {
            return res.status(404).json({ message: "Store not found" });
        }
        const store = stores[0];
        const metadata = store.metadata || {};
        res.status(200).json({
            success: true,
            data: {
                companyName: metadata.paystack_company_name || process.env.STORE_NAME || "Urban Device Care",
                storefrontUrl: metadata.paystack_storefront_url || process.env.STOREFRONT_URL || "http://localhost:5173",
                secretKey: metadata.paystack_secret_key || "", // Mask this or return empty if preferring security, but returning it so it populates the field
            }
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message || "Failed to load settings" });
    }
}
async function POST(req, res) {
    try {
        const storeService = req.scope.resolve(utils_1.Modules.STORE);
        const stores = await storeService.listStores({}, { take: 1 });
        if (!stores || stores.length === 0) {
            return res.status(404).json({ message: "Store not found" });
        }
        const store = stores[0];
        const { companyName, storefrontUrl, secretKey } = req.body;
        const updatedMetadata = {
            ...store.metadata,
            paystack_company_name: companyName,
            paystack_storefront_url: storefrontUrl,
        };
        if (secretKey && secretKey !== "********") {
            updatedMetadata.paystack_secret_key = secretKey.trim();
        }
        else if (secretKey === "") {
            delete updatedMetadata.paystack_secret_key;
        }
        // Update store metadata
        await storeService.updateStores(store.id, {
            metadata: updatedMetadata,
        });
        res.status(200).json({
            success: true,
            data: {
                companyName,
                storefrontUrl,
                secretKey: secretKey ? "********" : "",
            }
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message || "Failed to update settings" });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3BheXN0YWNrL3NldHRpbmdzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBdUJDO0FBRUQsb0JBd0NDO0FBbkVELHFEQUFvRDtBQUU3QyxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsSUFBSSxDQUFDO1FBQ0gsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RELE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUU5RCxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbkMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUM7UUFDOUQsQ0FBQztRQUVELE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4QixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztRQUV0QyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsSUFBSTtZQUNiLElBQUksRUFBRTtnQkFDSixXQUFXLEVBQUUsUUFBUSxDQUFDLHFCQUFxQixJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLG1CQUFtQjtnQkFDNUYsYUFBYSxFQUFFLFFBQVEsQ0FBQyx1QkFBdUIsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsSUFBSSx1QkFBdUI7Z0JBQ3hHLFNBQVMsRUFBRSxRQUFRLENBQUMsbUJBQW1CLElBQUksRUFBRSxFQUFFLCtGQUErRjthQUMvSTtTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPLElBQUkseUJBQXlCLEVBQUUsQ0FBQyxDQUFDO0lBQ2hGLENBQUM7QUFDSCxDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLElBQUksQ0FBQztRQUNILE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0RCxNQUFNLE1BQU0sR0FBRyxNQUFNLFlBQVksQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFOUQsSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ25DLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1FBQzlELENBQUM7UUFFRCxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEIsTUFBTSxFQUFFLFdBQVcsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQVcsQ0FBQztRQUVsRSxNQUFNLGVBQWUsR0FBd0I7WUFDM0MsR0FBRyxLQUFLLENBQUMsUUFBUTtZQUNqQixxQkFBcUIsRUFBRSxXQUFXO1lBQ2xDLHVCQUF1QixFQUFFLGFBQWE7U0FDdkMsQ0FBQztRQUVGLElBQUksU0FBUyxJQUFJLFNBQVMsS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUMxQyxlQUFlLENBQUMsbUJBQW1CLEdBQUcsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3pELENBQUM7YUFBTSxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUM1QixPQUFPLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQztRQUM3QyxDQUFDO1FBRUQsd0JBQXdCO1FBQ3hCLE1BQU0sWUFBWSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFO1lBQ3hDLFFBQVEsRUFBRSxlQUFlO1NBQzFCLENBQUMsQ0FBQztRQUVILEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxJQUFJO1lBQ2IsSUFBSSxFQUFFO2dCQUNKLFdBQVc7Z0JBQ1gsYUFBYTtnQkFDYixTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUU7YUFDdkM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLDJCQUEyQixFQUFFLENBQUMsQ0FBQztJQUNsRixDQUFDO0FBQ0gsQ0FBQyJ9