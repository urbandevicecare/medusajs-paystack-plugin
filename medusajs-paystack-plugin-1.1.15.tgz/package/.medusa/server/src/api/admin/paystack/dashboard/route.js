"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const paystack_client_1 = __importDefault(require("../../../../providers/paystack/services/paystack-client"));
const currency_1 = require("../../../../providers/paystack/utils/currency");
const reconcile_payment_1 = require("../../../../providers/paystack/utils/reconcile-payment");
async function GET(req, res) {
    try {
        const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        // Resolve store metadata and currency
        let dynamicSecret = "";
        let storeCurrency = "KES";
        try {
            const { data: stores } = await query.graph({
                entity: "store",
                fields: ["metadata", "default_currency_code", "supported_currencies.*"]
            }).catch(() => ({ data: [] }));
            if (stores?.[0]) {
                const storeObj = stores[0];
                if (storeObj.metadata?.paystack_secret_key) {
                    dynamicSecret = storeObj.metadata.paystack_secret_key;
                }
                const defaultCurr = storeObj.supported_currencies?.find((c) => c.is_default)?.currency_code ||
                    storeObj.supported_currencies?.[0]?.currency_code ||
                    storeObj.default_currency_code;
                if (defaultCurr) {
                    storeCurrency = defaultCurr.toUpperCase();
                }
            }
        }
        catch { }
        if (!dynamicSecret) {
            try {
                const storeService = req.scope.resolve(utils_1.Modules.STORE);
                if (storeService && typeof storeService.listStores === "function") {
                    const stores = await storeService.listStores({}, { take: 1 });
                    if (stores?.[0]) {
                        const storeObj = stores[0];
                        if (storeObj.metadata?.paystack_secret_key) {
                            dynamicSecret = storeObj.metadata.paystack_secret_key;
                        }
                        const defaultCurr = storeObj.supported_currencies?.find((c) => c.is_default)?.currency_code ||
                            storeObj.supported_currencies?.[0]?.currency_code ||
                            storeObj.default_currency_code;
                        if (defaultCurr) {
                            storeCurrency = defaultCurr.toUpperCase();
                        }
                    }
                }
            }
            catch { }
        }
        const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
        // 1. Fetch internal Medusa payments handled by paystack
        const { data: payments } = await query.graph({
            entity: "payment",
            fields: [
                "id",
                "amount",
                "currency_code",
                "created_at",
                "data",
                "payment_collection.order.id",
                "payment_collection.order.display_id",
                "payment_collection.order.email",
            ],
            filters: {
                provider_id: { $like: "%paystack%" }
            }
        }).catch(() => ({ data: [] }));
        // 2. Fetch Medusa orders to cross-reference with Paystack transactions
        const { data: orders } = await query.graph({
            entity: "order",
            fields: [
                "id",
                "display_id",
                "email",
                "total",
                "currency_code",
                "created_at",
                "metadata",
                "payment_collections.id",
                "payment_collections.status",
                "payment_collections.payment_sessions.id",
                "payment_collections.payment_sessions.status",
                "payment_collections.payment_sessions.data",
                "payment_collections.payment_sessions.provider_id",
                "payment_collections.payments.id",
                "payment_collections.payments.amount",
                "payment_collections.payments.currency_code",
                "payment_collections.payments.provider_id",
            ],
        }).catch(() => ({ data: [] }));
        // Build lookup maps for fast matching
        const orderById = new Map();
        const orderByDisplayId = new Map();
        const orderByRef = new Map();
        (orders || []).forEach((order) => {
            if (order.id)
                orderById.set(order.id, order);
            if (order.display_id != null)
                orderByDisplayId.set(String(order.display_id), order);
            const metaRef = order.metadata?.paystack_reference;
            if (metaRef)
                orderByRef.set(String(metaRef), order);
            (order.payment_collections || []).forEach((col) => {
                (col.payment_sessions || []).forEach((s) => {
                    const sRef = s.data?.paystackTxRef || s.data?.reference;
                    if (sRef)
                        orderByRef.set(String(sRef), order);
                    if (s.id)
                        orderByRef.set(String(s.id), order);
                });
                (col.payments || []).forEach((p) => {
                    if (p.id)
                        orderByRef.set(String(p.id), order);
                });
            });
        });
        // Resolve repair tickets if repairshop module is installed
        let repairService = null;
        let repairTickets = [];
        try {
            repairService = req.scope.resolve("repair", { allowUnregistered: true });
            if (repairService && typeof repairService.listRepairTickets === "function") {
                repairTickets = await repairService.listRepairTickets({}, { take: 100 }).catch(() => []);
            }
        }
        catch { }
        const repairById = new Map();
        const repairByTicketNumber = new Map();
        for (const t of (repairTickets || [])) {
            if (t.id)
                repairById.set(t.id, t);
            if (t.ticket_number) {
                repairByTicketNumber.set(String(t.ticket_number).toLowerCase(), t);
            }
        }
        // 3. Query Paystack balance and live transactions
        let balance = null;
        let balanceError = null;
        let rawPaystackTransactions = [];
        let transactionsError = null;
        if (secretKey) {
            const client = new paystack_client_1.default(secretKey);
            // Fetch live Paystack balance
            try {
                const balanceRes = await client.balance.get();
                if (balanceRes && balanceRes.status && balanceRes.data) {
                    balance = (0, currency_1.normalizePaystackBalances)(balanceRes.data, storeCurrency);
                }
                else if (balanceRes && !balanceRes.status) {
                    balanceError = balanceRes.message || "Failed to retrieve balance from Paystack";
                }
            }
            catch (err) {
                console.error("Failed to fetch Paystack balance", err);
                balanceError = err?.response?.data?.message || err.message || "Could not connect to Paystack";
            }
            // Fetch live transactions directly from Paystack API (capped at 100)
            try {
                const txRes = await client.transaction.list({ perPage: 100 });
                if (txRes && txRes.status && Array.isArray(txRes.data)) {
                    rawPaystackTransactions = txRes.data;
                }
                else if (txRes && !txRes.status) {
                    transactionsError = txRes.message || "Failed to retrieve transactions from Paystack";
                }
            }
            catch (err) {
                console.error("Failed to fetch Paystack transactions", err);
                transactionsError = err?.response?.data?.message || err.message || "Could not fetch Paystack transactions";
            }
        }
        else {
            balanceError = "Paystack secret key is not configured";
            transactionsError = "Paystack secret key is not configured";
        }
        // 4. Normalize and combine transactions from Paystack and Medusa
        const normalizedTransactions = [];
        const seenReferences = new Set();
        const seenPaymentIds = new Set();
        for (const tx of rawPaystackTransactions) {
            const txRef = String(tx.reference || tx.id || "");
            if (txRef)
                seenReferences.add(txRef);
            if (tx.id)
                seenReferences.add(String(tx.id));
            let meta = tx.metadata;
            if (typeof meta === "string") {
                try {
                    meta = JSON.parse(meta);
                }
                catch {
                    meta = {};
                }
            }
            meta = meta || {};
            // Match with Medusa order
            let matchedOrder = (meta.order_id && orderById.get(meta.order_id)) ||
                (meta.orderId && orderById.get(meta.orderId)) ||
                (meta.order?.id && orderById.get(meta.order?.id)) ||
                (meta.display_id && orderByDisplayId.get(String(meta.display_id))) ||
                (txRef && orderByRef.get(txRef));
            // Attempt matching by reference parts if still not found
            if (!matchedOrder && txRef) {
                const parts = txRef.split("-");
                for (const part of parts) {
                    if (part && orderByDisplayId.has(part)) {
                        matchedOrder = orderByDisplayId.get(part);
                        break;
                    }
                    if (part && orderById.has(part)) {
                        matchedOrder = orderById.get(part);
                        break;
                    }
                }
            }
            // Match with Repair ticket if applicable
            let matchedRepair = null;
            const ticketId = meta.ticket_id || meta.ticketId;
            if (ticketId && repairById.has(ticketId)) {
                matchedRepair = repairById.get(ticketId);
            }
            else if (txRef) {
                const match = txRef.match(/^REP-([^-]+)/i);
                if (match && repairByTicketNumber.has(match[1].toLowerCase())) {
                    matchedRepair = repairByTicketNumber.get(match[1].toLowerCase());
                }
                else if (repairByTicketNumber.has(txRef.toLowerCase())) {
                    matchedRepair = repairByTicketNumber.get(txRef.toLowerCase());
                }
            }
            const txCurrency = (tx.currency || storeCurrency).toUpperCase();
            const standardAmount = (0, currency_1.getMedusaAmount)(Number(tx.amount || 0), txCurrency);
            // Auto-reconcile unpaid order if Paystack payment succeeded
            if (matchedOrder && tx.status === "success") {
                const payCol = matchedOrder.payment_collections?.[0];
                const isNotFullyPaid = !payCol || (payCol.status !== "authorized" && payCol.status !== "captured");
                if (isNotFullyPaid) {
                    try {
                        await (0, reconcile_payment_1.reconcileAndCapturePaystackPayment)({
                            container: req.scope,
                            orderId: matchedOrder.id,
                            reference: tx.reference,
                            amount: standardAmount,
                            currency: txCurrency,
                        });
                    }
                    catch (reconErr) {
                        console.debug?.("Dashboard auto-reconcile note:", reconErr?.message);
                    }
                }
            }
            // Auto-reconcile unpaid repair ticket if Paystack payment succeeded
            if (matchedRepair && tx.status === "success" && matchedRepair.payment_status !== "captured") {
                try {
                    await (0, reconcile_payment_1.reconcilePaystackRepairPayment)({
                        container: req.scope,
                        ticketId: matchedRepair.id,
                        reference: tx.reference,
                        amount: standardAmount,
                    });
                }
                catch (repairErr) {
                    console.debug?.("Dashboard repair auto-reconcile note:", repairErr?.message);
                }
            }
            const txDate = tx.paid_at || tx.created_at || new Date().toISOString();
            normalizedTransactions.push({
                id: String(tx.id || tx.reference),
                reference: tx.reference || String(tx.id),
                amount: standardAmount,
                currency_code: txCurrency,
                status: tx.status || "success",
                gateway_response: tx.gateway_response || tx.message || "",
                channel: tx.channel || "card",
                paid_at: tx.paid_at || null,
                created_at: txDate,
                customer: {
                    email: tx.customer?.email || matchedOrder?.email || "",
                    name: [tx.customer?.first_name, tx.customer?.last_name].filter(Boolean).join(" ") || "",
                    phone: tx.customer?.phone || "",
                },
                order: matchedOrder ? {
                    id: matchedOrder.id,
                    display_id: matchedOrder.display_id,
                } : null,
                payment_collection: matchedOrder ? {
                    order: {
                        id: matchedOrder.id,
                        display_id: matchedOrder.display_id,
                    }
                } : null,
                repair: matchedRepair ? {
                    id: matchedRepair.id,
                    ticket_number: matchedRepair.ticket_number,
                } : null,
                source: "paystack",
            });
        }
        // Merge any Medusa payment records that are not in Paystack transactions
        (payments || []).forEach((payment) => {
            const pRef = payment.data?.paystackTxRef || payment.data?.reference || payment.id;
            if (pRef && seenReferences.has(String(pRef)))
                return;
            if (payment.id && seenPaymentIds.has(payment.id))
                return;
            seenPaymentIds.add(payment.id);
            const pCurrency = (payment.currency_code || storeCurrency).toUpperCase();
            const pAmount = Number(payment.amount || 0);
            normalizedTransactions.push({
                id: payment.id,
                reference: pRef || payment.id,
                amount: pAmount,
                currency_code: pCurrency,
                status: "success",
                gateway_response: "Successful",
                channel: "medusa",
                paid_at: payment.created_at,
                created_at: payment.created_at,
                customer: {
                    email: payment.payment_collection?.order?.email || "",
                    name: "",
                    phone: "",
                },
                order: payment.payment_collection?.order ? {
                    id: payment.payment_collection.order.id,
                    display_id: payment.payment_collection.order.display_id,
                } : null,
                payment_collection: payment.payment_collection,
                source: "medusa",
            });
        });
        // Sort all transactions by date descending (newest first)
        normalizedTransactions.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        // 5. Aggregate revenue and graph metrics
        let totalRevenue = 0;
        const now = new Date();
        const dailyDataMap = new Map();
        const weeklyDataMap = new Map();
        const monthlyDataMap = new Map();
        const yearlyDataMap = new Map();
        // Daily (last 30 days)
        for (let i = 29; i >= 0; i--) {
            const d = new Date(now);
            d.setDate(d.getDate() - i);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            dailyDataMap.set(key, 0);
        }
        // Weekly (last 12 weeks)
        for (let i = 11; i >= 0; i--) {
            const d = new Date(now);
            d.setDate(d.getDate() - (i * 7));
            const firstDayOfYear = new Date(d.getFullYear(), 0, 1);
            const pastDaysOfYear = (d.getTime() - firstDayOfYear.getTime()) / 86400000;
            const weekNum = Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
            const key = `${d.getFullYear()}-W${String(weekNum).padStart(2, '0')}`;
            if (!weeklyDataMap.has(key)) {
                weeklyDataMap.set(key, 0);
            }
        }
        // Monthly (last 12 months)
        for (let i = 11; i >= 0; i--) {
            const d = new Date(now);
            d.setMonth(d.getMonth() - i);
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
            monthlyDataMap.set(key, 0);
        }
        // Yearly (last 5 years)
        for (let i = 4; i >= 0; i--) {
            const yearStr = String(now.getFullYear() - i);
            yearlyDataMap.set(yearStr, 0);
        }
        normalizedTransactions.forEach((tx) => {
            // Only successful transactions count towards revenue
            if (tx.status !== "success")
                return;
            const amount = Number(tx.amount || 0);
            totalRevenue += amount;
            const date = new Date(tx.created_at);
            // Daily
            const dKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
            if (dailyDataMap.has(dKey)) {
                dailyDataMap.set(dKey, dailyDataMap.get(dKey) + amount);
            }
            // Weekly
            const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
            const pastDaysOfYear = (date.getTime() - firstDayOfYear.getTime()) / 86400000;
            const weekNum = Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
            const wKey = `${date.getFullYear()}-W${String(weekNum).padStart(2, '0')}`;
            if (weeklyDataMap.has(wKey)) {
                weeklyDataMap.set(wKey, weeklyDataMap.get(wKey) + amount);
            }
            // Monthly
            const mKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            if (monthlyDataMap.has(mKey)) {
                monthlyDataMap.set(mKey, monthlyDataMap.get(mKey) + amount);
            }
            // Yearly
            const yKey = String(date.getFullYear());
            if (yearlyDataMap.has(yKey)) {
                yearlyDataMap.set(yKey, yearlyDataMap.get(yKey) + amount);
            }
        });
        const dailyGraph = Array.from(dailyDataMap.entries()).map(([name, total]) => ({ name, total }));
        const weeklyGraph = Array.from(weeklyDataMap.entries()).map(([name, total]) => ({ name, total }));
        const monthlyGraph = Array.from(monthlyDataMap.entries()).map(([name, total]) => ({ name, total }));
        const yearlyGraph = Array.from(yearlyDataMap.entries()).map(([name, total]) => ({ name, total }));
        const cappedTransactions = normalizedTransactions.slice(0, 100);
        res.status(200).json({
            success: true,
            data: {
                transactions: cappedTransactions,
                payments: cappedTransactions, // Backwards-compatible
                totalRevenue,
                dailyGraph,
                weeklyGraph,
                monthlyGraph,
                yearlyGraph,
                balance,
                balanceError,
                transactionsError,
            }
        });
    }
    catch (error) {
        console.error("Dashboard API Error:", error);
        res.status(500).json({ message: error.message || "Failed to load dashboard data" });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3BheXN0YWNrL2Rhc2hib2FyZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQVVBLGtCQWtjQztBQTNjRCxxREFBK0U7QUFDL0UsOEdBQXFGO0FBQ3JGLDRFQUl1RDtBQUN2RCw4RkFBNEk7QUFFckksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFakUsc0NBQXNDO1FBQ3RDLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN2QixJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFFMUIsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7Z0JBQ3pDLE1BQU0sRUFBRSxPQUFPO2dCQUNmLE1BQU0sRUFBRSxDQUFDLFVBQVUsRUFBRSx1QkFBdUIsRUFBRSx3QkFBd0IsQ0FBQzthQUN4RSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRS9CLElBQUksTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDaEIsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBUSxDQUFDO2dCQUNsQyxJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsQ0FBQztvQkFDM0MsYUFBYSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsbUJBQTZCLENBQUM7Z0JBQ2xFLENBQUM7Z0JBQ0QsTUFBTSxXQUFXLEdBQ2YsUUFBUSxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLGFBQWE7b0JBQzVFLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLGFBQWE7b0JBQ2pELFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztnQkFDakMsSUFBSSxXQUFXLEVBQUUsQ0FBQztvQkFDaEIsYUFBYSxHQUFHLFdBQVcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDNUMsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQUMsTUFBTSxDQUFDLENBQUEsQ0FBQztRQUVWLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUM7Z0JBQ0gsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0RCxJQUFJLFlBQVksSUFBSSxPQUFPLFlBQVksQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUM7b0JBQ2xFLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDOUQsSUFBSSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO3dCQUNoQixNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFRLENBQUM7d0JBQ2xDLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsRUFBRSxDQUFDOzRCQUMzQyxhQUFhLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxtQkFBNkIsQ0FBQzt3QkFDbEUsQ0FBQzt3QkFDRCxNQUFNLFdBQVcsR0FDZixRQUFRLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsYUFBYTs0QkFDNUUsUUFBUSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsYUFBYTs0QkFDakQsUUFBUSxDQUFDLHFCQUFxQixDQUFDO3dCQUNqQyxJQUFJLFdBQVcsRUFBRSxDQUFDOzRCQUNoQixhQUFhLEdBQUcsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUM1QyxDQUFDO29CQUNILENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7WUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO1FBQ1osQ0FBQztRQUVELE1BQU0sU0FBUyxHQUFHLElBQUEsbUNBQXdCLEVBQUMsYUFBYSxDQUFDLENBQUM7UUFFMUQsd0RBQXdEO1FBQ3hELE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQzNDLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLE1BQU0sRUFBRTtnQkFDTixJQUFJO2dCQUNKLFFBQVE7Z0JBQ1IsZUFBZTtnQkFDZixZQUFZO2dCQUNaLE1BQU07Z0JBQ04sNkJBQTZCO2dCQUM3QixxQ0FBcUM7Z0JBQ3JDLGdDQUFnQzthQUNqQztZQUNELE9BQU8sRUFBRTtnQkFDUCxXQUFXLEVBQUUsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFO2FBQ3JDO1NBQ0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUUvQix1RUFBdUU7UUFDdkUsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDekMsTUFBTSxFQUFFLE9BQU87WUFDZixNQUFNLEVBQUU7Z0JBQ04sSUFBSTtnQkFDSixZQUFZO2dCQUNaLE9BQU87Z0JBQ1AsT0FBTztnQkFDUCxlQUFlO2dCQUNmLFlBQVk7Z0JBQ1osVUFBVTtnQkFDVix3QkFBd0I7Z0JBQ3hCLDRCQUE0QjtnQkFDNUIseUNBQXlDO2dCQUN6Qyw2Q0FBNkM7Z0JBQzdDLDJDQUEyQztnQkFDM0Msa0RBQWtEO2dCQUNsRCxpQ0FBaUM7Z0JBQ2pDLHFDQUFxQztnQkFDckMsNENBQTRDO2dCQUM1QywwQ0FBMEM7YUFDM0M7U0FDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRS9CLHNDQUFzQztRQUN0QyxNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBZSxDQUFDO1FBQ3pDLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEVBQWUsQ0FBQztRQUNoRCxNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQUcsRUFBZSxDQUFDO1FBRTFDLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3BDLElBQUksS0FBSyxDQUFDLEVBQUU7Z0JBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdDLElBQUksS0FBSyxDQUFDLFVBQVUsSUFBSSxJQUFJO2dCQUFFLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRXBGLE1BQU0sT0FBTyxHQUFJLEtBQUssQ0FBQyxRQUFnQixFQUFFLGtCQUFrQixDQUFDO1lBQzVELElBQUksT0FBTztnQkFBRSxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVwRCxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRTtnQkFDckQsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUU7b0JBQzlDLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsYUFBYSxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDO29CQUN4RCxJQUFJLElBQUk7d0JBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzlDLElBQUksQ0FBQyxDQUFDLEVBQUU7d0JBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUMsQ0FBQztnQkFDSCxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUU7b0JBQ3RDLElBQUksQ0FBQyxDQUFDLEVBQUU7d0JBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCwyREFBMkQ7UUFDM0QsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDO1FBQzlCLElBQUksYUFBYSxHQUFVLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUM7WUFDSCxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN6RSxJQUFJLGFBQWEsSUFBSSxPQUFPLGFBQWEsQ0FBQyxpQkFBaUIsS0FBSyxVQUFVLEVBQUUsQ0FBQztnQkFDM0UsYUFBYSxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUMzRixDQUFDO1FBQ0gsQ0FBQztRQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7UUFFVixNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQUcsRUFBZSxDQUFDO1FBQzFDLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxHQUFHLEVBQWUsQ0FBQztRQUNwRCxLQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDdEMsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFBRSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3BCLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7UUFDSCxDQUFDO1FBRUQsa0RBQWtEO1FBQ2xELElBQUksT0FBTyxHQUFRLElBQUksQ0FBQztRQUN4QixJQUFJLFlBQVksR0FBa0IsSUFBSSxDQUFDO1FBQ3ZDLElBQUksdUJBQXVCLEdBQVUsRUFBRSxDQUFDO1FBQ3hDLElBQUksaUJBQWlCLEdBQWtCLElBQUksQ0FBQztRQUU1QyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsTUFBTSxNQUFNLEdBQUcsSUFBSSx5QkFBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdDLDhCQUE4QjtZQUM5QixJQUFJLENBQUM7Z0JBQ0gsTUFBTSxVQUFVLEdBQUcsTUFBTSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUM5QyxJQUFJLFVBQVUsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdkQsT0FBTyxHQUFHLElBQUEsb0NBQXlCLEVBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDdEUsQ0FBQztxQkFBTSxJQUFJLFVBQVUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDNUMsWUFBWSxHQUFHLFVBQVUsQ0FBQyxPQUFPLElBQUksMENBQTBDLENBQUM7Z0JBQ2xGLENBQUM7WUFDSCxDQUFDO1lBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztnQkFDbEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDdkQsWUFBWSxHQUFHLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLCtCQUErQixDQUFDO1lBQ2hHLENBQUM7WUFFRCxxRUFBcUU7WUFDckUsSUFBSSxDQUFDO2dCQUNILE1BQU0sS0FBSyxHQUFHLE1BQU0sTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO29CQUN2RCx1QkFBdUIsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxDQUFDO3FCQUFNLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNsQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLCtDQUErQyxDQUFDO2dCQUN2RixDQUFDO1lBQ0gsQ0FBQztZQUFDLE9BQU8sR0FBUSxFQUFFLENBQUM7Z0JBQ2xCLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUNBQXVDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQzVELGlCQUFpQixHQUFHLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLHVDQUF1QyxDQUFDO1lBQzdHLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLFlBQVksR0FBRyx1Q0FBdUMsQ0FBQztZQUN2RCxpQkFBaUIsR0FBRyx1Q0FBdUMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsaUVBQWlFO1FBQ2pFLE1BQU0sc0JBQXNCLEdBQVUsRUFBRSxDQUFDO1FBQ3pDLE1BQU0sY0FBYyxHQUFHLElBQUksR0FBRyxFQUFVLENBQUM7UUFDekMsTUFBTSxjQUFjLEdBQUcsSUFBSSxHQUFHLEVBQVUsQ0FBQztRQUV6QyxLQUFLLE1BQU0sRUFBRSxJQUFJLHVCQUF1QixFQUFFLENBQUM7WUFDekMsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUNsRCxJQUFJLEtBQUs7Z0JBQUUsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyQyxJQUFJLEVBQUUsQ0FBQyxFQUFFO2dCQUFFLGNBQWMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRTdDLElBQUksSUFBSSxHQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDNUIsSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDO29CQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUFDLENBQUM7Z0JBQUMsTUFBTSxDQUFDO29CQUFDLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQUMsQ0FBQztZQUN2RCxDQUFDO1lBQ0QsSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7WUFFbEIsMEJBQTBCO1lBQzFCLElBQUksWUFBWSxHQUNkLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0MsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM3QyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRSxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDakQsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xFLENBQUMsS0FBSyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUVuQyx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLFlBQVksSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDM0IsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDL0IsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDekIsSUFBSSxJQUFJLElBQUksZ0JBQWdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ3ZDLFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQzFDLE1BQU07b0JBQ1IsQ0FBQztvQkFDRCxJQUFJLElBQUksSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQ2hDLFlBQVksR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNuQyxNQUFNO29CQUNSLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7WUFFRCx5Q0FBeUM7WUFDekMsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDO1lBQzlCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNqRCxJQUFJLFFBQVEsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7Z0JBQ3pDLGFBQWEsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNDLENBQUM7aUJBQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxLQUFLLElBQUksb0JBQW9CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLENBQUM7b0JBQzlELGFBQWEsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7Z0JBQ25FLENBQUM7cUJBQU0sSUFBSSxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsQ0FBQztvQkFDekQsYUFBYSxHQUFHLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztnQkFDaEUsQ0FBQztZQUNILENBQUM7WUFFRCxNQUFNLFVBQVUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDaEUsTUFBTSxjQUFjLEdBQUcsSUFBQSwwQkFBZSxFQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBRTNFLDREQUE0RDtZQUM1RCxJQUFJLFlBQVksSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUM1QyxNQUFNLE1BQU0sR0FBRyxZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckQsTUFBTSxjQUFjLEdBQUcsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFlBQVksSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO2dCQUNuRyxJQUFJLGNBQWMsRUFBRSxDQUFDO29CQUNuQixJQUFJLENBQUM7d0JBQ0gsTUFBTSxJQUFBLHNEQUFrQyxFQUFDOzRCQUN2QyxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUs7NEJBQ3BCLE9BQU8sRUFBRSxZQUFZLENBQUMsRUFBRTs0QkFDeEIsU0FBUyxFQUFFLEVBQUUsQ0FBQyxTQUFTOzRCQUN2QixNQUFNLEVBQUUsY0FBYzs0QkFDdEIsUUFBUSxFQUFFLFVBQVU7eUJBQ3JCLENBQUMsQ0FBQztvQkFDTCxDQUFDO29CQUFDLE9BQU8sUUFBYSxFQUFFLENBQUM7d0JBQ3ZCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxnQ0FBZ0MsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ3ZFLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7WUFFRCxvRUFBb0U7WUFDcEUsSUFBSSxhQUFhLElBQUksRUFBRSxDQUFDLE1BQU0sS0FBSyxTQUFTLElBQUksYUFBYSxDQUFDLGNBQWMsS0FBSyxVQUFVLEVBQUUsQ0FBQztnQkFDNUYsSUFBSSxDQUFDO29CQUNILE1BQU0sSUFBQSxrREFBOEIsRUFBQzt3QkFDbkMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxLQUFLO3dCQUNwQixRQUFRLEVBQUUsYUFBYSxDQUFDLEVBQUU7d0JBQzFCLFNBQVMsRUFBRSxFQUFFLENBQUMsU0FBUzt3QkFDdkIsTUFBTSxFQUFFLGNBQWM7cUJBQ3ZCLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUFDLE9BQU8sU0FBYyxFQUFFLENBQUM7b0JBQ3hCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyx1Q0FBdUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQy9FLENBQUM7WUFDSCxDQUFDO1lBRUQsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7WUFFdkUsc0JBQXNCLENBQUMsSUFBSSxDQUFDO2dCQUMxQixFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQztnQkFDakMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxTQUFTLElBQUksTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ3hDLE1BQU0sRUFBRSxjQUFjO2dCQUN0QixhQUFhLEVBQUUsVUFBVTtnQkFDekIsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLElBQUksU0FBUztnQkFDOUIsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxPQUFPLElBQUksRUFBRTtnQkFDekQsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLElBQUksTUFBTTtnQkFDN0IsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLElBQUksSUFBSTtnQkFDM0IsVUFBVSxFQUFFLE1BQU07Z0JBQ2xCLFFBQVEsRUFBRTtvQkFDUixLQUFLLEVBQUUsRUFBRSxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksWUFBWSxFQUFFLEtBQUssSUFBSSxFQUFFO29CQUN0RCxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFVBQVUsRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRTtvQkFDdkYsS0FBSyxFQUFFLEVBQUUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLEVBQUU7aUJBQ2hDO2dCQUNELEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO29CQUNwQixFQUFFLEVBQUUsWUFBWSxDQUFDLEVBQUU7b0JBQ25CLFVBQVUsRUFBRSxZQUFZLENBQUMsVUFBVTtpQkFDcEMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDUixrQkFBa0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO29CQUNqQyxLQUFLLEVBQUU7d0JBQ0wsRUFBRSxFQUFFLFlBQVksQ0FBQyxFQUFFO3dCQUNuQixVQUFVLEVBQUUsWUFBWSxDQUFDLFVBQVU7cUJBQ3BDO2lCQUNGLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQ1IsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7b0JBQ3RCLEVBQUUsRUFBRSxhQUFhLENBQUMsRUFBRTtvQkFDcEIsYUFBYSxFQUFFLGFBQWEsQ0FBQyxhQUFhO2lCQUMzQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUNSLE1BQU0sRUFBRSxVQUFVO2FBQ25CLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCx5RUFBeUU7UUFDekUsQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBWSxFQUFFLEVBQUU7WUFDeEMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFhLElBQUksT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLElBQUksT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNsRixJQUFJLElBQUksSUFBSSxjQUFjLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFBRSxPQUFPO1lBQ3JELElBQUksT0FBTyxDQUFDLEVBQUUsSUFBSSxjQUFjLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQUUsT0FBTztZQUN6RCxjQUFjLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUUvQixNQUFNLFNBQVMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLElBQUksYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDekUsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7WUFFNUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDO2dCQUMxQixFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsU0FBUyxFQUFFLElBQUksSUFBSSxPQUFPLENBQUMsRUFBRTtnQkFDN0IsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsYUFBYSxFQUFFLFNBQVM7Z0JBQ3hCLE1BQU0sRUFBRSxTQUFTO2dCQUNqQixnQkFBZ0IsRUFBRSxZQUFZO2dCQUM5QixPQUFPLEVBQUUsUUFBUTtnQkFDakIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUMzQixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFFBQVEsRUFBRTtvQkFDUixLQUFLLEVBQUUsT0FBTyxDQUFDLGtCQUFrQixFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRTtvQkFDckQsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLEVBQUU7aUJBQ1Y7Z0JBQ0QsS0FBSyxFQUFFLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUN6QyxFQUFFLEVBQUUsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUN2QyxVQUFVLEVBQUUsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxVQUFVO2lCQUN4RCxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUNSLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxrQkFBa0I7Z0JBQzlDLE1BQU0sRUFBRSxRQUFRO2FBQ2pCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsMERBQTBEO1FBQzFELHNCQUFzQixDQUFDLElBQUksQ0FDekIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUM5RSxDQUFDO1FBRUYseUNBQXlDO1FBQ3pDLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztRQUNyQixNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBRXZCLE1BQU0sWUFBWSxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFDO1FBQy9DLE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFDO1FBQ2hELE1BQU0sY0FBYyxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFDO1FBQ2pELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFDO1FBRWhELHVCQUF1QjtRQUN2QixLQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDM0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdEgsWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQztRQUVELHlCQUF5QjtRQUN6QixLQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxNQUFNLGNBQWMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxHQUFHLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUMzRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM5RSxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsS0FBSyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3RFLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzVCLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUM7UUFDSCxDQUFDO1FBRUQsMkJBQTJCO1FBQzNCLEtBQUssSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUM3QixNQUFNLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN4QixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUM5RSxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDO1FBRUQsd0JBQXdCO1FBQ3hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUM1QixNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzlDLGFBQWEsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2hDLENBQUM7UUFFRCxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFPLEVBQUUsRUFBRTtZQUN6QyxxREFBcUQ7WUFDckQsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLFNBQVM7Z0JBQUUsT0FBTztZQUVwQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN0QyxZQUFZLElBQUksTUFBTSxDQUFDO1lBRXZCLE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVyQyxRQUFRO1lBQ1IsTUFBTSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDaEksSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzNCLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFDM0QsQ0FBQztZQUVELFNBQVM7WUFDVCxNQUFNLGNBQWMsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzFELE1BQU0sY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUM5RSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM5RSxNQUFNLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsS0FBSyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzFFLElBQUksYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUM1QixhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDO1lBQzdELENBQUM7WUFFRCxVQUFVO1lBQ1YsTUFBTSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDckYsSUFBSSxjQUFjLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzdCLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFDL0QsQ0FBQztZQUVELFNBQVM7WUFDVCxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDeEMsSUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzVCLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFDN0QsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDaEcsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEcsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEcsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFbEcsTUFBTSxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRWhFLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxJQUFJO1lBQ2IsSUFBSSxFQUFFO2dCQUNKLFlBQVksRUFBRSxrQkFBa0I7Z0JBQ2hDLFFBQVEsRUFBRSxrQkFBa0IsRUFBRSx1QkFBdUI7Z0JBQ3JELFlBQVk7Z0JBQ1osVUFBVTtnQkFDVixXQUFXO2dCQUNYLFlBQVk7Z0JBQ1osV0FBVztnQkFDWCxPQUFPO2dCQUNQLFlBQVk7Z0JBQ1osaUJBQWlCO2FBQ2xCO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM3QyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLCtCQUErQixFQUFFLENBQUMsQ0FBQztJQUN0RixDQUFDO0FBQ0gsQ0FBQyJ9