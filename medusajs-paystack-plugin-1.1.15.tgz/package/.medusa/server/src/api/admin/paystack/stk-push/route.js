"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const currency_1 = require("../../../../providers/paystack/utils/currency");
async function POST(req, res) {
    const { order_id, phone, amount } = req.body;
    if (!order_id || !phone) {
        return res.status(400).json({ message: "order_id and phone are required" });
    }
    // Format the phone number to +254XXXXXXXXX (Paystack MPESA format)
    let formattedPhone = phone.replace(/\D/g, "");
    if (formattedPhone.startsWith("0")) {
        formattedPhone = "+254" + formattedPhone.substring(1);
    }
    else if (formattedPhone.length === 9 && (formattedPhone.startsWith("7") || formattedPhone.startsWith("1"))) {
        formattedPhone = "+254" + formattedPhone;
    }
    else if (formattedPhone.startsWith("254")) {
        formattedPhone = "+" + formattedPhone;
    }
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    // 1. Retrieve the Order robustly
    let order = null;
    try {
        const orderService = req.scope.resolve(utils_1.Modules.ORDER);
        order = await orderService.retrieveOrder(order_id).catch(() => null);
    }
    catch { }
    if (!order) {
        try {
            const { data: orders } = await query.graph({
                entity: "order",
                fields: ["id", "display_id", "currency_code", "email"],
                filters: { id: order_id }
            }).catch(() => ({ data: [] }));
            order = orders?.[0];
        }
        catch { }
    }
    if (!order) {
        try {
            const pgConnection = req.scope.resolve(utils_1.ContainerRegistrationKeys.PG_CONNECTION);
            const rows = await pgConnection("order")
                .where("id", order_id)
                .orWhere("display_id", isNaN(Number(order_id)) ? -1 : Number(order_id))
                .limit(1);
            if (rows && rows[0])
                order = rows[0];
        }
        catch { }
    }
    if (!order) {
        return res.status(404).json({ message: "Order not found" });
    }
    // 2. Resolve Paystack Secret Key
    const { data: stores } = await query.graph({
        entity: "store",
        fields: ["metadata"]
    }).catch(() => ({ data: [] }));
    const dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key;
    const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
    if (!secretKey) {
        return res.status(500).json({ message: "Paystack is not configured. Please set PAYSTACK_SECRET_KEY." });
    }
    // 3. Resolve amount
    let chargeAmount = amount !== undefined && amount !== null ? Number(amount) : Number(order.total || 0);
    if (!chargeAmount || chargeAmount <= 0) {
        // If order.total wasn't loaded directly, check order_summary table
        try {
            const pgConnection = req.scope.resolve(utils_1.ContainerRegistrationKeys.PG_CONNECTION);
            const summaryRows = await pgConnection("order_summary")
                .where("order_id", order.id)
                .orderBy("version", "desc")
                .limit(1);
            if (summaryRows && summaryRows[0]?.totals) {
                const totals = summaryRows[0].totals;
                chargeAmount = Number(totals.pending_difference || totals.current_order_total || 0);
            }
        }
        catch { }
    }
    if (chargeAmount < 1) {
        return res.status(400).json({ message: "Amount to pay must be at least 1." });
    }
    const paystackAmount = Math.round(chargeAmount * 100);
    const currency = (order.currency_code || "KES").toUpperCase();
    const reference = `STK-${order.display_id || order.id.slice(-6)}-${Date.now()}`;
    let customerEmail = order.email;
    if (!customerEmail) {
        customerEmail = `guest-${order.id}@urbandevicecare.co.uk`;
    }
    let provider = "mpesa";
    const curr = currency.toLowerCase();
    if (curr === "ghs" || curr === "xof" || curr === "rwf") {
        provider = "mtn";
    }
    // Attempt to link a payment session on the order's payment collection
    let sessionId;
    try {
        const paymentModule = req.scope.resolve(utils_1.Modules.PAYMENT);
        const { data: fullOrders } = await query.graph({
            entity: "order",
            fields: ["payment_collections.id", "payment_collections.status"],
            filters: { id: order.id }
        }).catch(() => ({ data: [] }));
        const payCol = fullOrders?.[0]?.payment_collections?.[0];
        if (payCol && paymentModule && typeof paymentModule.createPaymentSession === "function") {
            const session = await paymentModule.createPaymentSession(payCol.id, {
                provider_id: "paystack",
                currency_code: currency.toLowerCase(),
                amount: chargeAmount,
                data: {
                    paystackTxRef: reference,
                    reference,
                },
            }).catch(() => null);
            if (session?.id) {
                sessionId = session.id;
            }
        }
    }
    catch { }
    try {
        const payload = {
            email: customerEmail,
            amount: paystackAmount,
            currency,
            reference,
            mobile_money: {
                phone: formattedPhone,
                provider,
            },
            metadata: {
                order_id: order.id,
                stk_push: true,
                ...(sessionId ? { session_id: sessionId } : {}),
            },
        };
        const paystackRes = await fetch("https://api.paystack.co/charge", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${secretKey}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        });
        const paystackData = await paystackRes.json();
        if (!paystackRes.ok || !paystackData.status || paystackData.data?.status === "failed") {
            const detailedMessage = paystackData.data?.message ||
                paystackData.data?.gateway_response ||
                paystackData.data?.data?.message ||
                paystackData.message ||
                "Failed to push STK prompt via Paystack";
            return res.status(400).json({
                message: detailedMessage,
                data: paystackData,
            });
        }
        res.status(200).json({
            success: true,
            message: paystackData.data?.display_text || `STK push prompt sent to ${formattedPhone}. Please check your phone.`,
            reference,
            data: paystackData.data,
        });
    }
    catch (error) {
        console.error("[Paystack STK Push Error]:", error);
        res.status(500).json({
            message: error?.message || "Failed to initiate STK Push",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3BheXN0YWNrL3N0ay1wdXNoL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBSUEsb0JBeUxDO0FBNUxELHFEQUErRTtBQUMvRSw0RUFBeUY7QUFFbEYsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQTRELENBQUM7SUFFckcsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUNBQWlDLEVBQUUsQ0FBQyxDQUFDO0lBQzlFLENBQUM7SUFFRCxtRUFBbUU7SUFDbkUsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUMsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDbkMsY0FBYyxHQUFHLE1BQU0sR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hELENBQUM7U0FBTSxJQUFJLGNBQWMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM3RyxjQUFjLEdBQUcsTUFBTSxHQUFHLGNBQWMsQ0FBQztJQUMzQyxDQUFDO1NBQU0sSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDNUMsY0FBYyxHQUFHLEdBQUcsR0FBRyxjQUFjLENBQUM7SUFDeEMsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRWpFLGlDQUFpQztJQUNqQyxJQUFJLEtBQUssR0FBUSxJQUFJLENBQUM7SUFDdEIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RELEtBQUssR0FBRyxNQUFNLFlBQVksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBRVYsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ1gsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7Z0JBQ3pDLE1BQU0sRUFBRSxPQUFPO2dCQUNmLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRTthQUMxQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQy9CLEtBQUssR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QixDQUFDO1FBQUMsTUFBTSxDQUFDLENBQUEsQ0FBQztJQUNaLENBQUM7SUFFRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxJQUFJLENBQUM7WUFDSCxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNoRixNQUFNLElBQUksR0FBRyxNQUFNLFlBQVksQ0FBQyxPQUFPLENBQUM7aUJBQ3JDLEtBQUssQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO2lCQUNyQixPQUFPLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDdEUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ1osSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBQ1osQ0FBQztJQUVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCxpQ0FBaUM7SUFDakMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDekMsTUFBTSxFQUFFLE9BQU87UUFDZixNQUFNLEVBQUUsQ0FBQyxVQUFVLENBQUM7S0FDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMvQixNQUFNLGFBQWEsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsbUJBQXlDLENBQUM7SUFFdkYsTUFBTSxTQUFTLEdBQUcsSUFBQSxtQ0FBd0IsRUFBQyxhQUFhLENBQUMsQ0FBQztJQUMxRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDZixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLDZEQUE2RCxFQUFFLENBQUMsQ0FBQztJQUMxRyxDQUFDO0lBRUQsb0JBQW9CO0lBQ3BCLElBQUksWUFBWSxHQUFHLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztJQUN2RyxJQUFJLENBQUMsWUFBWSxJQUFJLFlBQVksSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUN2QyxtRUFBbUU7UUFDbkUsSUFBSSxDQUFDO1lBQ0gsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDaEYsTUFBTSxXQUFXLEdBQUcsTUFBTSxZQUFZLENBQUMsZUFBZSxDQUFDO2lCQUNwRCxLQUFLLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUM7aUJBQzNCLE9BQU8sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDO2lCQUMxQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDWixJQUFJLFdBQVcsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUM7Z0JBQzFDLE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQ3JDLFlBQVksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGtCQUFrQixJQUFJLE1BQU0sQ0FBQyxtQkFBbUIsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN0RixDQUFDO1FBQ0gsQ0FBQztRQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7SUFDWixDQUFDO0lBRUQsSUFBSSxZQUFZLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDckIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxtQ0FBbUMsRUFBRSxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3RELE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM5RCxNQUFNLFNBQVMsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLElBQUksS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztJQUVoRixJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ2hDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQixhQUFhLEdBQUcsU0FBUyxLQUFLLENBQUMsRUFBRSx3QkFBd0IsQ0FBQztJQUM1RCxDQUFDO0lBRUQsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDO0lBQ3ZCLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNwQyxJQUFJLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7UUFDdkQsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNuQixDQUFDO0lBRUQsc0VBQXNFO0lBQ3RFLElBQUksU0FBNkIsQ0FBQztJQUNsQyxJQUFJLENBQUM7UUFDSCxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekQsTUFBTSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDN0MsTUFBTSxFQUFFLE9BQU87WUFDZixNQUFNLEVBQUUsQ0FBQyx3QkFBd0IsRUFBRSw0QkFBNEIsQ0FBQztZQUNoRSxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRTtTQUMxQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRS9CLE1BQU0sTUFBTSxHQUFHLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekQsSUFBSSxNQUFNLElBQUksYUFBYSxJQUFJLE9BQU8sYUFBYSxDQUFDLG9CQUFvQixLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ3hGLE1BQU0sT0FBTyxHQUFHLE1BQU0sYUFBYSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xFLFdBQVcsRUFBRSxVQUFVO2dCQUN2QixhQUFhLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRTtnQkFDckMsTUFBTSxFQUFFLFlBQVk7Z0JBQ3BCLElBQUksRUFBRTtvQkFDSixhQUFhLEVBQUUsU0FBUztvQkFDeEIsU0FBUztpQkFDVjthQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFckIsSUFBSSxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUM7Z0JBQ2hCLFNBQVMsR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ3pCLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7SUFFVixJQUFJLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRztZQUNkLEtBQUssRUFBRSxhQUFhO1lBQ3BCLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLFFBQVE7WUFDUixTQUFTO1lBQ1QsWUFBWSxFQUFFO2dCQUNaLEtBQUssRUFBRSxjQUFjO2dCQUNyQixRQUFRO2FBQ1Q7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNsQixRQUFRLEVBQUUsSUFBSTtnQkFDZCxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2FBQ2hEO1NBQ0YsQ0FBQztRQUVGLE1BQU0sV0FBVyxHQUFHLE1BQU0sS0FBSyxDQUFDLGdDQUFnQyxFQUFFO1lBQ2hFLE1BQU0sRUFBRSxNQUFNO1lBQ2QsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFBRSxVQUFVLFNBQVMsRUFBRTtnQkFDcEMsY0FBYyxFQUFFLGtCQUFrQjthQUNuQztZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztTQUM5QixDQUFDLENBQUM7UUFFSCxNQUFNLFlBQVksR0FBRyxNQUFNLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUU5QyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLElBQUksWUFBWSxDQUFDLElBQUksRUFBRSxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDdEYsTUFBTSxlQUFlLEdBQ25CLFlBQVksQ0FBQyxJQUFJLEVBQUUsT0FBTztnQkFDMUIsWUFBWSxDQUFDLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ25DLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU87Z0JBQ2hDLFlBQVksQ0FBQyxPQUFPO2dCQUNwQix3Q0FBd0MsQ0FBQztZQUUzQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsZUFBZTtnQkFDeEIsSUFBSSxFQUFFLFlBQVk7YUFDbkIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxJQUFJO1lBQ2IsT0FBTyxFQUFFLFlBQVksQ0FBQyxJQUFJLEVBQUUsWUFBWSxJQUFJLDJCQUEyQixjQUFjLDRCQUE0QjtZQUNqSCxTQUFTO1lBQ1QsSUFBSSxFQUFFLFlBQVksQ0FBQyxJQUFJO1NBQ3hCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbkQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLElBQUksNkJBQTZCO1NBQ3pELENBQUMsQ0FBQztJQUNMLENBQUM7QUFDSCxDQUFDIn0=