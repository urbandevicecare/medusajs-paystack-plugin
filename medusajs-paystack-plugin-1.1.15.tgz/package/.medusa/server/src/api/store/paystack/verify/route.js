"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const currency_1 = require("../../../../providers/paystack/utils/currency");
const reconcile_payment_1 = require("../../../../providers/paystack/utils/reconcile-payment");
async function POST(req, res) {
    const { reference } = req.body;
    if (!reference) {
        return res.status(400).json({ message: "Reference is required" });
    }
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    let dynamicSecret = "";
    try {
        const { data: stores } = await query.graph({
            entity: "store",
            fields: ["metadata"]
        }).catch(() => ({ data: [] }));
        dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key || "";
    }
    catch { }
    if (!dynamicSecret) {
        try {
            const storeService = req.scope.resolve(utils_1.Modules.STORE);
            if (storeService && typeof storeService.listStores === "function") {
                const stores = await storeService.listStores({}, { take: 1 });
                dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key || "";
            }
        }
        catch { }
    }
    const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
    if (!secretKey) {
        return res.status(500).json({ message: "Paystack secret key is not configured" });
    }
    try {
        const paystackRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${secretKey}`,
                "Content-Type": "application/json",
            },
        });
        const paystackData = await paystackRes.json();
        if (!paystackRes.ok || !paystackData.status) {
            return res.status(400).json({
                message: paystackData.message || "Failed to verify transaction with Paystack",
                data: paystackData,
            });
        }
        const txData = paystackData.data;
        const isSuccess = txData.status === "success";
        let reconcileResult = null;
        const orderId = txData.metadata?.order_id;
        const ticketId = txData.metadata?.ticket_id || txData.metadata?.ticketId;
        const isRepairTx = Boolean(ticketId || (txData.reference && String(txData.reference).startsWith("REP-")));
        const medusaAmount = (0, currency_1.getMedusaAmount)(Number(txData.amount || 0), txData.currency);
        if (isSuccess && orderId) {
            try {
                reconcileResult = await (0, reconcile_payment_1.reconcileAndCapturePaystackPayment)({
                    container: req.scope,
                    orderId,
                    reference: txData.reference,
                    amount: medusaAmount,
                    currency: txData.currency,
                });
            }
            catch (err) {
                console.warn("[Paystack Verify] Error during auto-reconciliation:", err);
            }
        }
        if (isSuccess && isRepairTx) {
            try {
                reconcileResult = await (0, reconcile_payment_1.reconcilePaystackRepairPayment)({
                    container: req.scope,
                    ticketId,
                    reference: txData.reference,
                    amount: medusaAmount,
                });
            }
            catch (err) {
                console.warn("[Paystack Verify] Error during repair auto-reconciliation:", err);
            }
        }
        res.status(200).json({
            success: isSuccess,
            status: txData.status,
            message: isSuccess ? "Payment verified successfully" : `Payment status: ${txData.status}`,
            reference: txData.reference,
            amount: medusaAmount,
            currency: txData.currency,
            captured: Boolean(reconcileResult?.captured),
            data: txData,
        });
    }
    catch (error) {
        console.error("[Paystack Verify Error]:", error);
        res.status(500).json({
            message: error?.message || "Failed to verify payment",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3BheXN0YWNrL3ZlcmlmeS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUtBLG9CQTBHQztBQTlHRCxxREFBK0U7QUFDL0UsNEVBQTBHO0FBQzFHLDhGQUE0STtBQUVySSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQTZCLENBQUM7SUFFeEQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2pFLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztJQUV2QixJQUFJLENBQUM7UUFDSCxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztZQUN6QyxNQUFNLEVBQUUsT0FBTztZQUNmLE1BQU0sRUFBRSxDQUFDLFVBQVUsQ0FBQztTQUNyQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQy9CLGFBQWEsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsbUJBQTZCLElBQUksRUFBRSxDQUFDO0lBQzdFLENBQUM7SUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBRVYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQztZQUNILE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0RCxJQUFJLFlBQVksSUFBSSxPQUFPLFlBQVksQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUM7Z0JBQ2xFLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDOUQsYUFBYSxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxtQkFBNkIsSUFBSSxFQUFFLENBQUM7WUFDN0UsQ0FBQztRQUNILENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBQ1osQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLElBQUEsbUNBQXdCLEVBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSx1Q0FBdUMsRUFBRSxDQUFDLENBQUM7SUFDcEYsQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sV0FBVyxHQUFHLE1BQU0sS0FBSyxDQUFDLDhDQUE4QyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFO1lBQzdHLE1BQU0sRUFBRSxLQUFLO1lBQ2IsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFBRSxVQUFVLFNBQVMsRUFBRTtnQkFDcEMsY0FBYyxFQUFFLGtCQUFrQjthQUNuQztTQUNGLENBQUMsQ0FBQztRQUVILE1BQU0sWUFBWSxHQUFHLE1BQU0sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO1FBRTlDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzVDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxZQUFZLENBQUMsT0FBTyxJQUFJLDRDQUE0QztnQkFDN0UsSUFBSSxFQUFFLFlBQVk7YUFDbkIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7UUFDakMsTUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLENBQUM7UUFFOUMsSUFBSSxlQUFlLEdBQVEsSUFBSSxDQUFDO1FBQ2hDLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDO1FBQzFDLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsU0FBUyxJQUFJLE1BQU0sQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDO1FBQ3pFLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMxRyxNQUFNLFlBQVksR0FBRyxJQUFBLDBCQUFlLEVBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWxGLElBQUksU0FBUyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQztnQkFDSCxlQUFlLEdBQUcsTUFBTSxJQUFBLHNEQUFrQyxFQUFDO29CQUN6RCxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUs7b0JBQ3BCLE9BQU87b0JBQ1AsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO29CQUMzQixNQUFNLEVBQUUsWUFBWTtvQkFDcEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO2lCQUMxQixDQUFDLENBQUM7WUFDTCxDQUFDO1lBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztnQkFDbEIsT0FBTyxDQUFDLElBQUksQ0FBQyxxREFBcUQsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUMzRSxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksU0FBUyxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBQzVCLElBQUksQ0FBQztnQkFDSCxlQUFlLEdBQUcsTUFBTSxJQUFBLGtEQUE4QixFQUFDO29CQUNyRCxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUs7b0JBQ3BCLFFBQVE7b0JBQ1IsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO29CQUMzQixNQUFNLEVBQUUsWUFBWTtpQkFDckIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUFDLE9BQU8sR0FBUSxFQUFFLENBQUM7Z0JBQ2xCLE9BQU8sQ0FBQyxJQUFJLENBQUMsNERBQTRELEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDbEYsQ0FBQztRQUNILENBQUM7UUFFRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsU0FBUztZQUNsQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07WUFDckIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ3pGLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixNQUFNLEVBQUUsWUFBWTtZQUNwQixRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVE7WUFDekIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxlQUFlLEVBQUUsUUFBUSxDQUFDO1lBQzVDLElBQUksRUFBRSxNQUFNO1NBQ2IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sSUFBSSwwQkFBMEI7U0FDdEQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztBQUNILENBQUMifQ==