"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const currency_1 = require("../../../../providers/paystack/utils/currency");
async function POST(req, res) {
    const { order_id, amount } = req.body;
    if (!order_id) {
        return res.status(400).json({ message: "order_id is required" });
    }
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    // 1. Retrieve the Order robustly
    let order = null;
    try {
        const orderService = req.scope.resolve(utils_1.Modules.ORDER);
        order = await orderService.retrieveOrder(order_id).catch(() => null);
    }
    catch { }
    if (!order) {
        try {
            const { data: orders } = await query.graph({
                entity: "order",
                fields: ["id", "display_id", "currency_code", "email"],
                filters: { id: order_id }
            }).catch(() => ({ data: [] }));
            order = orders?.[0];
        }
        catch { }
    }
    if (!order) {
        try {
            const pgConnection = req.scope.resolve(utils_1.ContainerRegistrationKeys.PG_CONNECTION);
            const rows = await pgConnection("order")
                .where("id", order_id)
                .orWhere("display_id", isNaN(Number(order_id)) ? -1 : Number(order_id))
                .limit(1);
            if (rows && rows[0])
                order = rows[0];
        }
        catch { }
    }
    if (!order) {
        return res.status(404).json({ message: "Order not found" });
    }
    // 2. Resolve Paystack Secret Key
    const { data: stores } = await query.graph({
        entity: "store",
        fields: ["metadata"]
    }).catch(() => ({ data: [] }));
    const dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key;
    const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
    if (!secretKey) {
        return res.status(500).json({ message: "Paystack is not configured. Please set PAYSTACK_SECRET_KEY." });
    }
    // 3. Resolve amount
    let chargeAmount = amount !== undefined && amount !== null ? Number(amount) : Number(order.total || 0);
    if (!chargeAmount || chargeAmount <= 0) {
        try {
            const pgConnection = req.scope.resolve(utils_1.ContainerRegistrationKeys.PG_CONNECTION);
            const summaryRows = await pgConnection("order_summary")
                .where("order_id", order.id)
                .orderBy("version", "desc")
                .limit(1);
            if (summaryRows && summaryRows[0]?.totals) {
                const totals = summaryRows[0].totals;
                chargeAmount = Number(totals.pending_difference || totals.current_order_total || 0);
            }
        }
        catch { }
    }
    if (chargeAmount < 1) {
        return res.status(400).json({ message: "Amount must be at least 1." });
    }
    const paystackAmount = Math.round(chargeAmount * 100);
    const currency = (order.currency_code || "KES").toUpperCase();
    const reference = `ORD-${order.display_id || order.id.slice(-6)}-${Date.now()}`;
    let customerEmail = order.email;
    if (!customerEmail) {
        customerEmail = `guest-${order.id}@urbandevicecare.co.uk`;
    }
    // Attempt to link a payment session on the order's payment collection
    let sessionId;
    try {
        const paymentModule = req.scope.resolve(utils_1.Modules.PAYMENT);
        const { data: fullOrders } = await query.graph({
            entity: "order",
            fields: ["payment_collections.id", "payment_collections.status"],
            filters: { id: order.id }
        }).catch(() => ({ data: [] }));
        const payCol = fullOrders?.[0]?.payment_collections?.[0];
        if (payCol && paymentModule && typeof paymentModule.createPaymentSession === "function") {
            const session = await paymentModule.createPaymentSession(payCol.id, {
                provider_id: "paystack",
                currency_code: currency.toLowerCase(),
                amount: chargeAmount,
                data: {
                    paystackTxRef: reference,
                    reference,
                },
            }).catch(() => null);
            if (session?.id) {
                sessionId = session.id;
            }
        }
    }
    catch { }
    try {
        const paystackRes = await fetch("https://api.paystack.co/transaction/initialize", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${secretKey}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                email: customerEmail,
                amount: paystackAmount,
                currency,
                reference,
                metadata: {
                    order_id: order.id,
                    charge_amount: chargeAmount,
                    ...(sessionId ? { session_id: sessionId } : {}),
                },
            }),
        });
        const paystackData = await paystackRes.json();
        if (!paystackRes.ok || !paystackData.status) {
            return res.status(400).json({
                message: paystackData.message || "Failed to initialize Paystack transaction",
                data: paystackData,
            });
        }
        res.status(200).json({
            success: true,
            authorization_url: paystackData.data.authorization_url,
            access_code: paystackData.data.access_code,
            reference: paystackData.data.reference,
            paymentSession: {
                access_code: paystackData.data.access_code,
                paystackTxAccessCode: paystackData.data.access_code,
            },
            data: paystackData.data,
        });
    }
    catch (error) {
        console.error("[Paystack Custom Payment Init Error]:", error);
        res.status(500).json({
            message: error?.message || "Failed to initialize custom payment",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3BheXN0YWNrL2N1c3RvbS1wYXltZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBSUEsb0JBZ0tDO0FBbktELHFEQUErRTtBQUMvRSw0RUFBeUY7QUFFbEYsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBNkMsQ0FBQztJQUUvRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLHNCQUFzQixFQUFFLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFakUsaUNBQWlDO0lBQ2pDLElBQUksS0FBSyxHQUFRLElBQUksQ0FBQztJQUN0QixJQUFJLENBQUM7UUFDSCxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEQsS0FBSyxHQUFHLE1BQU0sWUFBWSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7SUFFVixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDekMsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsT0FBTyxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFO2FBQzFCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsS0FBSyxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RCLENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBQ1osQ0FBQztJQUVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLElBQUksQ0FBQztZQUNILE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2hGLE1BQU0sSUFBSSxHQUFHLE1BQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQztpQkFDckMsS0FBSyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUM7aUJBQ3JCLE9BQU8sQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUN0RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDWixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkMsQ0FBQztRQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7SUFDWixDQUFDO0lBRUQsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ1gsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELGlDQUFpQztJQUNqQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QyxNQUFNLEVBQUUsT0FBTztRQUNmLE1BQU0sRUFBRSxDQUFDLFVBQVUsQ0FBQztLQUNyQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9CLE1BQU0sYUFBYSxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxtQkFBeUMsQ0FBQztJQUV2RixNQUFNLFNBQVMsR0FBRyxJQUFBLG1DQUF3QixFQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzFELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNmLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsNkRBQTZELEVBQUUsQ0FBQyxDQUFDO0lBQzFHLENBQUM7SUFFRCxvQkFBb0I7SUFDcEIsSUFBSSxZQUFZLEdBQUcsTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3ZHLElBQUksQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQ3ZDLElBQUksQ0FBQztZQUNILE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2hGLE1BQU0sV0FBVyxHQUFHLE1BQU0sWUFBWSxDQUFDLGVBQWUsQ0FBQztpQkFDcEQsS0FBSyxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDO2lCQUMzQixPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQztpQkFDMUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ1osSUFBSSxXQUFXLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDO2dCQUMxQyxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNyQyxZQUFZLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsSUFBSSxNQUFNLENBQUMsbUJBQW1CLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDdEYsQ0FBQztRQUNILENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBQ1osQ0FBQztJQUVELElBQUksWUFBWSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ3JCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsNEJBQTRCLEVBQUUsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRCxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUMsQ0FBQztJQUN0RCxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDOUQsTUFBTSxTQUFTLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUM7SUFFaEYsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztJQUNoQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDbkIsYUFBYSxHQUFHLFNBQVMsS0FBSyxDQUFDLEVBQUUsd0JBQXdCLENBQUM7SUFDNUQsQ0FBQztJQUVELHNFQUFzRTtJQUN0RSxJQUFJLFNBQTZCLENBQUM7SUFDbEMsSUFBSSxDQUFDO1FBQ0gsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pELE1BQU0sRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQzdDLE1BQU0sRUFBRSxPQUFPO1lBQ2YsTUFBTSxFQUFFLENBQUMsd0JBQXdCLEVBQUUsNEJBQTRCLENBQUM7WUFDaEUsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUU7U0FDMUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUUvQixNQUFNLE1BQU0sR0FBRyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxtQkFBbUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pELElBQUksTUFBTSxJQUFJLGFBQWEsSUFBSSxPQUFPLGFBQWEsQ0FBQyxvQkFBb0IsS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUN4RixNQUFNLE9BQU8sR0FBRyxNQUFNLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO2dCQUNsRSxXQUFXLEVBQUUsVUFBVTtnQkFDdkIsYUFBYSxFQUFFLFFBQVEsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3JDLE1BQU0sRUFBRSxZQUFZO2dCQUNwQixJQUFJLEVBQUU7b0JBQ0osYUFBYSxFQUFFLFNBQVM7b0JBQ3hCLFNBQVM7aUJBQ1Y7YUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXJCLElBQUksT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDO2dCQUNoQixTQUFTLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUN6QixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBRVYsSUFBSSxDQUFDO1FBQ0gsTUFBTSxXQUFXLEdBQUcsTUFBTSxLQUFLLENBQUMsZ0RBQWdELEVBQUU7WUFDaEYsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUU7Z0JBQ1AsYUFBYSxFQUFFLFVBQVUsU0FBUyxFQUFFO2dCQUNwQyxjQUFjLEVBQUUsa0JBQWtCO2FBQ25DO1lBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLEtBQUssRUFBRSxhQUFhO2dCQUNwQixNQUFNLEVBQUUsY0FBYztnQkFDdEIsUUFBUTtnQkFDUixTQUFTO2dCQUNULFFBQVEsRUFBRTtvQkFDUixRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ2xCLGFBQWEsRUFBRSxZQUFZO29CQUMzQixHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2lCQUNoRDthQUNGLENBQUM7U0FDSCxDQUFDLENBQUM7UUFFSCxNQUFNLFlBQVksR0FBRyxNQUFNLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUU5QyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM1QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixPQUFPLEVBQUUsWUFBWSxDQUFDLE9BQU8sSUFBSSwyQ0FBMkM7Z0JBQzVFLElBQUksRUFBRSxZQUFZO2FBQ25CLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsSUFBSTtZQUNiLGlCQUFpQixFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsaUJBQWlCO1lBQ3RELFdBQVcsRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFDMUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUztZQUN0QyxjQUFjLEVBQUU7Z0JBQ2QsV0FBVyxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVztnQkFDMUMsb0JBQW9CLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXO2FBQ3BEO1lBQ0QsSUFBSSxFQUFFLFlBQVksQ0FBQyxJQUFJO1NBQ3hCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLElBQUkscUNBQXFDO1NBQ2pFLENBQUMsQ0FBQztJQUNMLENBQUM7QUFDSCxDQUFDIn0=