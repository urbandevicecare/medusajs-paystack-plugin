"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = paymentLinkSubscriber;
const utils_1 = require("@medusajs/framework/utils");
const crypto_1 = __importDefault(require("crypto"));
const payment_link_1 = require("../templates/payment-link");
async function paymentLinkSubscriber({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    const query = container.resolve("query");
    logger.info(`[Paystack-Plugin] Checking order.placed event for unpaid balances (Order: ${data.id})`);
    // Retrieve full order data with all item, address, and pricing details
    const { data: orders } = await query.graph({
        entity: "order",
        fields: [
            "id",
            "display_id",
            "email",
            "created_at",
            "currency_code",
            "total",
            "subtotal",
            "shipping_total",
            "discount_total",
            "tax_total",
            "customer.first_name",
            "customer.last_name",
            "customer.email",
            "shipping_address.first_name",
            "shipping_address.last_name",
            "shipping_address.address_1",
            "shipping_address.address_2",
            "shipping_address.city",
            "shipping_address.province",
            "shipping_address.postal_code",
            "shipping_address.country_code",
            "shipping_address.phone",
            "billing_address.first_name",
            "billing_address.last_name",
            "billing_address.phone",
            "items.id",
            "items.title",
            "items.subtitle",
            "items.thumbnail",
            "items.quantity",
            "items.unit_price",
            "payment_collections.captured_amount",
            "payment_collections.amount",
            "payment_collections.payments.amount",
            "payment_collections.payments.captured_at",
            "payment_collections.payments.canceled_at"
        ],
        filters: {
            id: data.id,
        },
    }).catch(err => {
        logger.error(`[Paystack-Plugin] Failed to query order in subscriber: ${err}`);
        return { data: [] };
    });
    if (!orders || orders.length === 0) {
        logger.error(`[Paystack-Plugin] Order ${data.id} not found`);
        return;
    }
    const order = orders[0];
    // Calculate remaining balance: only payments that have actually been captured count as paid
    let capturedAmountRaw = 0;
    if (order.payment_collections) {
        for (const pc of order.payment_collections) {
            if (pc.captured_amount != null) {
                capturedAmountRaw += Number(pc.captured_amount);
            }
            else if (pc.payments) {
                capturedAmountRaw += pc.payments.reduce((acc, p) => {
                    const isPaid = Boolean(p.captured_at) && !p.canceled_at;
                    return acc + (isPaid ? Number(p.amount) : 0);
                }, 0);
            }
        }
    }
    const remainingBalanceRaw = Math.max(0, order.total - capturedAmountRaw);
    if (remainingBalanceRaw <= 0) {
        logger.info(`[Paystack-Plugin] Order ${order.id} is fully paid. No payment link notification needed.`);
        return;
    }
    // Fetch Store Settings
    const { data: stores } = await query.graph({
        entity: "store",
        fields: ["metadata"]
    }).catch(() => ({ data: [] }));
    const storeMeta = stores?.[0]?.metadata || {};
    const configuredStorefrontUrl = storeMeta.paystack_storefront_url;
    const configuredCompanyName = storeMeta.paystack_company_name;
    const dynamicSecret = storeMeta.paystack_secret_key;
    // Generate HMAC hash matching the storefront's secure-link verification
    const secretKey = process.env.MEDUSA_PUBLISHABLE_KEY ||
        process.env.NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY ||
        process.env.MEDUSA_PUBLISHABLE_API_KEY ||
        "super_secret_fallback_key";
    const hash = crypto_1.default.createHmac('sha256', secretKey)
        .update(order.id)
        .digest('hex');
    const storefrontUrl = configuredStorefrontUrl || process.env.STOREFRONT_URL || "http://localhost:5173";
    const paymentLink = `${storefrontUrl}/pay/${hash}/${order.id}`;
    let notificationService = null;
    try {
        notificationService = container.resolve(utils_1.Modules.NOTIFICATION);
    }
    catch {
        try {
            notificationService = container.resolve("notification");
        }
        catch {
            logger.warn("[Paystack-Plugin] Notification module not found in container, skipping payment link notification");
            return;
        }
    }
    const templatePayload = (0, payment_link_1.getPaymentRequiredTemplate)(order, paymentLink, remainingBalanceRaw, configuredCompanyName);
    const notificationSubject = `Action Required: Payment Pending for Order #${order.display_id || order.id}`;
    // 1. Send SMS
    const phone = order.shipping_address?.phone || order.customer?.phone;
    if (phone) {
        try {
            await notificationService.createNotifications({
                to: phone,
                // Some SMS providers use the template field as the actual message body.
                // We fallback to the raw text if PAYSTACK_SMS_TEMPLATE is not explicitly set.
                template: process.env.PAYSTACK_SMS_TEMPLATE || templatePayload.text,
                channel: "sms",
                data: {
                    message: templatePayload.text
                },
            });
            logger.info(`[Paystack-Plugin] Payment link SMS queued for ${phone}`);
        }
        catch (e) {
            logger.error(`[Paystack-Plugin] Failed to send SMS to ${phone}: ${e.message}`);
        }
    }
    else {
        logger.info(`[Paystack-Plugin] No phone number found for order ${order.id}, skipping SMS`);
    }
    // 2. Send Email
    if (order.email) {
        try {
            await notificationService.createNotifications({
                to: order.email,
                template: "paystack-payment-required",
                channel: "email",
                content: {
                    subject: notificationSubject,
                    html: templatePayload.html,
                },
                data: {
                    order_id: order.id,
                    display_id: order.display_id,
                    remaining_balance: remainingBalanceRaw,
                    total: order.total,
                    currency_code: order.currency_code,
                    payment_link: paymentLink,
                    message: templatePayload.text
                },
            });
            logger.info(`[Paystack-Plugin] Payment link Email queued for ${order.email}`);
        }
        catch (e) {
            logger.error(`[Paystack-Plugin] Failed to send Email to ${order.email}: ${e.message}`);
        }
    }
    // 3. Send WhatsApp
    if (phone) {
        try {
            await notificationService.createNotifications({
                to: phone,
                channel: "whatsapp",
                template: process.env.PAYSTACK_WHATSAPP_TEMPLATE || "paystack-payment-required-whatsapp",
                data: {
                    message: templatePayload.text,
                    payment_link: paymentLink,
                    order_id: order.id,
                    display_id: order.display_id,
                    remaining_balance: remainingBalanceRaw,
                    currency_code: order.currency_code,
                },
            });
            logger.info(`[Paystack-Plugin] Payment link WhatsApp queued for ${phone}`);
        }
        catch (e) {
            logger.error(`[Paystack-Plugin] Failed to send WhatsApp to ${phone}: ${e.message}`);
        }
    }
}
exports.config = {
    event: "order.placed",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5bWVudC1saW5rLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3BheW1lbnQtbGluay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSx3Q0FxTUM7QUF6TUQscURBQW1EO0FBQ25ELG9EQUEyQjtBQUMzQiw0REFBc0U7QUFFdkQsS0FBSyxVQUFVLHFCQUFxQixDQUFDLEVBQ2xELEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUNmLFNBQVMsR0FDc0I7SUFDL0IsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUMxQyxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBRXhDLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkVBQTZFLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO0lBRXBHLHVFQUF1RTtJQUN2RSxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QyxNQUFNLEVBQUUsT0FBTztRQUNmLE1BQU0sRUFBRTtZQUNOLElBQUk7WUFDSixZQUFZO1lBQ1osT0FBTztZQUNQLFlBQVk7WUFDWixlQUFlO1lBQ2YsT0FBTztZQUNQLFVBQVU7WUFDVixnQkFBZ0I7WUFDaEIsZ0JBQWdCO1lBQ2hCLFdBQVc7WUFDWCxxQkFBcUI7WUFDckIsb0JBQW9CO1lBQ3BCLGdCQUFnQjtZQUNoQiw2QkFBNkI7WUFDN0IsNEJBQTRCO1lBQzVCLDRCQUE0QjtZQUM1Qiw0QkFBNEI7WUFDNUIsdUJBQXVCO1lBQ3ZCLDJCQUEyQjtZQUMzQiw4QkFBOEI7WUFDOUIsK0JBQStCO1lBQy9CLHdCQUF3QjtZQUN4Qiw0QkFBNEI7WUFDNUIsMkJBQTJCO1lBQzNCLHVCQUF1QjtZQUN2QixVQUFVO1lBQ1YsYUFBYTtZQUNiLGdCQUFnQjtZQUNoQixpQkFBaUI7WUFDakIsZ0JBQWdCO1lBQ2hCLGtCQUFrQjtZQUNsQixxQ0FBcUM7WUFDckMsNEJBQTRCO1lBQzVCLHFDQUFxQztZQUNyQywwQ0FBMEM7WUFDMUMsMENBQTBDO1NBQzNDO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1NBQ1o7S0FDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ2IsTUFBTSxDQUFDLEtBQUssQ0FBQywwREFBMEQsR0FBRyxFQUFFLENBQUMsQ0FBQTtRQUM3RSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFBO0lBQ3JCLENBQUMsQ0FBQyxDQUFBO0lBRUYsSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ25DLE1BQU0sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLElBQUksQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFBO1FBQzVELE9BQU07SUFDUixDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRXZCLDRGQUE0RjtJQUM1RixJQUFJLGlCQUFpQixHQUFHLENBQUMsQ0FBQztJQUMxQixJQUFJLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzlCLEtBQUssTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDLG1CQUE0QixFQUFFLENBQUM7WUFDcEQsSUFBSSxFQUFFLENBQUMsZUFBZSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUMvQixpQkFBaUIsSUFBSSxNQUFNLENBQUMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2xELENBQUM7aUJBQU0sSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ3ZCLGlCQUFpQixJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBVyxFQUFFLENBQU0sRUFBRSxFQUFFO29CQUM5RCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztvQkFDeEQsT0FBTyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDUixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFHLEtBQUssQ0FBQyxLQUFnQixHQUFHLGlCQUFpQixDQUFDLENBQUM7SUFFckYsSUFBSSxtQkFBbUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLDJCQUEyQixLQUFLLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO1FBQ3ZHLE9BQU87SUFDVCxDQUFDO0lBRUQsdUJBQXVCO0lBQ3ZCLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3pDLE1BQU0sRUFBRSxPQUFPO1FBQ2YsTUFBTSxFQUFFLENBQUMsVUFBVSxDQUFDO0tBQ3JCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUE7SUFFOUIsTUFBTSxTQUFTLEdBQUcsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxJQUFJLEVBQUUsQ0FBQTtJQUM3QyxNQUFNLHVCQUF1QixHQUFHLFNBQVMsQ0FBQyx1QkFBNkMsQ0FBQTtJQUN2RixNQUFNLHFCQUFxQixHQUFHLFNBQVMsQ0FBQyxxQkFBMkMsQ0FBQTtJQUNuRixNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsbUJBQXlDLENBQUE7SUFFekUsd0VBQXdFO0lBQ3hFLE1BQU0sU0FBUyxHQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCO1FBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDO1FBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCO1FBQ3RDLDJCQUEyQixDQUFDO0lBRTlCLE1BQU0sSUFBSSxHQUFHLGdCQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUM7U0FDaEQsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7U0FDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRWpCLE1BQU0sYUFBYSxHQUFHLHVCQUF1QixJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLHVCQUF1QixDQUFBO0lBQ3RHLE1BQU0sV0FBVyxHQUFHLEdBQUcsYUFBYSxRQUFRLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUE7SUFFOUQsSUFBSSxtQkFBbUIsR0FBUSxJQUFJLENBQUM7SUFDcEMsSUFBSSxDQUFDO1FBQ0gsbUJBQW1CLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUFDLE1BQU0sQ0FBQztRQUNQLElBQUksQ0FBQztZQUNILG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUFDLE1BQU0sQ0FBQztZQUNQLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0dBQWtHLENBQUMsQ0FBQztZQUNoSCxPQUFPO1FBQ1QsQ0FBQztJQUNILENBQUM7SUFFRCxNQUFNLGVBQWUsR0FBRyxJQUFBLHlDQUEwQixFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsbUJBQW1CLEVBQUUscUJBQXFCLENBQUMsQ0FBQTtJQUNsSCxNQUFNLG1CQUFtQixHQUFHLCtDQUErQyxLQUFLLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQTtJQUV6RyxjQUFjO0lBQ2QsTUFBTSxLQUFLLEdBQUksS0FBSyxDQUFDLGdCQUF3QixFQUFFLEtBQUssSUFBSyxLQUFhLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQTtJQUN0RixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ1YsSUFBSSxDQUFDO1lBQ0gsTUFBTSxtQkFBbUIsQ0FBQyxtQkFBbUIsQ0FBQztnQkFDNUMsRUFBRSxFQUFFLEtBQUs7Z0JBQ1Qsd0VBQXdFO2dCQUN4RSw4RUFBOEU7Z0JBQzlFLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixJQUFJLGVBQWUsQ0FBQyxJQUFJO2dCQUNuRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUU7b0JBQ0osT0FBTyxFQUFFLGVBQWUsQ0FBQyxJQUFJO2lCQUM5QjthQUNGLENBQUMsQ0FBQTtZQUNGLE1BQU0sQ0FBQyxJQUFJLENBQUMsaURBQWlELEtBQUssRUFBRSxDQUFDLENBQUE7UUFDdkUsQ0FBQztRQUFDLE9BQU8sQ0FBTSxFQUFFLENBQUM7WUFDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQywyQ0FBMkMsS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO1FBQ2hGLENBQUM7SUFDSCxDQUFDO1NBQU0sQ0FBQztRQUNOLE1BQU0sQ0FBQyxJQUFJLENBQUMscURBQXFELEtBQUssQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUE7SUFDNUYsQ0FBQztJQUVELGdCQUFnQjtJQUNoQixJQUFJLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUM7WUFDSCxNQUFNLG1CQUFtQixDQUFDLG1CQUFtQixDQUFDO2dCQUM1QyxFQUFFLEVBQUUsS0FBSyxDQUFDLEtBQWU7Z0JBQ3pCLFFBQVEsRUFBRSwyQkFBMkI7Z0JBQ3JDLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUU7b0JBQ1AsT0FBTyxFQUFFLG1CQUFtQjtvQkFDNUIsSUFBSSxFQUFFLGVBQWUsQ0FBQyxJQUFJO2lCQUMzQjtnQkFDRCxJQUFJLEVBQUU7b0JBQ0osUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFO29CQUNsQixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7b0JBQzVCLGlCQUFpQixFQUFFLG1CQUFtQjtvQkFDdEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO29CQUNsQixhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7b0JBQ2xDLFlBQVksRUFBRSxXQUFXO29CQUN6QixPQUFPLEVBQUUsZUFBZSxDQUFDLElBQUk7aUJBQzlCO2FBQ0YsQ0FBQyxDQUFBO1lBQ0YsTUFBTSxDQUFDLElBQUksQ0FBQyxtREFBbUQsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7UUFDL0UsQ0FBQztRQUFDLE9BQU8sQ0FBTSxFQUFFLENBQUM7WUFDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyw2Q0FBNkMsS0FBSyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtRQUN4RixDQUFDO0lBQ0gsQ0FBQztJQUVELG1CQUFtQjtJQUNuQixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ1YsSUFBSSxDQUFDO1lBQ0gsTUFBTSxtQkFBbUIsQ0FBQyxtQkFBbUIsQ0FBQztnQkFDNUMsRUFBRSxFQUFFLEtBQUs7Z0JBQ1QsT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixJQUFJLG9DQUFvQztnQkFDeEYsSUFBSSxFQUFFO29CQUNKLE9BQU8sRUFBRSxlQUFlLENBQUMsSUFBSTtvQkFDN0IsWUFBWSxFQUFFLFdBQVc7b0JBQ3pCLFFBQVEsRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDbEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO29CQUM1QixpQkFBaUIsRUFBRSxtQkFBbUI7b0JBQ3RDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtpQkFDbkM7YUFDRixDQUFDLENBQUE7WUFDRixNQUFNLENBQUMsSUFBSSxDQUFDLHNEQUFzRCxLQUFLLEVBQUUsQ0FBQyxDQUFBO1FBQzVFLENBQUM7UUFBQyxPQUFPLENBQU0sRUFBRSxDQUFDO1lBQ2hCLE1BQU0sQ0FBQyxLQUFLLENBQUMsZ0RBQWdELEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtRQUNyRixDQUFDO0lBQ0gsQ0FBQztBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBcUI7SUFDdEMsS0FBSyxFQUFFLGNBQWM7Q0FDdEIsQ0FBQSJ9