"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = __importDefault(require("crypto"));
const paystack_client_1 = __importDefault(require("./services/paystack-client"));
const currency_1 = require("./utils/currency");
const utils_1 = require("@medusajs/framework/utils");
const reconcile_payment_1 = require("./utils/reconcile-payment");
class PaystackPaymentProvider extends utils_1.AbstractPaymentProvider {
    // IMPORTANT: Leave this generic. Medusa V2 resolves multiple accounts by concatenating the config 'id' with this static identifier.
    // E.g. Config id "apple_4all" + identifier "paystack" = "apple_4all_paystack"
    static identifier = "paystack";
    configuration;
    paystack;
    debug;
    container;
    static validateOptions(options) {
        const secretKey = options?.secret_key ||
            options?.secretKey ||
            options?.apiKey ||
            process.env.PAYSTACK_SECRET_KEY ||
            process.env.PAYSTACK_SECRET_KEY_URBANDEVICECARE ||
            process.env.PAYSTACK_TEST_SECRET_KEY ||
            process.env.PAYSTACK_KEY;
        // We no longer strictly enforce secretKey at startup because it could be configured dynamically in the dashboard later
    }
    constructor(container, options) {
        super(container, options);
        this.container = container;
        const secretKey = (0, currency_1.resolvePaystackSecretKey)(options?.secret_key || options?.secretKey || options?.apiKey) ||
            "DUMMY_KEY_PENDING_CONFIG";
        this.configuration = { ...options, secret_key: secretKey };
        this.paystack = new paystack_client_1.default(secretKey);
        this.debug = Boolean(options.debug);
    }
    async getClient() {
        let dynamicSecret;
        try {
            if (this.container && this.container.query) {
                const query = this.container.query;
                const { data: stores } = await query.graph({
                    entity: "store",
                    fields: ["metadata"]
                }).catch(() => ({ data: [] }));
                dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key;
            }
            if (!dynamicSecret && this.container) {
                const storeService = this.container.resolve ? this.container.resolve(utils_1.Modules.STORE) : null;
                if (storeService && typeof storeService.listStores === "function") {
                    const stores = await storeService.listStores({}, { take: 1 });
                    dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key;
                }
            }
        }
        catch (err) {
            if (this.debug)
                console.warn("Failed to fetch dynamic paystack secret from store:", err);
        }
        const resolvedSecret = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret || this.configuration.secret_key);
        if (resolvedSecret) {
            return new paystack_client_1.default(resolvedSecret);
        }
        if (this.configuration.secret_key === "DUMMY_KEY_PENDING_CONFIG") {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_ARGUMENT, "Paystack Secret Key is missing. Please configure it in the Admin Dashboard Settings or via environment variables.");
        }
        return this.paystack;
    }
    async initiatePayment(input) {
        if (this.debug) {
            console.info("PS_P_Debug: InitiatePayment", JSON.stringify(input, null, 2));
        }
        const client = await this.getClient();
        const { data, amount, currency_code } = input;
        const contextAny = input.context;
        const email = data?.email ||
            contextAny?.email ||
            contextAny?.customer?.email ||
            contextAny?.billing_address?.email ||
            contextAny?.account_holder?.data?.email;
        const session_id = data?.session_id;
        // In Medusa v2 checkout, payment sessions can be initialized before a guest customer enters their email.
        // Return a pending session placeholder so cart creation succeeds; updatePayment will initialize with Paystack once email is provided.
        if (!email && !data?.stk_push) {
            return {
                id: session_id || `ps_pending_${Date.now()}`,
                status: utils_1.PaymentSessionStatus.PENDING,
                data: {
                    ...data,
                    emailPending: true,
                },
            };
        }
        try {
            const paystackAmount = (0, currency_1.getPaystackAmount)(Number(amount), currency_code);
            if (data?.stk_push) {
                // Skip calling Paystack's initialize endpoint if this is an STK Push.
                // The STK Push route handles the actual Paystack charge creation.
                return {
                    id: data.paystackTxRef || `stk_${Date.now()}`,
                    status: utils_1.PaymentSessionStatus.PENDING_AUTHORIZATION,
                    data: {
                        ...data,
                        paystackTxRef: data.paystackTxRef,
                    },
                };
            }
            // Generate Custom Reference
            const randomSuffix = Math.floor(10000 + Math.random() * 90000);
            const resourceId = contextAny?.resource_id || data?.session_id || contextAny?.payment_collection?.id || "";
            const displayId = data?.display_id || contextAny?.order?.display_id || contextAny?.payment_collection?.order?.display_id || "";
            let customReference = "";
            if (resourceId.startsWith("order_")) {
                const strippedId = resourceId.replace("order_", "");
                customReference = displayId ? `${displayId}-${strippedId}-${randomSuffix}` : `${strippedId}-${randomSuffix}`;
            }
            else if (resourceId.startsWith("cart_")) {
                const strippedId = resourceId.replace("cart_", "");
                customReference = `${strippedId}-${randomSuffix}`;
            }
            else if (resourceId) {
                const strippedId = resourceId.replace(/^(cart_|order_|paycol_)/, "");
                customReference = displayId ? `${displayId}-${strippedId}-${randomSuffix}` : `${strippedId}-${randomSuffix}`;
            }
            else {
                customReference = `ref-${Date.now()}-${randomSuffix}`;
            }
            const response = await client.transaction.initialize({
                amount: paystackAmount,
                email: email,
                currency: (currency_code || "NGN").toUpperCase(),
                reference: customReference,
                metadata: {
                    session_id,
                    ...data,
                },
            });
            if (!response.status) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to initiate Paystack payment", response.message);
            }
            return {
                id: response.data.reference,
                status: utils_1.PaymentSessionStatus.PENDING,
                data: {
                    paystackTxRef: response.data.reference,
                    paystackTxAccessCode: response.data.access_code,
                    paystackTxAuthorizationUrl: response.data.authorization_url,
                },
            };
        }
        catch (error) {
            if (this.debug)
                console.error("PS_P_Debug: InitiatePayment: Error", error);
            const errMsg = error?.response?.data?.message || error?.message || error?.toString() || "Unknown error";
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to initiate Paystack payment", errMsg);
        }
    }
    async updatePayment(input) {
        if (this.debug)
            console.info("PS_P_Debug: UpdatePayment", JSON.stringify(input, null, 2));
        // Paystack doesn't support updating transaction amounts. 
        // We abandon the current one and create a new one.
        const session = await this.initiatePayment(input);
        return {
            data: session.data,
            status: session.status,
        };
    }
    async authorizePayment(input) {
        if (this.debug)
            console.info("PS_P_Debug: AuthorizePayment", JSON.stringify(input, null, 2));
        const client = await this.getClient();
        try {
            const sessionData = (input.data || {});
            const paystackTxRef = sessionData.paystackTxRef || sessionData.reference;
            if (!paystackTxRef) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Missing paystackTxRef in payment data.");
            }
            const response = await client.transaction.verify({ reference: paystackTxRef });
            if (!response.status) {
                return {
                    status: utils_1.PaymentSessionStatus.ERROR,
                    data: { ...input.data, paystackTxId: response.data?.id, paystackTxData: response.data },
                };
            }
            switch (response.data.status) {
                case "success":
                    return {
                        status: utils_1.PaymentSessionStatus.CAPTURED,
                        data: {
                            ...input.data,
                            paystackTxId: response.data.id,
                            paystackTxData: response.data,
                        },
                    };
                case "failed":
                    return {
                        status: utils_1.PaymentSessionStatus.ERROR,
                        data: { ...input.data, paystackTxId: response.data?.id, paystackTxData: response.data },
                    };
                case "pay_offline":
                case "pending":
                    return {
                        status: utils_1.PaymentSessionStatus.PENDING_AUTHORIZATION,
                        data: { ...input.data, paystackTxId: response.data?.id, paystackTxData: response.data },
                    };
                default:
                    return {
                        status: utils_1.PaymentSessionStatus.PENDING,
                        data: { ...input.data, paystackTxId: response.data?.id, paystackTxData: response.data },
                    };
            }
        }
        catch (error) {
            if (this.debug)
                console.error("PS_P_Debug: AuthorizePayment: Error", error);
            const errMsg = error?.response?.data?.message || error?.message || error?.toString() || "Unknown error";
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to authorize payment", errMsg);
        }
    }
    async retrievePayment(input) {
        if (this.debug)
            console.info("PS_P_Debug: RetrievePayment", JSON.stringify(input, null, 2));
        const client = await this.getClient();
        try {
            const { paystackTxId, paystackTxRef } = input.data;
            if (!paystackTxId && !paystackTxRef) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Missing paystackTxId or paystackTxRef in payment data.");
            }
            const response = paystackTxId
                ? await client.transaction.get({ id: paystackTxId })
                : await client.transaction.verify({ reference: paystackTxRef });
            if (!response.status) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to retrieve payment", response.message);
            }
            return {
                data: {
                    ...input.data,
                    paystackTxData: response.data,
                },
            };
        }
        catch (error) {
            if (this.debug)
                console.error("PS_P_Debug: RetrievePayment: Error", error);
            const errMsg = error?.response?.data?.message || error?.message || error?.toString() || "Unknown error";
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to retrieve payment", errMsg);
        }
    }
    async refundPayment(input) {
        if (this.debug)
            console.info("PS_P_Debug: RefundPayment", JSON.stringify(input, null, 2));
        const client = await this.getClient();
        try {
            const { paystackTxId, paystackTxRef } = input.data;
            if (!paystackTxId && !paystackTxRef) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Missing paystackTxId or paystackTxRef in payment data.");
            }
            const currency = input.data?.paystackTxData?.currency || "NGN";
            const paystackAmount = (0, currency_1.getPaystackAmount)(Number(input.amount), currency);
            const originalAmount = Number(input.data?.paystackTxData?.amount);
            if (originalAmount && paystackAmount > originalAmount) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `Cannot refund an amount greater than the original transaction amount.`);
            }
            const response = await client.refund.create({
                transaction: String(paystackTxId || paystackTxRef),
                amount: paystackAmount,
            });
            if (!response.status) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to refund payment", response.message);
            }
            return {
                data: {
                    ...input.data,
                    paystackRefundData: response.data,
                },
            };
        }
        catch (error) {
            if (this.debug)
                console.error("PS_P_Debug: RefundPayment: Error", error);
            const errMsg = error?.response?.data?.message || error?.message || error?.toString() || "Unknown error";
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "Failed to refund payment", errMsg);
        }
    }
    async getPaymentStatus(input) {
        if (this.debug)
            console.info("PS_P_Debug: GetPaymentStatus", JSON.stringify(input, null, 2));
        const client = await this.getClient();
        const { paystackTxId, paystackTxRef } = input.data;
        if (!paystackTxId && !paystackTxRef) {
            return { status: utils_1.PaymentSessionStatus.PENDING };
        }
        try {
            const response = paystackTxId
                ? await client.transaction.get({ id: paystackTxId })
                : await client.transaction.verify({ reference: paystackTxRef });
            if (!response.status) {
                return { status: utils_1.PaymentSessionStatus.ERROR };
            }
            switch (response.data?.status) {
                case "success":
                    return { status: utils_1.PaymentSessionStatus.CAPTURED };
                case "failed":
                    return { status: utils_1.PaymentSessionStatus.ERROR };
                case "abandoned":
                    return { status: utils_1.PaymentSessionStatus.CANCELED };
                case "pay_offline":
                case "pending":
                    return { status: utils_1.PaymentSessionStatus.PENDING_AUTHORIZATION };
                default:
                    return { status: utils_1.PaymentSessionStatus.PENDING };
            }
        }
        catch (error) {
            if (this.debug)
                console.error("PS_P_Debug: GetPaymentStatus: Error", error);
            return { status: utils_1.PaymentSessionStatus.ERROR };
        }
    }
    async getWebhookActionAndData(payload) {
        if (this.debug)
            console.info("PS_P_Debug: Webhook", JSON.stringify(payload, null, 2));
        const { data: rawPayloadData, rawData, headers } = (payload || {});
        let dynamicSecret = this.configuration.secret_key;
        try {
            if (this.container && this.container.query) {
                const query = this.container.query;
                const { data: stores } = await query.graph({
                    entity: "store",
                    fields: ["metadata"]
                }).catch(() => ({ data: [] }));
                if (stores?.[0]?.metadata?.paystack_secret_key) {
                    dynamicSecret = stores[0].metadata.paystack_secret_key;
                }
            }
        }
        catch (e) {
            if (this.debug)
                console.warn("Failed to fetch dynamic secret for webhook:", e);
        }
        const webhookSecretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
        if (!webhookSecretKey) {
            return { action: utils_1.PaymentActions.NOT_SUPPORTED };
        }
        const signature = (headers?.["x-paystack-signature"] || headers?.["X-Paystack-Signature"]);
        if (!signature) {
            if (this.debug)
                console.error("PS_P_Debug: Webhook missing signature header");
            return { action: utils_1.PaymentActions.NOT_SUPPORTED };
        }
        const rawPayload = typeof rawData === "string" || Buffer.isBuffer(rawData)
            ? rawData
            : JSON.stringify(rawPayloadData || {});
        const hash = crypto_1.default
            .createHmac("sha512", webhookSecretKey)
            .update(rawPayload)
            .digest("hex");
        let isSignatureValid = false;
        try {
            const hashBuf = Buffer.from(hash, "hex");
            const sigBuf = Buffer.from(signature, "hex");
            isSignatureValid = hashBuf.length === sigBuf.length && crypto_1.default.timingSafeEqual(hashBuf, sigBuf);
        }
        catch {
            isSignatureValid = hash === signature;
        }
        if (!isSignatureValid) {
            if (this.debug)
                console.error("PS_P_Debug: Webhook signature mismatch");
            return {
                action: utils_1.PaymentActions.NOT_SUPPORTED,
            };
        }
        const body = (rawPayloadData || {});
        const event = body.event;
        const eventData = body.data || {};
        let sessionId = eventData.metadata?.session_id || undefined;
        const orderId = eventData.metadata?.order_id || undefined;
        if (!sessionId && orderId && this.container) {
            try {
                const query = this.container.query;
                if (query) {
                    const { data: sessions } = await query.graph({
                        entity: "payment_session",
                        fields: ["id", "provider_id", "data"],
                        filters: {
                            payment_collection: {
                                order: { id: orderId }
                            }
                        }
                    }).catch(() => ({ data: [] }));
                    const matched = sessions?.find((s) => s.provider_id?.includes("paystack") ||
                        s.data?.paystackTxRef === eventData.reference ||
                        s.data?.reference === eventData.reference) || sessions?.[0];
                    if (matched?.id) {
                        sessionId = matched.id;
                    }
                }
            }
            catch (err) {
                if (this.debug)
                    console.warn("PS_P_Debug: Error locating session for webhook order:", err);
            }
        }
        const currency = eventData.currency || "NGN";
        const medusaAmount = (0, currency_1.getMedusaAmount)(Number(eventData.amount || 0), currency);
        const ticketId = eventData.metadata?.ticket_id || eventData.metadata?.ticketId || undefined;
        const ref = eventData.reference || "";
        const isRepairTx = Boolean(ticketId || ref.startsWith("REP-") || ref.startsWith("rep-"));
        if (event === "charge.success" && this.container) {
            if (orderId) {
                try {
                    await (0, reconcile_payment_1.reconcileAndCapturePaystackPayment)({
                        container: this.container,
                        orderId,
                        reference: eventData.reference,
                        amount: medusaAmount,
                        currency,
                    });
                }
                catch (err) {
                    if (this.debug)
                        console.warn("PS_P_Debug: Error in webhook auto-reconcile:", err);
                }
            }
            if (isRepairTx) {
                try {
                    await (0, reconcile_payment_1.reconcilePaystackRepairPayment)({
                        container: this.container,
                        ticketId,
                        reference: eventData.reference,
                        amount: medusaAmount,
                    });
                }
                catch (err) {
                    if (this.debug)
                        console.warn("PS_P_Debug: Error in repair webhook auto-reconcile:", err);
                }
            }
        }
        if (!sessionId) {
            if (this.debug && !isRepairTx)
                console.warn("PS_P_Debug: Webhook event missing session_id in metadata");
            return {
                action: utils_1.PaymentActions.NOT_SUPPORTED,
            };
        }
        if (event === "charge.success") {
            console.info(`[Paystack Webhook] Received charge.success for reference: ${eventData.reference} (Session: ${sessionId})`);
            return {
                action: utils_1.PaymentActions.SUCCESSFUL,
                data: {
                    session_id: sessionId,
                    amount: medusaAmount,
                },
            };
        }
        if (event === "charge.failed") {
            console.info(`[Paystack Webhook] Received charge.failed for reference: ${eventData.reference} (Session: ${sessionId})`);
            return {
                action: utils_1.PaymentActions.FAILED,
                data: {
                    session_id: sessionId,
                    amount: medusaAmount,
                },
            };
        }
        return {
            action: utils_1.PaymentActions.NOT_SUPPORTED,
        };
    }
    async capturePayment(input) {
        return { data: input.data };
    }
    async cancelPayment(input) {
        return { data: input.data };
    }
    async deletePayment(input) {
        return { data: input.data };
    }
}
exports.default = PaystackPaymentProvider;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5c3RhY2stcHJvdmlkZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvcHJvdmlkZXJzL3BheXN0YWNrL3BheXN0YWNrLXByb3ZpZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsb0RBQTRCO0FBRTVCLGlGQUF3RDtBQUN4RCwrQ0FBZ0c7QUF3QmhHLHFEQU1tQztBQUNuQyxpRUFBK0c7QUFvQi9HLE1BQU0sdUJBQXdCLFNBQVEsK0JBQXVEO0lBQzNGLG9JQUFvSTtJQUNwSSw4RUFBOEU7SUFDOUUsTUFBTSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7SUFFWixhQUFhLENBQWlDO0lBQzlDLFFBQVEsQ0FBaUI7SUFDekIsS0FBSyxDQUFVO0lBQ2YsU0FBUyxDQUFNO0lBRWxDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBdUM7UUFDNUQsTUFBTSxTQUFTLEdBQ2IsT0FBTyxFQUFFLFVBQVU7WUFDbEIsT0FBZSxFQUFFLFNBQVM7WUFDMUIsT0FBZSxFQUFFLE1BQU07WUFDeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7WUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUM7WUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0I7WUFDcEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFM0IsdUhBQXVIO0lBQ3pILENBQUM7SUFFRCxZQUNFLFNBQWtDLEVBQ2xDLE9BQXVDO1FBRXZDLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFFM0IsTUFBTSxTQUFTLEdBQ2IsSUFBQSxtQ0FBd0IsRUFBQyxPQUFPLEVBQUUsVUFBVSxJQUFLLE9BQWUsRUFBRSxTQUFTLElBQUssT0FBZSxFQUFFLE1BQU0sQ0FBQztZQUN4RywwQkFBMEIsQ0FBQztRQUU3QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsR0FBRyxPQUFPLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSx5QkFBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRVMsS0FBSyxDQUFDLFNBQVM7UUFDdkIsSUFBSSxhQUFpQyxDQUFDO1FBQ3RDLElBQUksQ0FBQztZQUNILElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUMzQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQVksQ0FBQztnQkFDMUMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7b0JBQ3pDLE1BQU0sRUFBRSxPQUFPO29CQUNmLE1BQU0sRUFBRSxDQUFDLFVBQVUsQ0FBQztpQkFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFL0IsYUFBYSxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQztZQUM3RCxDQUFDO1lBQ0QsSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3JDLE1BQU0sWUFBWSxHQUFJLElBQUksQ0FBQyxTQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUUsSUFBSSxDQUFDLFNBQWlCLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUM3RyxJQUFJLFlBQVksSUFBSSxPQUFPLFlBQVksQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUM7b0JBQ2xFLE1BQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDOUQsYUFBYSxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQztnQkFDN0QsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxxREFBcUQsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzRixDQUFDO1FBRUQsTUFBTSxjQUFjLEdBQUcsSUFBQSxtQ0FBd0IsRUFBQyxhQUFhLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNoRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSx5QkFBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzVDLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxLQUFLLDBCQUEwQixFQUFFLENBQUM7WUFDakUsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUNsQyxtSEFBbUgsQ0FDcEgsQ0FBQztRQUNKLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDdkIsQ0FBQztJQUVELEtBQUssQ0FBQyxlQUFlLENBQ25CLEtBQTJCO1FBRTNCLElBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5RSxDQUFDO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFdEMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLEdBQUcsS0FBSyxDQUFDO1FBQzlDLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxPQUFjLENBQUM7UUFDeEMsTUFBTSxLQUFLLEdBQ1IsSUFBSSxFQUFFLEtBQWdCO1lBQ3RCLFVBQVUsRUFBRSxLQUFnQjtZQUM1QixVQUFVLEVBQUUsUUFBUSxFQUFFLEtBQWdCO1lBQ3RDLFVBQVUsRUFBRSxlQUFlLEVBQUUsS0FBZ0I7WUFDN0MsVUFBVSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsS0FBZ0IsQ0FBQztRQUN0RCxNQUFNLFVBQVUsR0FBRyxJQUFJLEVBQUUsVUFBZ0MsQ0FBQztRQUUxRCx5R0FBeUc7UUFDekcsc0lBQXNJO1FBQ3RJLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUM7WUFDOUIsT0FBTztnQkFDTCxFQUFFLEVBQUUsVUFBVSxJQUFJLGNBQWMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUM1QyxNQUFNLEVBQUUsNEJBQW9CLENBQUMsT0FBTztnQkFDcEMsSUFBSSxFQUFFO29CQUNKLEdBQUcsSUFBSTtvQkFDUCxZQUFZLEVBQUUsSUFBSTtpQkFDWjthQUNULENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxjQUFjLEdBQUcsSUFBQSw0QkFBaUIsRUFBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUM7WUFFeEUsSUFBSSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUM7Z0JBQ25CLHNFQUFzRTtnQkFDdEUsa0VBQWtFO2dCQUNsRSxPQUFPO29CQUNMLEVBQUUsRUFBRyxJQUFJLENBQUMsYUFBd0IsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtvQkFDekQsTUFBTSxFQUFFLDRCQUFvQixDQUFDLHFCQUFxQjtvQkFDbEQsSUFBSSxFQUFFO3dCQUNKLEdBQUcsSUFBSTt3QkFDUCxhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQXVCO3FCQUNOO2lCQUN4QyxDQUFDO1lBQ0osQ0FBQztZQUVELDRCQUE0QjtZQUM1QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUM7WUFDL0QsTUFBTSxVQUFVLEdBQUksVUFBVSxFQUFFLFdBQXNCLElBQUssSUFBSSxFQUFFLFVBQXFCLElBQUssVUFBVSxFQUFFLGtCQUFrQixFQUFFLEVBQWEsSUFBSSxFQUFFLENBQUM7WUFDL0ksTUFBTSxTQUFTLEdBQUcsSUFBSSxFQUFFLFVBQVUsSUFBSSxVQUFVLEVBQUUsS0FBSyxFQUFFLFVBQVUsSUFBSSxVQUFVLEVBQUUsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLFVBQVUsSUFBSSxFQUFFLENBQUM7WUFFL0gsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO2dCQUNwQyxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDcEQsZUFBZSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUMvRyxDQUFDO2lCQUFNLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO2dCQUMxQyxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDbkQsZUFBZSxHQUFHLEdBQUcsVUFBVSxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ3BELENBQUM7aUJBQU0sSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDckUsZUFBZSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLElBQUksVUFBVSxJQUFJLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUMvRyxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sZUFBZSxHQUFHLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ3hELENBQUM7WUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE1BQU0sQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO2dCQUNuRCxNQUFNLEVBQUUsY0FBYztnQkFDdEIsS0FBSyxFQUFFLEtBQWU7Z0JBQ3RCLFFBQVEsRUFBRSxDQUFDLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQ2hELFNBQVMsRUFBRSxlQUFlO2dCQUMxQixRQUFRLEVBQUU7b0JBQ1IsVUFBVTtvQkFDVixHQUFHLElBQUk7aUJBQ1I7YUFDRixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNyQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQ2xDLHFDQUFxQyxFQUNyQyxRQUFRLENBQUMsT0FBTyxDQUNqQixDQUFDO1lBQ0osQ0FBQztZQUVELE9BQU87Z0JBQ0wsRUFBRSxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUztnQkFDM0IsTUFBTSxFQUFFLDRCQUFvQixDQUFDLE9BQU87Z0JBQ3BDLElBQUksRUFBRTtvQkFDSixhQUFhLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTO29CQUN0QyxvQkFBb0IsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVc7b0JBQy9DLDBCQUEwQixFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsaUJBQWlCO2lCQUNmO2FBQy9DLENBQUM7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztZQUNwQixJQUFJLElBQUksQ0FBQyxLQUFLO2dCQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDM0UsTUFBTSxNQUFNLEdBQUcsS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsT0FBTyxJQUFJLEtBQUssRUFBRSxPQUFPLElBQUksS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLGVBQWUsQ0FBQztZQUN4RyxNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQ2xDLHFDQUFxQyxFQUNyQyxNQUFNLENBQ1AsQ0FBQztRQUNKLENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQywyQkFBMkIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUxRiwwREFBMEQ7UUFDMUQsbURBQW1EO1FBQ25ELE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVsRCxPQUFPO1lBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtTQUN2QixDQUFDO0lBQ0osQ0FBQztJQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FDcEIsS0FBNEI7UUFFNUIsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsOEJBQThCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFN0YsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFdEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxXQUFXLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBUSxDQUFDO1lBQzlDLE1BQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxhQUFhLElBQUksV0FBVyxDQUFDLFNBQVMsQ0FBQztZQUV6RSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ25CLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLHdDQUF3QyxDQUN6QyxDQUFDO1lBQ0osQ0FBQztZQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQztZQUUvRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNyQixPQUFPO29CQUNMLE1BQU0sRUFBRSw0QkFBb0IsQ0FBQyxLQUFLO29CQUNsQyxJQUFJLEVBQUUsRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFO2lCQUN4RixDQUFDO1lBQ0osQ0FBQztZQUVELFFBQVEsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDN0IsS0FBSyxTQUFTO29CQUNaLE9BQU87d0JBQ0wsTUFBTSxFQUFFLDRCQUFvQixDQUFDLFFBQVE7d0JBQ3JDLElBQUksRUFBRTs0QkFDSixHQUFHLEtBQUssQ0FBQyxJQUFJOzRCQUNiLFlBQVksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQzlCLGNBQWMsRUFBRSxRQUFRLENBQUMsSUFBSTt5QkFDOUI7cUJBQ0YsQ0FBQztnQkFDSixLQUFLLFFBQVE7b0JBQ1gsT0FBTzt3QkFDTCxNQUFNLEVBQUUsNEJBQW9CLENBQUMsS0FBSzt3QkFDbEMsSUFBSSxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRTtxQkFDeEYsQ0FBQztnQkFDSixLQUFLLGFBQWEsQ0FBQztnQkFDbkIsS0FBSyxTQUFTO29CQUNaLE9BQU87d0JBQ0wsTUFBTSxFQUFFLDRCQUFvQixDQUFDLHFCQUFxQjt3QkFDbEQsSUFBSSxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRTtxQkFDeEYsQ0FBQztnQkFDSjtvQkFDRSxPQUFPO3dCQUNMLE1BQU0sRUFBRSw0QkFBb0IsQ0FBQyxPQUFPO3dCQUNwQyxJQUFJLEVBQUUsRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFO3FCQUN4RixDQUFDO1lBQ04sQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1lBQ3BCLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM1RSxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxPQUFPLElBQUksS0FBSyxFQUFFLE9BQU8sSUFBSSxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksZUFBZSxDQUFDO1lBQ3hHLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFDbEMsNkJBQTZCLEVBQzdCLE1BQU0sQ0FDUCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUNuQixLQUEyQjtRQUUzQixJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU1RixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUV0QyxJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFvRCxDQUFDO1lBRW5HLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDcEMsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsd0RBQXdELENBQ3pELENBQUM7WUFDSixDQUFDO1lBRUQsTUFBTSxRQUFRLEdBQUcsWUFBWTtnQkFDM0IsQ0FBQyxDQUFDLE1BQU0sTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsWUFBWSxFQUFFLENBQUM7Z0JBQ3BELENBQUMsQ0FBQyxNQUFNLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUM7WUFFbEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDckIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUNsQyw0QkFBNEIsRUFDNUIsUUFBUSxDQUFDLE9BQU8sQ0FDakIsQ0FBQztZQUNKLENBQUM7WUFFRCxPQUFPO2dCQUNMLElBQUksRUFBRTtvQkFDSixHQUFHLEtBQUssQ0FBQyxJQUFJO29CQUNiLGNBQWMsRUFBRSxRQUFRLENBQUMsSUFBSTtpQkFDOUI7YUFDRixDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7WUFDcEIsSUFBSSxJQUFJLENBQUMsS0FBSztnQkFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzNFLE1BQU0sTUFBTSxHQUFHLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE9BQU8sSUFBSSxLQUFLLEVBQUUsT0FBTyxJQUFJLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxlQUFlLENBQUM7WUFDeEcsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUNsQyw0QkFBNEIsRUFDNUIsTUFBTSxDQUNQLENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBeUI7UUFDM0MsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFMUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFdEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsR0FBRyxLQUFLLENBQUMsSUFBb0QsQ0FBQztZQUVuRyxJQUFJLENBQUMsWUFBWSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3BDLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLHdEQUF3RCxDQUN6RCxDQUFDO1lBQ0osQ0FBQztZQUVELE1BQU0sUUFBUSxHQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsY0FBc0IsRUFBRSxRQUFRLElBQUksS0FBSyxDQUFDO1lBQ3hFLE1BQU0sY0FBYyxHQUFHLElBQUEsNEJBQWlCLEVBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUV6RSxNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxjQUFzQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQzNFLElBQUksY0FBYyxJQUFJLGNBQWMsR0FBRyxjQUFjLEVBQUUsQ0FBQztnQkFDdEQsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsdUVBQXVFLENBQ3hFLENBQUM7WUFDSixDQUFDO1lBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDMUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxZQUFZLElBQUksYUFBYSxDQUFDO2dCQUNsRCxNQUFNLEVBQUUsY0FBYzthQUN2QixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNyQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQ2xDLDBCQUEwQixFQUMxQixRQUFRLENBQUMsT0FBTyxDQUNqQixDQUFDO1lBQ0osQ0FBQztZQUVELE9BQU87Z0JBQ0wsSUFBSSxFQUFFO29CQUNKLEdBQUcsS0FBSyxDQUFDLElBQUk7b0JBQ2Isa0JBQWtCLEVBQUUsUUFBUSxDQUFDLElBQUk7aUJBQ2xDO2FBQ0YsQ0FBQztRQUNKLENBQUM7UUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1lBQ3BCLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN6RSxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxPQUFPLElBQUksS0FBSyxFQUFFLE9BQU8sSUFBSSxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksZUFBZSxDQUFDO1lBQ3hHLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFDbEMsMEJBQTBCLEVBQzFCLE1BQU0sQ0FDUCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQ3BCLEtBQTRCO1FBRTVCLElBQUksSUFBSSxDQUFDLEtBQUs7WUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLDhCQUE4QixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTdGLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRXRDLE1BQU0sRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLEdBQUcsS0FBSyxDQUFDLElBQW9ELENBQUM7UUFFbkcsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sRUFBRSxNQUFNLEVBQUUsNEJBQW9CLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDbEQsQ0FBQztRQUVELElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLFlBQVk7Z0JBQzNCLENBQUMsQ0FBQyxNQUFNLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLFlBQVksRUFBRSxDQUFDO2dCQUNwRCxDQUFDLENBQUMsTUFBTSxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO1lBRWxFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ3JCLE9BQU8sRUFBRSxNQUFNLEVBQUUsNEJBQW9CLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEQsQ0FBQztZQUVELFFBQVEsUUFBUSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQztnQkFDOUIsS0FBSyxTQUFTO29CQUNaLE9BQU8sRUFBRSxNQUFNLEVBQUUsNEJBQW9CLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ25ELEtBQUssUUFBUTtvQkFDWCxPQUFPLEVBQUUsTUFBTSxFQUFFLDRCQUFvQixDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNoRCxLQUFLLFdBQVc7b0JBQ2QsT0FBTyxFQUFFLE1BQU0sRUFBRSw0QkFBb0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDbkQsS0FBSyxhQUFhLENBQUM7Z0JBQ25CLEtBQUssU0FBUztvQkFDWixPQUFPLEVBQUUsTUFBTSxFQUFFLDRCQUFvQixDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQ2hFO29CQUNFLE9BQU8sRUFBRSxNQUFNLEVBQUUsNEJBQW9CLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEQsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1lBQ3BCLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM1RSxPQUFPLEVBQUUsTUFBTSxFQUFFLDRCQUFvQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2hELENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLHVCQUF1QixDQUMzQixPQUEwQztRQUUxQyxJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV0RixNQUFNLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFRLENBQUM7UUFFMUUsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUM7UUFDbEQsSUFBSSxDQUFDO1lBQ0gsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQzNDLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBWSxDQUFDO2dCQUMxQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztvQkFDekMsTUFBTSxFQUFFLE9BQU87b0JBQ2YsTUFBTSxFQUFFLENBQUMsVUFBVSxDQUFDO2lCQUNyQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMvQixJQUFJLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxtQkFBbUIsRUFBRSxDQUFDO29CQUMvQyxhQUFhLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQztnQkFDekQsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNYLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyw2Q0FBNkMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNqRixDQUFDO1FBQ0QsTUFBTSxnQkFBZ0IsR0FBRyxJQUFBLG1DQUF3QixFQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRWpFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sRUFBRSxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsRCxDQUFDO1FBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLE9BQU8sRUFBRSxDQUFDLHNCQUFzQixDQUFDLENBQVcsQ0FBQztRQUNyRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixJQUFJLElBQUksQ0FBQyxLQUFLO2dCQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsOENBQThDLENBQUMsQ0FBQztZQUM5RSxPQUFPLEVBQUUsTUFBTSxFQUFFLHNCQUFjLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDbEQsQ0FBQztRQUVELE1BQU0sVUFBVSxHQUFHLE9BQU8sT0FBTyxLQUFLLFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztZQUN4RSxDQUFDLENBQUMsT0FBTztZQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV6QyxNQUFNLElBQUksR0FBRyxnQkFBTTthQUNoQixVQUFVLENBQUMsUUFBUSxFQUFFLGdCQUFnQixDQUFDO2FBQ3RDLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRWpCLElBQUksZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1FBQzdCLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLE1BQU0sSUFBSSxnQkFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDakcsQ0FBQztRQUFDLE1BQU0sQ0FBQztZQUNQLGdCQUFnQixHQUFHLElBQUksS0FBSyxTQUFTLENBQUM7UUFDeEMsQ0FBQztRQUVELElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RCLElBQUksSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ3hFLE9BQU87Z0JBQ0wsTUFBTSxFQUFFLHNCQUFjLENBQUMsYUFBYTthQUNyQyxDQUFDO1FBQ0osQ0FBQztRQUVELE1BQU0sSUFBSSxHQUFHLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBUSxDQUFDO1FBQzNDLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDekIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7UUFFbEMsSUFBSSxTQUFTLEdBQUksU0FBUyxDQUFDLFFBQVEsRUFBRSxVQUFxQixJQUFJLFNBQVMsQ0FBQztRQUN4RSxNQUFNLE9BQU8sR0FBSSxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQW1CLElBQUksU0FBUyxDQUFDO1FBRXRFLElBQUksQ0FBQyxTQUFTLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUM1QyxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxLQUFLLEdBQUksSUFBSSxDQUFDLFNBQWlCLENBQUMsS0FBSyxDQUFDO2dCQUM1QyxJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO3dCQUMzQyxNQUFNLEVBQUUsaUJBQWlCO3dCQUN6QixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLE1BQU0sQ0FBQzt3QkFDckMsT0FBTyxFQUFFOzRCQUNQLGtCQUFrQixFQUFFO2dDQUNsQixLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFOzZCQUN2Qjt5QkFDRjtxQkFDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUUvQixNQUFNLE9BQU8sR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FDeEMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDO3dCQUNuQyxDQUFDLENBQUMsSUFBSSxFQUFFLGFBQWEsS0FBSyxTQUFTLENBQUMsU0FBUzt3QkFDN0MsQ0FBQyxDQUFDLElBQUksRUFBRSxTQUFTLEtBQUssU0FBUyxDQUFDLFNBQVMsQ0FDMUMsSUFBSSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFbkIsSUFBSSxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUM7d0JBQ2hCLFNBQVMsR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDO29CQUN6QixDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDYixJQUFJLElBQUksQ0FBQyxLQUFLO29CQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsdURBQXVELEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDN0YsQ0FBQztRQUNILENBQUM7UUFFRCxNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQztRQUM3QyxNQUFNLFlBQVksR0FBRyxJQUFBLDBCQUFlLEVBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDOUUsTUFBTSxRQUFRLEdBQUksU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFvQixJQUFLLFNBQVMsQ0FBQyxRQUFRLEVBQUUsUUFBbUIsSUFBSSxTQUFTLENBQUM7UUFDcEgsTUFBTSxHQUFHLEdBQUksU0FBUyxDQUFDLFNBQW9CLElBQUksRUFBRSxDQUFDO1FBQ2xELE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxRQUFRLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFFekYsSUFBSSxLQUFLLEtBQUssZ0JBQWdCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2pELElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ1osSUFBSSxDQUFDO29CQUNILE1BQU0sSUFBQSxzREFBa0MsRUFBQzt3QkFDdkMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixPQUFPO3dCQUNQLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUzt3QkFDOUIsTUFBTSxFQUFFLFlBQVk7d0JBQ3BCLFFBQVE7cUJBQ1QsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztvQkFDbEIsSUFBSSxJQUFJLENBQUMsS0FBSzt3QkFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNwRixDQUFDO1lBQ0gsQ0FBQztZQUVELElBQUksVUFBVSxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxDQUFDO29CQUNILE1BQU0sSUFBQSxrREFBOEIsRUFBQzt3QkFDbkMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixRQUFRO3dCQUNSLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUzt3QkFDOUIsTUFBTSxFQUFFLFlBQVk7cUJBQ3JCLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUFDLE9BQU8sR0FBUSxFQUFFLENBQUM7b0JBQ2xCLElBQUksSUFBSSxDQUFDLEtBQUs7d0JBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxxREFBcUQsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDM0YsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLDBEQUEwRCxDQUFDLENBQUM7WUFDeEcsT0FBTztnQkFDTCxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxhQUFhO2FBQ3JDLENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxLQUFLLEtBQUssZ0JBQWdCLEVBQUUsQ0FBQztZQUMvQixPQUFPLENBQUMsSUFBSSxDQUFDLDZEQUE2RCxTQUFTLENBQUMsU0FBUyxjQUFjLFNBQVMsR0FBRyxDQUFDLENBQUM7WUFDekgsT0FBTztnQkFDTCxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxVQUFVO2dCQUNqQyxJQUFJLEVBQUU7b0JBQ0osVUFBVSxFQUFFLFNBQVM7b0JBQ3JCLE1BQU0sRUFBRSxZQUFZO2lCQUNyQjthQUNGLENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxLQUFLLEtBQUssZUFBZSxFQUFFLENBQUM7WUFDOUIsT0FBTyxDQUFDLElBQUksQ0FBQyw0REFBNEQsU0FBUyxDQUFDLFNBQVMsY0FBYyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBQ3hILE9BQU87Z0JBQ0wsTUFBTSxFQUFFLHNCQUFjLENBQUMsTUFBTTtnQkFDN0IsSUFBSSxFQUFFO29CQUNKLFVBQVUsRUFBRSxTQUFTO29CQUNyQixNQUFNLEVBQUUsWUFBWTtpQkFDckI7YUFDRixDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU87WUFDTCxNQUFNLEVBQUUsc0JBQWMsQ0FBQyxhQUFhO1NBQ3JDLENBQUM7SUFDSixDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FDbEIsS0FBMEI7UUFFMUIsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBeUI7UUFDM0MsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBeUI7UUFDM0MsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQzs7QUFHSCxrQkFBZSx1QkFBdUIsQ0FBQyJ9