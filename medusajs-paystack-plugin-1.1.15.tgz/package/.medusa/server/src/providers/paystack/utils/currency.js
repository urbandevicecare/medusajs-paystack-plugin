"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZERO_DECIMAL_CURRENCIES = void 0;
exports.getPaystackAmount = getPaystackAmount;
exports.getMedusaAmount = getMedusaAmount;
exports.formatMobileMoneyPhone = formatMobileMoneyPhone;
exports.resolvePaystackSecretKey = resolvePaystackSecretKey;
exports.normalizePaystackBalances = normalizePaystackBalances;
exports.ZERO_DECIMAL_CURRENCIES = [
    "BIF",
    "CLP",
    "DJF",
    "GNF",
    "JPY",
    "KMF",
    "KRW",
    "MGA",
    "PYG",
    "RWF",
    "UGX",
    "VND",
    "VUV",
    "XAF",
    "XPF",
];
function getPaystackAmount(amount, currency = "NGN") {
    const curr = (currency || "NGN").toUpperCase();
    if (exports.ZERO_DECIMAL_CURRENCIES.includes(curr)) {
        return Math.round(amount);
    }
    // Convert standard currencies to their lowest subunit (e.g. KES 100 -> 10000 cents)
    // In Medusa v2, prices and totals are stored and represented in standard currency units (e.g. 100.50).
    // Paystack expects smallest subunit (e.g. kobo, pesewas, cents, and XOF*100).
    return Math.round(amount * 100);
}
function getMedusaAmount(paystackAmount, currency = "NGN") {
    const curr = (currency || "NGN").toUpperCase();
    if (exports.ZERO_DECIMAL_CURRENCIES.includes(curr)) {
        return paystackAmount;
    }
    // Convert from subunit back to standard Medusa amount
    return paystackAmount / 100;
}
/**
 * Normalizes phone numbers for Mobile Money STK Push providers.
 * For Kenya M-Pesa (KES), Paystack recommends numbers in international format e.g. +254710000000.
 */
function formatMobileMoneyPhone(phone, currency) {
    if (!phone)
        return "";
    const cleaned = phone.replace(/[\s\-\(\)]/g, "");
    const curr = (currency || "").toUpperCase();
    if (curr === "KES") {
        if (cleaned.startsWith("+254"))
            return cleaned;
        if (cleaned.startsWith("254"))
            return `+${cleaned}`;
        if (cleaned.startsWith("0"))
            return `+254${cleaned.slice(1)}`;
        return `+254${cleaned}`;
    }
    if (curr === "GHS") {
        if (cleaned.startsWith("+233"))
            return cleaned;
        if (cleaned.startsWith("233"))
            return `+${cleaned}`;
        return cleaned;
    }
    return cleaned;
}
function resolvePaystackSecretKey(dynamicSecret) {
    let key = "";
    if (dynamicSecret &&
        typeof dynamicSecret === "string" &&
        dynamicSecret.trim() !== "" &&
        dynamicSecret.trim() !== "undefined" &&
        dynamicSecret.trim() !== "null") {
        key = dynamicSecret.trim();
    }
    else {
        key = (process.env.PAYSTACK_SECRET_KEY ||
            process.env.PAYSTACK_TEST_SECRET_KEY ||
            process.env.PAYSTACK_LIVE_SECRET_KEY ||
            process.env.PAYSTACK_SECRET ||
            process.env.PAYSTACK_KEY ||
            process.env.PAYSTACK_SK ||
            process.env.PAYSTACK_SECRET_KEY_URBANDEVICECARE ||
            Object.entries(process.env).find(([k, v]) => (k.startsWith("PAYSTACK_SECRET_KEY") || k.startsWith("PAYSTACK_SECRET") || k === "PAYSTACK_SK") &&
                Boolean(v))?.[1] ||
            "");
    }
    const clean = key ? key.trim().replace(/^["']|["']$/g, "") : "";
    if (clean === "undefined" || clean === "null")
        return "";
    return clean;
}
/**
 * Normalizes Paystack balance responses (array or single object),
 * formats amounts according to currency decimal rules,
 * provides a default entry if balance list is empty,
 * and sorts balances so preferred store currency and positive funds appear first.
 */
function normalizePaystackBalances(rawBalancesPayload, preferredCurrency = "KES") {
    let list = Array.isArray(rawBalancesPayload)
        ? rawBalancesPayload
        : rawBalancesPayload
            ? [rawBalancesPayload]
            : [];
    const targetCurr = (preferredCurrency || "KES").toUpperCase();
    // If Paystack returns an empty array (common for newly integrated or unused accounts),
    // supply a default 0 balance entry with the target currency so UI widgets never display blank.
    if (list.length === 0) {
        list = [
            {
                currency: targetCurr,
                balance: 0,
            },
        ];
    }
    const normalized = list.map((b) => {
        const curr = (b.currency || targetCurr).toUpperCase();
        const rawVal = Number(b.balance || 0);
        const isZeroDec = exports.ZERO_DECIMAL_CURRENCIES.includes(curr);
        const standardVal = isZeroDec ? rawVal : rawVal / 100;
        return {
            currency: curr,
            balance: rawVal,
            amount: standardVal,
            formatted: standardVal.toLocaleString("en-US", {
                minimumFractionDigits: isZeroDec ? 0 : 2,
                maximumFractionDigits: isZeroDec ? 0 : 2,
            }),
        };
    });
    // Sort balances:
    // 1. Preferred currency (store currency) first if it exists
    // 2. Currencies with positive balance before zero balances
    normalized.sort((a, b) => {
        if (a.currency === targetCurr && b.currency !== targetCurr)
            return -1;
        if (b.currency === targetCurr && a.currency !== targetCurr)
            return 1;
        if (a.amount > 0 && b.amount <= 0)
            return -1;
        if (b.amount > 0 && a.amount <= 0)
            return 1;
        return 0;
    });
    return normalized;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VycmVuY3kuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvcHJvdmlkZXJzL3BheXN0YWNrL3V0aWxzL2N1cnJlbmN5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQWtCQSw4Q0FTQztBQUVELDBDQU9DO0FBTUQsd0RBbUJDO0FBRUQsNERBOEJDO0FBZUQsOERBbURDO0FBL0pZLFFBQUEsdUJBQXVCLEdBQUc7SUFDckMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0NBQ04sQ0FBQztBQUVGLFNBQWdCLGlCQUFpQixDQUFDLE1BQWMsRUFBRSxXQUFtQixLQUFLO0lBQ3hFLE1BQU0sSUFBSSxHQUFHLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQy9DLElBQUksK0JBQXVCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDM0MsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDRCxvRkFBb0Y7SUFDcEYsdUdBQXVHO0lBQ3ZHLDhFQUE4RTtJQUM5RSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQ2xDLENBQUM7QUFFRCxTQUFnQixlQUFlLENBQUMsY0FBc0IsRUFBRSxXQUFtQixLQUFLO0lBQzlFLE1BQU0sSUFBSSxHQUFHLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQy9DLElBQUksK0JBQXVCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDM0MsT0FBTyxjQUFjLENBQUM7SUFDeEIsQ0FBQztJQUNELHNEQUFzRDtJQUN0RCxPQUFPLGNBQWMsR0FBRyxHQUFHLENBQUM7QUFDOUIsQ0FBQztBQUVEOzs7R0FHRztBQUNILFNBQWdCLHNCQUFzQixDQUFDLEtBQWEsRUFBRSxRQUFnQjtJQUNwRSxJQUFJLENBQUMsS0FBSztRQUFFLE9BQU8sRUFBRSxDQUFDO0lBQ3RCLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ2pELE1BQU0sSUFBSSxHQUFHLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBRTVDLElBQUksSUFBSSxLQUFLLEtBQUssRUFBRSxDQUFDO1FBQ25CLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFBRSxPQUFPLE9BQU8sQ0FBQztRQUMvQyxJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO1lBQUUsT0FBTyxJQUFJLE9BQU8sRUFBRSxDQUFDO1FBQ3BELElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7WUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzlELE9BQU8sT0FBTyxPQUFPLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7UUFDbkIsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztZQUFFLE9BQU8sT0FBTyxDQUFDO1FBQy9DLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPLElBQUksT0FBTyxFQUFFLENBQUM7UUFDcEQsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVELE9BQU8sT0FBTyxDQUFDO0FBQ2pCLENBQUM7QUFFRCxTQUFnQix3QkFBd0IsQ0FBQyxhQUFzQjtJQUM3RCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7SUFDYixJQUNFLGFBQWE7UUFDYixPQUFPLGFBQWEsS0FBSyxRQUFRO1FBQ2pDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFO1FBQzNCLGFBQWEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxXQUFXO1FBQ3BDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxNQUFNLEVBQy9CLENBQUM7UUFDRCxHQUFHLEdBQUcsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzdCLENBQUM7U0FBTSxDQUFDO1FBQ04sR0FBRyxHQUFHLENBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7WUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0I7WUFDcEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0I7WUFDcEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlO1lBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWTtZQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVc7WUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUM7WUFDL0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUM5QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FDVCxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxLQUFLLGFBQWEsQ0FBQztnQkFDL0YsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUNiLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDTixFQUFFLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFDRCxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFDaEUsSUFBSSxLQUFLLEtBQUssV0FBVyxJQUFJLEtBQUssS0FBSyxNQUFNO1FBQUUsT0FBTyxFQUFFLENBQUM7SUFDekQsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDO0FBU0Q7Ozs7O0dBS0c7QUFDSCxTQUFnQix5QkFBeUIsQ0FDdkMsa0JBQXVCLEVBQ3ZCLG9CQUE0QixLQUFLO0lBRWpDLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7UUFDMUMsQ0FBQyxDQUFDLGtCQUFrQjtRQUNwQixDQUFDLENBQUMsa0JBQWtCO1lBQ3BCLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO1lBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFFUCxNQUFNLFVBQVUsR0FBRyxDQUFDLGlCQUFpQixJQUFJLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBRTlELHVGQUF1RjtJQUN2RiwrRkFBK0Y7SUFDL0YsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3RCLElBQUksR0FBRztZQUNMO2dCQUNFLFFBQVEsRUFBRSxVQUFVO2dCQUNwQixPQUFPLEVBQUUsQ0FBQzthQUNYO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRCxNQUFNLFVBQVUsR0FBZ0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFO1FBQ2xFLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN0RCxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN0QyxNQUFNLFNBQVMsR0FBRywrQkFBdUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekQsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7UUFDdEQsT0FBTztZQUNMLFFBQVEsRUFBRSxJQUFJO1lBQ2QsT0FBTyxFQUFFLE1BQU07WUFDZixNQUFNLEVBQUUsV0FBVztZQUNuQixTQUFTLEVBQUUsV0FBVyxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7Z0JBQzdDLHFCQUFxQixFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxxQkFBcUIsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN6QyxDQUFDO1NBQ0gsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBRUgsaUJBQWlCO0lBQ2pCLDREQUE0RDtJQUM1RCwyREFBMkQ7SUFDM0QsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUN2QixJQUFJLENBQUMsQ0FBQyxRQUFRLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxRQUFRLEtBQUssVUFBVTtZQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDdEUsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLLFVBQVUsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLLFVBQVU7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUM7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUM1QyxPQUFPLENBQUMsQ0FBQztJQUNYLENBQUMsQ0FBQyxDQUFDO0lBRUgsT0FBTyxVQUFVLENBQUM7QUFDcEIsQ0FBQyJ9