"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconcileAndCapturePaystackPayment = reconcileAndCapturePaystackPayment;
exports.reconcilePaystackRepairPayment = reconcilePaystackRepairPayment;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Reconciles and captures a Paystack payment against a Medusa order.
 * Ensures the order's payment collection is updated, remaining balance is deducted,
 * and the payment is marked as captured in Medusa v2.
 */
async function reconcileAndCapturePaystackPayment({ container, orderId, reference, amount, currency, }) {
    const logger = container?.resolve ? container.resolve("logger") : console;
    const query = container?.resolve ? container.resolve("query") : null;
    let paymentModule = null;
    try {
        const paymentKey = typeof utils_1.Modules !== "undefined" && utils_1.Modules?.PAYMENT ? utils_1.Modules.PAYMENT : "payment";
        paymentModule = container?.resolve ? container.resolve(paymentKey) : null;
    }
    catch {
        try {
            paymentModule = container?.resolve ? container.resolve("payment") : null;
        }
        catch { }
    }
    if (!query || !orderId) {
        return {
            success: false,
            captured: false,
            orderId,
            message: "Query service or orderId not provided",
        };
    }
    try {
        // 1. Fetch order details with payment collections and payments
        const { data: orders } = await query.graph({
            entity: "order",
            fields: [
                "id",
                "total",
                "currency_code",
                "payment_collections.id",
                "payment_collections.status",
                "payment_collections.amount",
                "payment_collections.captured_amount",
                "payment_collections.payment_sessions.id",
                "payment_collections.payment_sessions.status",
                "payment_collections.payment_sessions.data",
                "payment_collections.payment_sessions.provider_id",
                "payment_collections.payments.id",
                "payment_collections.payments.amount",
                "payment_collections.payments.captured_at",
                "payment_collections.payments.canceled_at",
            ],
            filters: { id: orderId },
        }).catch(() => ({ data: [] }));
        const order = orders?.[0];
        if (!order) {
            return {
                success: false,
                captured: false,
                orderId,
                message: `Order ${orderId} not found in Medusa`,
            };
        }
        const orderCurrency = (currency || order.currency_code || "KES").toLowerCase();
        const paymentCollections = order.payment_collections || [];
        const paymentCollection = paymentCollections[0];
        if (!paymentCollection) {
            return {
                success: false,
                captured: false,
                orderId,
                message: `No payment collection found for order ${orderId}`,
            };
        }
        // 2. Check if already fully captured
        let capturedAmount = Number(paymentCollection.captured_amount || 0);
        if (!capturedAmount && paymentCollection.payments) {
            capturedAmount = paymentCollection.payments.reduce((acc, p) => {
                const isPaid = Boolean(p.captured_at) && !p.canceled_at;
                return acc + (isPaid ? Number(p.amount) : 0);
            }, 0);
        }
        const orderTotal = Number(order.total || paymentCollection.amount || 0);
        const chargeAmount = amount !== undefined && amount !== null && amount > 0
            ? Number(amount)
            : Math.max(1, orderTotal - capturedAmount);
        if (capturedAmount >= orderTotal && orderTotal > 0) {
            logger.info?.(`[Paystack-Reconcile] Order ${orderId} is already fully captured (${capturedAmount}/${orderTotal}).`);
            return {
                success: true,
                captured: true,
                orderId,
                message: "Order already fully paid",
            };
        }
        if (!paymentModule) {
            logger.warn?.(`[Paystack-Reconcile] Payment module not found in container, unable to invoke capture.`);
            return {
                success: true,
                captured: false,
                orderId,
                message: "Order verified with Paystack, but payment module unavailable to capture in Medusa",
            };
        }
        // 3. Find or create payment session on the payment collection
        const existingSessions = paymentCollection.payment_sessions || [];
        let matchingSession = existingSessions.find((s) => {
            const sRef = s.data?.paystackTxRef || s.data?.reference;
            return sRef === reference;
        });
        if (!matchingSession) {
            matchingSession = existingSessions.find((s) => s.provider_id?.includes("paystack") && s.status !== "authorized");
        }
        if (!matchingSession && typeof paymentModule.createPaymentSession === "function") {
            try {
                matchingSession = await paymentModule.createPaymentSession(paymentCollection.id, {
                    provider_id: "paystack",
                    currency_code: orderCurrency,
                    amount: chargeAmount,
                    data: {
                        paystackTxRef: reference,
                        reference,
                    },
                });
                logger.info?.(`[Paystack-Reconcile] Created payment session ${matchingSession.id} for order ${orderId}`);
            }
            catch (err) {
                logger.warn?.(`[Paystack-Reconcile] Failed to create payment session: ${err.message}`);
            }
        }
        // 4. Authorize and capture payment session
        let payment = null;
        if (matchingSession && typeof paymentModule.authorizePaymentSession === "function") {
            try {
                payment = await paymentModule.authorizePaymentSession(matchingSession.id, {
                    paystackTxRef: reference,
                    reference,
                });
                logger.info?.(`[Paystack-Reconcile] Authorized payment session ${matchingSession.id} for order ${orderId}`);
            }
            catch (err) {
                logger.warn?.(`[Paystack-Reconcile] Authorize payment session note: ${err.message}`);
            }
        }
        // If payment was created but not yet captured, capture it explicitly
        if (payment && !payment.captured_at && typeof paymentModule.capturePayment === "function") {
            try {
                payment = await paymentModule.capturePayment({
                    payment_id: payment.id,
                    amount: chargeAmount,
                });
                logger.info?.(`[Paystack-Reconcile] Explicitly captured payment ${payment.id} for order ${orderId}`);
            }
            catch (err) {
                logger.warn?.(`[Paystack-Reconcile] Capture payment note: ${err.message}`);
            }
        }
        return {
            success: true,
            captured: Boolean(payment?.captured_at || payment?.id),
            paymentId: payment?.id,
            orderId,
            message: `Payment successfully reconciled and captured for order ${orderId}`,
        };
    }
    catch (error) {
        logger.error?.(`[Paystack-Reconcile] Error reconciling payment for order ${orderId}: ${error.message}`);
        return {
            success: false,
            captured: false,
            orderId,
            message: error.message || "Failed to reconcile payment",
        };
    }
}
/**
 * Reconciles and captures a Paystack payment against a Medusa repair ticket (Repairshop plugin).
 * Updates the ticket's payment_status to 'captured', advances ticket status, tags with 'Paid',
 * and emits 'repair.payment_received' event.
 */
async function reconcilePaystackRepairPayment({ container, ticketId, ticketNumber, reference, amount, }) {
    const logger = container?.resolve ? container.resolve("logger") : console;
    let repairService = null;
    try {
        repairService = container?.resolve ? container.resolve("repair", { allowUnregistered: true }) : null;
    }
    catch { }
    if (!repairService) {
        return {
            success: false,
            captured: false,
            message: "Repair module not available in container",
        };
    }
    try {
        let tickets = [];
        if (ticketId) {
            tickets = await repairService.listRepairTickets({ id: ticketId });
        }
        else if (ticketNumber) {
            tickets = await repairService.listRepairTickets({ ticket_number: ticketNumber });
        }
        else if (reference) {
            // Common pattern: REP-<ticket_number>-<timestamp>
            const match = reference.match(/^REP-([^-]+)/i);
            if (match) {
                tickets = await repairService.listRepairTickets({ ticket_number: match[1] });
            }
            if (!tickets?.length) {
                tickets = await repairService.listRepairTickets({ ticket_number: reference });
            }
        }
        if (!tickets || tickets.length === 0) {
            return {
                success: false,
                captured: false,
                message: `Repair ticket not found for reference ${reference}`,
            };
        }
        const ticket = tickets[0];
        const parseNum = (val) => {
            if (!val)
                return 0;
            if (typeof val === "object" && "value" in val)
                return Number(val.value);
            return Number(val);
        };
        const totalEstimate = parseNum(ticket.total_estimate);
        const totalActual = parseNum(ticket.total_actual);
        const targetTotal = totalActual > 0 ? totalActual : totalEstimate;
        const amountPaidSoFar = parseNum(ticket.amount_paid);
        const paymentAmount = Number(amount || 0);
        if (!paymentAmount || paymentAmount <= 0) {
            return {
                success: false,
                captured: false,
                ticketId: ticket.id,
                ticketNumber: ticket.ticket_number,
                message: `Cannot reconcile repair payment without a verified positive amount (received: ${amount})`,
            };
        }
        const newAmountPaid = amountPaidSoFar + paymentAmount;
        const isFullyPaid = targetTotal > 0 ? newAmountPaid >= targetTotal : true;
        if (ticket.payment_status === "captured" && isFullyPaid) {
            return {
                success: true,
                captured: true,
                ticketId: ticket.id,
                ticketNumber: ticket.ticket_number,
                message: `Repair ticket ${ticket.ticket_number || ticket.id} is already marked as paid`,
            };
        }
        let newStatus = ticket.status;
        const existingMetadata = ticket.metadata || {};
        const rawTags = existingMetadata.tags;
        const existingTags = Array.isArray(rawTags)
            ? [...rawTags]
            : typeof rawTags === "string"
                ? rawTags.split(",").map((t) => t.trim()).filter(Boolean)
                : [];
        if (isFullyPaid) {
            if (!existingTags.includes("Paid")) {
                existingTags.push("Paid");
            }
            if (ticket.status === "awaiting_approval") {
                newStatus = "repairing";
            }
        }
        const updatePayload = {
            id: ticket.id,
            amount_paid: newAmountPaid,
            payment_status: isFullyPaid ? "captured" : "pending",
            payment_collection_id: reference || ticket.payment_collection_id,
            status: newStatus,
            metadata: {
                ...existingMetadata,
                tags: existingTags,
                paystack_reference: reference,
            },
        };
        await repairService.updateRepairTickets(updatePayload);
        // Emit event if eventBus is present
        try {
            const eventBus = (container?.resolve && container.resolve("event_bus", { allowUnregistered: true })) ||
                (container?.resolve && container.resolve("eventBus", { allowUnregistered: true }));
            if (eventBus && typeof eventBus.emit === "function") {
                await eventBus.emit({
                    name: "repair.payment_received",
                    data: {
                        id: ticket.id,
                        repair_ticket_id: ticket.id,
                        amount: paymentAmount,
                        reference,
                        payment_method: "Paystack",
                    },
                });
            }
        }
        catch { }
        logger.info?.(`[Paystack-Reconcile] Successfully marked repair ticket ${ticket.ticket_number || ticket.id} as paid (Reference: ${reference}).`);
        return {
            success: true,
            captured: isFullyPaid,
            ticketId: ticket.id,
            ticketNumber: ticket.ticket_number,
            message: `Repair ticket ${ticket.ticket_number || ticket.id} marked as ${isFullyPaid ? "paid/captured" : "partially paid"}`,
        };
    }
    catch (err) {
        logger.error?.(`[Paystack-Reconcile] Error reconciling repair ticket: ${err.message}`);
        return {
            success: false,
            captured: false,
            message: err.message || "Failed to reconcile repair ticket",
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb25jaWxlLXBheW1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvcHJvdmlkZXJzL3BheXN0YWNrL3V0aWxzL3JlY29uY2lsZS1wYXltZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBdUJBLGdGQXdMQztBQXVCRCx3RUF3SkM7QUE5WEQscURBQW9EO0FBa0JwRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLGtDQUFrQyxDQUFDLEVBQ3ZELFNBQVMsRUFDVCxPQUFPLEVBQ1AsU0FBUyxFQUNULE1BQU0sRUFDTixRQUFRLEdBQ2dCO0lBQ3hCLE1BQU0sTUFBTSxHQUFHLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztJQUMxRSxNQUFNLEtBQUssR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFFckUsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDO0lBQzlCLElBQUksQ0FBQztRQUNILE1BQU0sVUFBVSxHQUFHLE9BQU8sZUFBTyxLQUFLLFdBQVcsSUFBSSxlQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFDcEcsYUFBYSxHQUFHLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM1RSxDQUFDO0lBQUMsTUFBTSxDQUFDO1FBQ1AsSUFBSSxDQUFDO1lBQ0gsYUFBYSxHQUFHLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMzRSxDQUFDO1FBQUMsTUFBTSxDQUFDLENBQUEsQ0FBQztJQUNaLENBQUM7SUFFRCxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdkIsT0FBTztZQUNMLE9BQU8sRUFBRSxLQUFLO1lBQ2QsUUFBUSxFQUFFLEtBQUs7WUFDZixPQUFPO1lBQ1AsT0FBTyxFQUFFLHVDQUF1QztTQUNqRCxDQUFDO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILCtEQUErRDtRQUMvRCxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztZQUN6QyxNQUFNLEVBQUUsT0FBTztZQUNmLE1BQU0sRUFBRTtnQkFDTixJQUFJO2dCQUNKLE9BQU87Z0JBQ1AsZUFBZTtnQkFDZix3QkFBd0I7Z0JBQ3hCLDRCQUE0QjtnQkFDNUIsNEJBQTRCO2dCQUM1QixxQ0FBcUM7Z0JBQ3JDLHlDQUF5QztnQkFDekMsNkNBQTZDO2dCQUM3QywyQ0FBMkM7Z0JBQzNDLGtEQUFrRDtnQkFDbEQsaUNBQWlDO2dCQUNqQyxxQ0FBcUM7Z0JBQ3JDLDBDQUEwQztnQkFDMUMsMENBQTBDO2FBQzNDO1lBQ0QsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRTtTQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRS9CLE1BQU0sS0FBSyxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE9BQU87Z0JBQ0wsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsT0FBTztnQkFDUCxPQUFPLEVBQUUsU0FBUyxPQUFPLHNCQUFzQjthQUNoRCxDQUFDO1FBQ0osQ0FBQztRQUVELE1BQU0sYUFBYSxHQUFHLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDL0UsTUFBTSxrQkFBa0IsR0FBRyxLQUFLLENBQUMsbUJBQW1CLElBQUksRUFBRSxDQUFDO1FBQzNELE1BQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDdkIsT0FBTztnQkFDTCxPQUFPLEVBQUUsS0FBSztnQkFDZCxRQUFRLEVBQUUsS0FBSztnQkFDZixPQUFPO2dCQUNQLE9BQU8sRUFBRSx5Q0FBeUMsT0FBTyxFQUFFO2FBQzVELENBQUM7UUFDSixDQUFDO1FBRUQscUNBQXFDO1FBQ3JDLElBQUksY0FBYyxHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNsRCxjQUFjLEdBQUcsaUJBQWlCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQVcsRUFBRSxDQUFNLEVBQUUsRUFBRTtnQkFDekUsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7Z0JBQ3hELE9BQU8sR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDUixDQUFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sWUFBWSxHQUFHLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEdBQUcsQ0FBQztZQUN4RSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNoQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsVUFBVSxHQUFHLGNBQWMsQ0FBQyxDQUFDO1FBRTdDLElBQUksY0FBYyxJQUFJLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbkQsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLDhCQUE4QixPQUFPLCtCQUErQixjQUFjLElBQUksVUFBVSxJQUFJLENBQUMsQ0FBQztZQUNwSCxPQUFPO2dCQUNMLE9BQU8sRUFBRSxJQUFJO2dCQUNiLFFBQVEsRUFBRSxJQUFJO2dCQUNkLE9BQU87Z0JBQ1AsT0FBTyxFQUFFLDBCQUEwQjthQUNwQyxDQUFDO1FBQ0osQ0FBQztRQUVELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuQixNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsdUZBQXVGLENBQUMsQ0FBQztZQUN2RyxPQUFPO2dCQUNMLE9BQU8sRUFBRSxJQUFJO2dCQUNiLFFBQVEsRUFBRSxLQUFLO2dCQUNmLE9BQU87Z0JBQ1AsT0FBTyxFQUFFLG1GQUFtRjthQUM3RixDQUFDO1FBQ0osQ0FBQztRQUVELDhEQUE4RDtRQUM5RCxNQUFNLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQztRQUNsRSxJQUFJLGVBQWUsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRTtZQUNyRCxNQUFNLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLGFBQWEsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQztZQUN4RCxPQUFPLElBQUksS0FBSyxTQUFTLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDckIsZUFBZSxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQ2pELENBQUMsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUNqRSxDQUFDO1FBQ0osQ0FBQztRQUVELElBQUksQ0FBQyxlQUFlLElBQUksT0FBTyxhQUFhLENBQUMsb0JBQW9CLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDakYsSUFBSSxDQUFDO2dCQUNILGVBQWUsR0FBRyxNQUFNLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUU7b0JBQy9FLFdBQVcsRUFBRSxVQUFVO29CQUN2QixhQUFhLEVBQUUsYUFBYTtvQkFDNUIsTUFBTSxFQUFFLFlBQVk7b0JBQ3BCLElBQUksRUFBRTt3QkFDSixhQUFhLEVBQUUsU0FBUzt3QkFDeEIsU0FBUztxQkFDVjtpQkFDRixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLGdEQUFnRCxlQUFlLENBQUMsRUFBRSxjQUFjLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDM0csQ0FBQztZQUFDLE9BQU8sR0FBUSxFQUFFLENBQUM7Z0JBQ2xCLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQywwREFBMEQsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDekYsQ0FBQztRQUNILENBQUM7UUFFRCwyQ0FBMkM7UUFDM0MsSUFBSSxPQUFPLEdBQVEsSUFBSSxDQUFDO1FBQ3hCLElBQUksZUFBZSxJQUFJLE9BQU8sYUFBYSxDQUFDLHVCQUF1QixLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ25GLElBQUksQ0FBQztnQkFDSCxPQUFPLEdBQUcsTUFBTSxhQUFhLENBQUMsdUJBQXVCLENBQUMsZUFBZSxDQUFDLEVBQUUsRUFBRTtvQkFDeEUsYUFBYSxFQUFFLFNBQVM7b0JBQ3hCLFNBQVM7aUJBQ1YsQ0FBQyxDQUFDO2dCQUVILE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxtREFBbUQsZUFBZSxDQUFDLEVBQUUsY0FBYyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzlHLENBQUM7WUFBQyxPQUFPLEdBQVEsRUFBRSxDQUFDO2dCQUNsQixNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsd0RBQXdELEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZGLENBQUM7UUFDSCxDQUFDO1FBRUQscUVBQXFFO1FBQ3JFLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLGFBQWEsQ0FBQyxjQUFjLEtBQUssVUFBVSxFQUFFLENBQUM7WUFDMUYsSUFBSSxDQUFDO2dCQUNILE9BQU8sR0FBRyxNQUFNLGFBQWEsQ0FBQyxjQUFjLENBQUM7b0JBQzNDLFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtvQkFDdEIsTUFBTSxFQUFFLFlBQVk7aUJBQ3JCLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsb0RBQW9ELE9BQU8sQ0FBQyxFQUFFLGNBQWMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUN2RyxDQUFDO1lBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztnQkFDbEIsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLDhDQUE4QyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUM3RSxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU87WUFDTCxPQUFPLEVBQUUsSUFBSTtZQUNiLFFBQVEsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLFdBQVcsSUFBSSxPQUFPLEVBQUUsRUFBRSxDQUFDO1lBQ3RELFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN0QixPQUFPO1lBQ1AsT0FBTyxFQUFFLDBEQUEwRCxPQUFPLEVBQUU7U0FDN0UsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyw0REFBNEQsT0FBTyxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3hHLE9BQU87WUFDTCxPQUFPLEVBQUUsS0FBSztZQUNkLFFBQVEsRUFBRSxLQUFLO1lBQ2YsT0FBTztZQUNQLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLDZCQUE2QjtTQUN4RCxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUM7QUFrQkQ7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSw4QkFBOEIsQ0FBQyxFQUNuRCxTQUFTLEVBQ1QsUUFBUSxFQUNSLFlBQVksRUFDWixTQUFTLEVBQ1QsTUFBTSxHQUNpQjtJQUN2QixNQUFNLE1BQU0sR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7SUFDMUUsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDO0lBRTlCLElBQUksQ0FBQztRQUNILGFBQWEsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUN2RyxDQUFDO0lBQUMsTUFBTSxDQUFDLENBQUEsQ0FBQztJQUVWLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQixPQUFPO1lBQ0wsT0FBTyxFQUFFLEtBQUs7WUFDZCxRQUFRLEVBQUUsS0FBSztZQUNmLE9BQU8sRUFBRSwwQ0FBMEM7U0FDcEQsQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxJQUFJLE9BQU8sR0FBVSxFQUFFLENBQUM7UUFDeEIsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUNiLE9BQU8sR0FBRyxNQUFNLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7YUFBTSxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ3hCLE9BQU8sR0FBRyxNQUFNLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLGFBQWEsRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDO1FBQ25GLENBQUM7YUFBTSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ3JCLGtEQUFrRDtZQUNsRCxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQy9DLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1YsT0FBTyxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDL0UsQ0FBQztZQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7Z0JBQ3JCLE9BQU8sR0FBRyxNQUFNLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBQ2hGLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3JDLE9BQU87Z0JBQ0wsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsT0FBTyxFQUFFLHlDQUF5QyxTQUFTLEVBQUU7YUFDOUQsQ0FBQztRQUNKLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUIsTUFBTSxRQUFRLEdBQUcsQ0FBQyxHQUFRLEVBQUUsRUFBRTtZQUM1QixJQUFJLENBQUMsR0FBRztnQkFBRSxPQUFPLENBQUMsQ0FBQztZQUNuQixJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsSUFBSSxPQUFPLElBQUksR0FBRztnQkFBRSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDeEUsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDckIsQ0FBQyxDQUFDO1FBRUYsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN0RCxNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2xELE1BQU0sV0FBVyxHQUFHLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO1FBQ2xFLE1BQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFckQsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztRQUMxQyxJQUFJLENBQUMsYUFBYSxJQUFJLGFBQWEsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN6QyxPQUFPO2dCQUNMLE9BQU8sRUFBRSxLQUFLO2dCQUNkLFFBQVEsRUFBRSxLQUFLO2dCQUNmLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbkIsWUFBWSxFQUFFLE1BQU0sQ0FBQyxhQUFhO2dCQUNsQyxPQUFPLEVBQUUsaUZBQWlGLE1BQU0sR0FBRzthQUNwRyxDQUFDO1FBQ0osQ0FBQztRQUVELE1BQU0sYUFBYSxHQUFHLGVBQWUsR0FBRyxhQUFhLENBQUM7UUFDdEQsTUFBTSxXQUFXLEdBQUcsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRTFFLElBQUksTUFBTSxDQUFDLGNBQWMsS0FBSyxVQUFVLElBQUksV0FBVyxFQUFFLENBQUM7WUFDeEQsT0FBTztnQkFDTCxPQUFPLEVBQUUsSUFBSTtnQkFDYixRQUFRLEVBQUUsSUFBSTtnQkFDZCxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBQ25CLFlBQVksRUFBRSxNQUFNLENBQUMsYUFBYTtnQkFDbEMsT0FBTyxFQUFFLGlCQUFpQixNQUFNLENBQUMsYUFBYSxJQUFJLE1BQU0sQ0FBQyxFQUFFLDRCQUE0QjthQUN4RixDQUFDO1FBQ0osQ0FBQztRQUVELElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDOUIsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztRQUMvQyxNQUFNLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7UUFDdEMsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDekMsQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUM7WUFDZCxDQUFDLENBQUMsT0FBTyxPQUFPLEtBQUssUUFBUTtnQkFDM0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUNqRSxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRVQsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNoQixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUNuQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVCLENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssbUJBQW1CLEVBQUUsQ0FBQztnQkFDMUMsU0FBUyxHQUFHLFdBQVcsQ0FBQztZQUMxQixDQUFDO1FBQ0gsQ0FBQztRQUVELE1BQU0sYUFBYSxHQUFRO1lBQ3pCLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNiLFdBQVcsRUFBRSxhQUFhO1lBQzFCLGNBQWMsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUNwRCxxQkFBcUIsRUFBRSxTQUFTLElBQUksTUFBTSxDQUFDLHFCQUFxQjtZQUNoRSxNQUFNLEVBQUUsU0FBUztZQUNqQixRQUFRLEVBQUU7Z0JBQ1IsR0FBRyxnQkFBZ0I7Z0JBQ25CLElBQUksRUFBRSxZQUFZO2dCQUNsQixrQkFBa0IsRUFBRSxTQUFTO2FBQzlCO1NBQ0YsQ0FBQztRQUVGLE1BQU0sYUFBYSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRXZELG9DQUFvQztRQUNwQyxJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FDWixDQUFDLFNBQVMsRUFBRSxPQUFPLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUNuRixDQUFDLFNBQVMsRUFBRSxPQUFPLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckYsSUFBSSxRQUFRLElBQUksT0FBTyxRQUFRLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRSxDQUFDO2dCQUNwRCxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUM7b0JBQ2xCLElBQUksRUFBRSx5QkFBeUI7b0JBQy9CLElBQUksRUFBRTt3QkFDSixFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7d0JBQ2IsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLEVBQUU7d0JBQzNCLE1BQU0sRUFBRSxhQUFhO3dCQUNyQixTQUFTO3dCQUNULGNBQWMsRUFBRSxVQUFVO3FCQUMzQjtpQkFDRixDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQztRQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7UUFFVixNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsMERBQTBELE1BQU0sQ0FBQyxhQUFhLElBQUksTUFBTSxDQUFDLEVBQUUsd0JBQXdCLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFFaEosT0FBTztZQUNMLE9BQU8sRUFBRSxJQUFJO1lBQ2IsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFlBQVksRUFBRSxNQUFNLENBQUMsYUFBYTtZQUNsQyxPQUFPLEVBQUUsaUJBQWlCLE1BQU0sQ0FBQyxhQUFhLElBQUksTUFBTSxDQUFDLEVBQUUsY0FBYyxXQUFXLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUU7U0FDNUgsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEdBQVEsRUFBRSxDQUFDO1FBQ2xCLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyx5REFBeUQsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDdkYsT0FBTztZQUNMLE9BQU8sRUFBRSxLQUFLO1lBQ2QsUUFBUSxFQUFFLEtBQUs7WUFDZixPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU8sSUFBSSxtQ0FBbUM7U0FDNUQsQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDIn0=