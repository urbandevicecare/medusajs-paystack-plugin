"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
class PaystackClient {
    axios;
    constructor(secretKey) {
        this.axios = axios_1.default.create({
            baseURL: "https://api.paystack.co",
            timeout: 30000,
            headers: {
                Authorization: `Bearer ${secretKey}`,
                "Content-Type": "application/json",
            },
        });
    }
    transaction = {
        initialize: async (data) => {
            const response = await this.axios.post("/transaction/initialize", data);
            return response.data;
        },
        verify: async ({ reference }) => {
            const response = await this.axios.get(`/transaction/verify/${reference}`);
            return response.data;
        },
        get: async ({ id }) => {
            const response = await this.axios.get(`/transaction/${id}`);
            return response.data;
        },
        list: async (params) => {
            const response = await this.axios.get("/transaction", { params });
            return response.data;
        },
    };
    charge = {
        create: async (data) => {
            const response = await this.axios.post("/charge", data);
            return response.data;
        },
        checkPending: async (reference) => {
            const response = await this.axios.get(`/charge/${reference}`);
            return response.data;
        },
    };
    refund = {
        create: async (data) => {
            const response = await this.axios.post("/refund", data);
            return response.data;
        },
    };
    balance = {
        get: async () => {
            const response = await this.axios.get("/balance");
            return response.data;
        },
        getLedger: async () => {
            const response = await this.axios.get("/balance/ledger");
            return response.data;
        },
    };
}
exports.default = PaystackClient;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5c3RhY2stY2xpZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL3Byb3ZpZGVycy9wYXlzdGFjay9zZXJ2aWNlcy9wYXlzdGFjay1jbGllbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxrREFBNkM7QUFpRDdDLE1BQXFCLGNBQWM7SUFDekIsS0FBSyxDQUFnQjtJQUU3QixZQUFZLFNBQWlCO1FBQzNCLElBQUksQ0FBQyxLQUFLLEdBQUcsZUFBSyxDQUFDLE1BQU0sQ0FBQztZQUN4QixPQUFPLEVBQUUseUJBQXlCO1lBQ2xDLE9BQU8sRUFBRSxLQUFLO1lBQ2QsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFBRSxVQUFVLFNBQVMsRUFBRTtnQkFDcEMsY0FBYyxFQUFFLGtCQUFrQjthQUNuQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxXQUFXLEdBQUc7UUFDbkIsVUFBVSxFQUFFLEtBQUssRUFBRSxJQUE4QixFQUFFLEVBQUU7WUFDbkQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4RSxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDdkIsQ0FBQztRQUNELE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQXdCLEVBQUUsRUFBRTtZQUNwRCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHVCQUF1QixTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBQzFFLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQztRQUN2QixDQUFDO1FBQ0QsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsRUFBeUIsRUFBRSxFQUFFO1lBQzNDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDNUQsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLENBQUM7UUFDRCxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQWdDLEVBQUUsRUFBRTtZQUMvQyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDbEUsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLENBQUM7S0FDRixDQUFDO0lBRUssTUFBTSxHQUFHO1FBQ2QsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUEwQixFQUFFLEVBQUU7WUFDM0MsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDeEQsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLENBQUM7UUFDRCxZQUFZLEVBQUUsS0FBSyxFQUFFLFNBQWlCLEVBQUUsRUFBRTtZQUN4QyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFdBQVcsU0FBUyxFQUFFLENBQUMsQ0FBQztZQUM5RCxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDdkIsQ0FBQztLQUNGLENBQUM7SUFFSyxNQUFNLEdBQUc7UUFDZCxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQTBCLEVBQUUsRUFBRTtZQUMzQyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4RCxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDdkIsQ0FBQztLQUNGLENBQUM7SUFFSyxPQUFPLEdBQUc7UUFDZixHQUFHLEVBQUUsS0FBSyxJQUFJLEVBQUU7WUFDZCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ2xELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQztRQUN2QixDQUFDO1FBQ0QsU0FBUyxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQ3BCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUN6RCxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDdkIsQ0FBQztLQUNGLENBQUM7Q0FDSDtBQTdERCxpQ0E2REMifQ==