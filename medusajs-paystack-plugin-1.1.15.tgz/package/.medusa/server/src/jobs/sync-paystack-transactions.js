"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = syncPaystackTransactions;
const utils_1 = require("@medusajs/framework/utils");
const reconcile_payment_1 = require("../providers/paystack/utils/reconcile-payment");
const currency_1 = require("../providers/paystack/utils/currency");
async function syncPaystackTransactions(containerOrArgs) {
    const container = containerOrArgs?.resolve
        ? containerOrArgs
        : containerOrArgs?.container;
    if (!container || typeof container.resolve !== "function") {
        return;
    }
    const query = container.resolve("query");
    let paymentModule = null;
    try {
        paymentModule = container.resolve(utils_1.Modules.PAYMENT);
    }
    catch {
        try {
            paymentModule = container.resolve("payment");
        }
        catch { }
    }
    const logger = container.resolve("logger");
    logger.info("Starting Paystack transaction sync job...");
    try {
        let verifiedCount = 0;
        // 1. Fetch pending/in-flight payment sessions for Paystack
        const { data: paymentSessions } = await query.graph({
            entity: "payment_session",
            fields: ["id", "status", "provider_id", "data", "created_at"],
            filters: {
                status: { $in: ["pending", "pending_authorization", "requires_more"] },
                provider_id: { $like: "%paystack%" },
            },
        }).catch(() => ({ data: [] }));
        if (paymentSessions && paymentSessions.length > 0) {
            logger.info(`Found ${paymentSessions.length} in-flight Paystack session(s).`);
            const now = Date.now();
            for (const session of paymentSessions) {
                try {
                    // Skip sessions created in the last 60 seconds to avoid racing with customer checkout
                    const createdAt = session.created_at ? new Date(session.created_at).getTime() : 0;
                    if (createdAt && (now - createdAt) < 60000) {
                        continue;
                    }
                    if (!paymentModule)
                        continue;
                    // Authorize payment session. The Paystack provider will internally verify the transaction
                    // via Paystack's API. If successful, it returns status CAPTURED.
                    const authorizedSession = await paymentModule.authorizePaymentSession(session.id, {});
                    if (authorizedSession) {
                        // Ensure payment is explicitly captured if returned in authorized state
                        if (!authorizedSession.captured_at && typeof paymentModule.capturePayment === "function") {
                            try {
                                await paymentModule.capturePayment({
                                    payment_id: authorizedSession.id,
                                    amount: authorizedSession.amount,
                                });
                            }
                            catch { }
                        }
                        verifiedCount++;
                        logger.info(`[Paystack-Sync] Verified and captured payment for session ${session.id}`);
                    }
                }
                catch (err) {
                    // When a session is not yet approved by customer, Medusa throws NOT_ALLOWED.
                    logger.debug?.(`[Paystack-Sync] Session ${session.id} pending completion: ${err.message}`);
                }
            }
        }
        else {
            logger.info("No pending Paystack payment sessions found.");
        }
        // 2. Reconcile unpaid orders with pending Paystack references
        try {
            const { data: unpaidOrders } = await query.graph({
                entity: "order",
                fields: [
                    "id",
                    "total",
                    "currency_code",
                    "metadata",
                    "payment_collections.id",
                    "payment_collections.status",
                    "payment_collections.amount",
                    "payment_collections.captured_amount",
                    "payment_collections.payment_sessions.id",
                    "payment_collections.payment_sessions.status",
                    "payment_collections.payment_sessions.data",
                    "payment_collections.payment_sessions.provider_id",
                ],
                filters: {
                    payment_collections: {
                        status: { $in: ["not_paid", "partially_paid"] },
                    },
                },
            }).catch(() => ({ data: [] }));
            if (unpaidOrders && unpaidOrders.length > 0) {
                for (const order of unpaidOrders) {
                    const sessions = order.payment_collections?.[0]?.payment_sessions || [];
                    let reconciled = false;
                    for (const s of sessions) {
                        const ref = s.data?.paystackTxRef || s.data?.reference || order.metadata?.paystack_reference;
                        if (ref && s.provider_id?.includes("paystack") && s.status !== "authorized") {
                            try {
                                const res = await (0, reconcile_payment_1.reconcileAndCapturePaystackPayment)({
                                    container,
                                    orderId: order.id,
                                    reference: ref,
                                    currency: order.currency_code,
                                });
                                if (res.captured) {
                                    verifiedCount++;
                                    reconciled = true;
                                    logger.info(`[Paystack-Sync] Reconciled and captured payment for order ${order.id} (ref: ${ref})`);
                                }
                            }
                            catch (err) {
                                logger.debug?.(`[Paystack-Sync] Note reconciling order ${order.id}: ${err.message}`);
                            }
                        }
                    }
                    if (!reconciled && order.metadata?.paystack_reference) {
                        const orderRef = order.metadata.paystack_reference;
                        try {
                            const res = await (0, reconcile_payment_1.reconcileAndCapturePaystackPayment)({
                                container,
                                orderId: order.id,
                                reference: orderRef,
                                currency: order.currency_code,
                            });
                            if (res.captured) {
                                verifiedCount++;
                                logger.info(`[Paystack-Sync] Reconciled and captured payment for order ${order.id} via metadata ref (${orderRef})`);
                            }
                        }
                        catch (err) {
                            logger.debug?.(`[Paystack-Sync] Note reconciling order ${order.id} via metadata: ${err.message}`);
                        }
                    }
                }
            }
        }
        catch (orderSyncErr) {
            logger.debug?.(`[Paystack-Sync] Order reconciliation scan note: ${orderSyncErr.message}`);
        }
        // 3. Reconcile pending repair tickets with Paystack if repair module is present and secretKey is configured
        try {
            let dynamicSecret = "";
            try {
                const { data: stores } = await query.graph({
                    entity: "store",
                    fields: ["metadata"],
                }).catch(() => ({ data: [] }));
                dynamicSecret = stores?.[0]?.metadata?.paystack_secret_key || "";
            }
            catch { }
            const secretKey = (0, currency_1.resolvePaystackSecretKey)(dynamicSecret);
            let repairService = null;
            try {
                repairService = container.resolve("repair", { allowUnregistered: true });
            }
            catch { }
            if (repairService && typeof repairService.listRepairTickets === "function" && secretKey) {
                const pendingTickets = await repairService.listRepairTickets({
                    payment_status: "pending",
                }).catch(() => []);
                for (const ticket of (pendingTickets || [])) {
                    const rawRef = ticket.metadata?.paystack_reference;
                    // Only attempt verification on valid Paystack references (never internal Medusa IDs like pay_col_...)
                    if (rawRef &&
                        typeof rawRef === "string" &&
                        !rawRef.startsWith("pay_col_") &&
                        !rawRef.startsWith("payses_")) {
                        try {
                            const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(rawRef)}`, {
                                method: "GET",
                                headers: {
                                    Authorization: `Bearer ${secretKey}`,
                                    "Content-Type": "application/json",
                                },
                            });
                            if (verifyRes.ok) {
                                const verifyData = await verifyRes.json();
                                if (verifyData.status && verifyData.data?.status === "success") {
                                    const verifiedAmount = (0, currency_1.getMedusaAmount)(Number(verifyData.data.amount || 0), verifyData.data.currency);
                                    if (verifiedAmount > 0) {
                                        const res = await (0, reconcile_payment_1.reconcilePaystackRepairPayment)({
                                            container,
                                            ticketId: ticket.id,
                                            reference: rawRef,
                                            amount: verifiedAmount,
                                        });
                                        if (res.captured) {
                                            verifiedCount++;
                                            logger.info(`[Paystack-Sync] Verified with Paystack and reconciled repair ticket ${ticket.ticket_number || ticket.id} (ref: ${rawRef}, amount: ${verifiedAmount})`);
                                        }
                                    }
                                }
                            }
                        }
                        catch (ticketErr) {
                            logger.debug?.(`[Paystack-Sync] Note verifying repair ticket ${ticket.id}: ${ticketErr.message}`);
                        }
                    }
                }
            }
        }
        catch (repairSyncErr) {
            logger.debug?.(`[Paystack-Sync] Repair ticket scan note: ${repairSyncErr.message}`);
        }
        logger.info(`Paystack sync complete. Captured/reconciled ${verifiedCount} payment(s).`);
    }
    catch (error) {
        logger.error(`Failed to sync Paystack transactions: ${error.message}`);
    }
}
exports.config = {
    name: "sync-paystack-transactions",
    // Runs every 15 minutes
    schedule: "*/15 * * * *",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3luYy1wYXlzdGFjay10cmFuc2FjdGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvam9icy9zeW5jLXBheXN0YWNrLXRyYW5zYWN0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFLQSwyQ0ErT0M7QUFuUEQscURBQW9EO0FBQ3BELHFGQUFtSTtBQUNuSSxtRUFBaUc7QUFFbEYsS0FBSyxVQUFVLHdCQUF3QixDQUNwRCxlQUFvQjtJQUVwQixNQUFNLFNBQVMsR0FBb0IsZUFBZSxFQUFFLE9BQU87UUFDekQsQ0FBQyxDQUFDLGVBQWU7UUFDakIsQ0FBQyxDQUFDLGVBQWUsRUFBRSxTQUFTLENBQUM7SUFFL0IsSUFBSSxDQUFDLFNBQVMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxPQUFPLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDMUQsT0FBTztJQUNULENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3pDLElBQUksYUFBYSxHQUFRLElBQUksQ0FBQztJQUM5QixJQUFJLENBQUM7UUFDSCxhQUFhLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUFDLE1BQU0sQ0FBQztRQUNQLElBQUksQ0FBQztZQUNILGFBQWEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9DLENBQUM7UUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO0lBQ1osQ0FBQztJQUVELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFM0MsTUFBTSxDQUFDLElBQUksQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO0lBRXpELElBQUksQ0FBQztRQUNILElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQztRQUV0QiwyREFBMkQ7UUFDM0QsTUFBTSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDbEQsTUFBTSxFQUFFLGlCQUFpQjtZQUN6QixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDO1lBQzdELE9BQU8sRUFBRTtnQkFDUCxNQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxTQUFTLEVBQUUsdUJBQXVCLEVBQUUsZUFBZSxDQUFDLEVBQUU7Z0JBQ3RFLFdBQVcsRUFBRSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUU7YUFDckM7U0FDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRS9CLElBQUksZUFBZSxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbEQsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLGVBQWUsQ0FBQyxNQUFNLGlDQUFpQyxDQUFDLENBQUM7WUFFOUUsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLEtBQUssTUFBTSxPQUFPLElBQUksZUFBZSxFQUFFLENBQUM7Z0JBQ3RDLElBQUksQ0FBQztvQkFDSCxzRkFBc0Y7b0JBQ3RGLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNsRixJQUFJLFNBQVMsSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUMsR0FBRyxLQUFLLEVBQUUsQ0FBQzt3QkFDM0MsU0FBUztvQkFDWCxDQUFDO29CQUVELElBQUksQ0FBQyxhQUFhO3dCQUFFLFNBQVM7b0JBRTdCLDBGQUEwRjtvQkFDMUYsaUVBQWlFO29CQUNqRSxNQUFNLGlCQUFpQixHQUFHLE1BQU0sYUFBYSxDQUFDLHVCQUF1QixDQUNuRSxPQUFPLENBQUMsRUFBRSxFQUNWLEVBQUUsQ0FDSCxDQUFDO29CQUVGLElBQUksaUJBQWlCLEVBQUUsQ0FBQzt3QkFDdEIsd0VBQXdFO3dCQUN4RSxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxJQUFJLE9BQU8sYUFBYSxDQUFDLGNBQWMsS0FBSyxVQUFVLEVBQUUsQ0FBQzs0QkFDekYsSUFBSSxDQUFDO2dDQUNILE1BQU0sYUFBYSxDQUFDLGNBQWMsQ0FBQztvQ0FDakMsVUFBVSxFQUFFLGlCQUFpQixDQUFDLEVBQUU7b0NBQ2hDLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQyxNQUFNO2lDQUNqQyxDQUFDLENBQUM7NEJBQ0wsQ0FBQzs0QkFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO3dCQUNaLENBQUM7d0JBRUQsYUFBYSxFQUFFLENBQUM7d0JBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQ1QsNkRBQTZELE9BQU8sQ0FBQyxFQUFFLEVBQUUsQ0FDMUUsQ0FBQztvQkFDSixDQUFDO2dCQUNILENBQUM7Z0JBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztvQkFDbEIsNkVBQTZFO29CQUM3RSxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsMkJBQTJCLE9BQU8sQ0FBQyxFQUFFLHdCQUF3QixHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztnQkFDN0YsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBRUQsOERBQThEO1FBQzlELElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUMvQyxNQUFNLEVBQUUsT0FBTztnQkFDZixNQUFNLEVBQUU7b0JBQ04sSUFBSTtvQkFDSixPQUFPO29CQUNQLGVBQWU7b0JBQ2YsVUFBVTtvQkFDVix3QkFBd0I7b0JBQ3hCLDRCQUE0QjtvQkFDNUIsNEJBQTRCO29CQUM1QixxQ0FBcUM7b0JBQ3JDLHlDQUF5QztvQkFDekMsNkNBQTZDO29CQUM3QywyQ0FBMkM7b0JBQzNDLGtEQUFrRDtpQkFDbkQ7Z0JBQ0QsT0FBTyxFQUFFO29CQUNQLG1CQUFtQixFQUFFO3dCQUNuQixNQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsRUFBRTtxQkFDaEQ7aUJBQ0Y7YUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRS9CLElBQUksWUFBWSxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzVDLEtBQUssTUFBTSxLQUFLLElBQUksWUFBWSxFQUFFLENBQUM7b0JBQ2pDLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLGdCQUFnQixJQUFJLEVBQUUsQ0FBQztvQkFDeEUsSUFBSSxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUN2QixLQUFLLE1BQU0sQ0FBQyxJQUFJLFFBQVEsRUFBRSxDQUFDO3dCQUN6QixNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLGFBQWEsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLFNBQVMsSUFBSyxLQUFLLENBQUMsUUFBZ0IsRUFBRSxrQkFBa0IsQ0FBQzt3QkFDdEcsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxZQUFZLEVBQUUsQ0FBQzs0QkFDNUUsSUFBSSxDQUFDO2dDQUNILE1BQU0sR0FBRyxHQUFHLE1BQU0sSUFBQSxzREFBa0MsRUFBQztvQ0FDbkQsU0FBUztvQ0FDVCxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0NBQ2pCLFNBQVMsRUFBRSxHQUFHO29DQUNkLFFBQVEsRUFBRSxLQUFLLENBQUMsYUFBYTtpQ0FDOUIsQ0FBQyxDQUFDO2dDQUNILElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO29DQUNqQixhQUFhLEVBQUUsQ0FBQztvQ0FDaEIsVUFBVSxHQUFHLElBQUksQ0FBQztvQ0FDbEIsTUFBTSxDQUFDLElBQUksQ0FBQyw2REFBNkQsS0FBSyxDQUFDLEVBQUUsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dDQUNyRyxDQUFDOzRCQUNILENBQUM7NEJBQUMsT0FBTyxHQUFRLEVBQUUsQ0FBQztnQ0FDbEIsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLDBDQUEwQyxLQUFLLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDOzRCQUN2RixDQUFDO3dCQUNILENBQUM7b0JBQ0gsQ0FBQztvQkFFRCxJQUFJLENBQUMsVUFBVSxJQUFLLEtBQUssQ0FBQyxRQUFnQixFQUFFLGtCQUFrQixFQUFFLENBQUM7d0JBQy9ELE1BQU0sUUFBUSxHQUFJLEtBQUssQ0FBQyxRQUFnQixDQUFDLGtCQUFrQixDQUFDO3dCQUM1RCxJQUFJLENBQUM7NEJBQ0gsTUFBTSxHQUFHLEdBQUcsTUFBTSxJQUFBLHNEQUFrQyxFQUFDO2dDQUNuRCxTQUFTO2dDQUNULE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTtnQ0FDakIsU0FBUyxFQUFFLFFBQVE7Z0NBQ25CLFFBQVEsRUFBRSxLQUFLLENBQUMsYUFBYTs2QkFDOUIsQ0FBQyxDQUFDOzRCQUNILElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dDQUNqQixhQUFhLEVBQUUsQ0FBQztnQ0FDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyw2REFBNkQsS0FBSyxDQUFDLEVBQUUsc0JBQXNCLFFBQVEsR0FBRyxDQUFDLENBQUM7NEJBQ3RILENBQUM7d0JBQ0gsQ0FBQzt3QkFBQyxPQUFPLEdBQVEsRUFBRSxDQUFDOzRCQUNsQixNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsMENBQTBDLEtBQUssQ0FBQyxFQUFFLGtCQUFrQixHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzt3QkFDcEcsQ0FBQztvQkFDSCxDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUFDLE9BQU8sWUFBaUIsRUFBRSxDQUFDO1lBQzNCLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxtREFBbUQsWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDNUYsQ0FBQztRQUVELDRHQUE0RztRQUM1RyxJQUFJLENBQUM7WUFDSCxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDO2dCQUNILE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO29CQUN6QyxNQUFNLEVBQUUsT0FBTztvQkFDZixNQUFNLEVBQUUsQ0FBQyxVQUFVLENBQUM7aUJBQ3JCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLGFBQWEsR0FBSSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsbUJBQThCLElBQUksRUFBRSxDQUFDO1lBQy9FLENBQUM7WUFBQyxNQUFNLENBQUMsQ0FBQSxDQUFDO1lBRVYsTUFBTSxTQUFTLEdBQUcsSUFBQSxtQ0FBd0IsRUFBQyxhQUFhLENBQUMsQ0FBQztZQUUxRCxJQUFJLGFBQWEsR0FBUSxJQUFJLENBQUM7WUFDOUIsSUFBSSxDQUFDO2dCQUNILGFBQWEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7WUFDM0UsQ0FBQztZQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7WUFFVixJQUFJLGFBQWEsSUFBSSxPQUFPLGFBQWEsQ0FBQyxpQkFBaUIsS0FBSyxVQUFVLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ3hGLE1BQU0sY0FBYyxHQUFHLE1BQU0sYUFBYSxDQUFDLGlCQUFpQixDQUFDO29CQUMzRCxjQUFjLEVBQUUsU0FBUztpQkFDMUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFbkIsS0FBSyxNQUFNLE1BQU0sSUFBSSxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDO29CQUM1QyxNQUFNLE1BQU0sR0FBSSxNQUFNLENBQUMsUUFBZ0IsRUFBRSxrQkFBa0IsQ0FBQztvQkFDNUQsc0dBQXNHO29CQUN0RyxJQUNFLE1BQU07d0JBQ04sT0FBTyxNQUFNLEtBQUssUUFBUTt3QkFDMUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDOUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUM3QixDQUFDO3dCQUNELElBQUksQ0FBQzs0QkFDSCxNQUFNLFNBQVMsR0FBRyxNQUFNLEtBQUssQ0FDM0IsOENBQThDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQzFFO2dDQUNFLE1BQU0sRUFBRSxLQUFLO2dDQUNiLE9BQU8sRUFBRTtvQ0FDUCxhQUFhLEVBQUUsVUFBVSxTQUFTLEVBQUU7b0NBQ3BDLGNBQWMsRUFBRSxrQkFBa0I7aUNBQ25DOzZCQUNGLENBQ0YsQ0FBQzs0QkFFRixJQUFJLFNBQVMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQ0FDakIsTUFBTSxVQUFVLEdBQUcsTUFBTSxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7Z0NBQzFDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxVQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztvQ0FDL0QsTUFBTSxjQUFjLEdBQUcsSUFBQSwwQkFBZSxFQUNwQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQ25DLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUN6QixDQUFDO29DQUVGLElBQUksY0FBYyxHQUFHLENBQUMsRUFBRSxDQUFDO3dDQUN2QixNQUFNLEdBQUcsR0FBRyxNQUFNLElBQUEsa0RBQThCLEVBQUM7NENBQy9DLFNBQVM7NENBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFOzRDQUNuQixTQUFTLEVBQUUsTUFBTTs0Q0FDakIsTUFBTSxFQUFFLGNBQWM7eUNBQ3ZCLENBQUMsQ0FBQzt3Q0FDSCxJQUFJLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQzs0Q0FDakIsYUFBYSxFQUFFLENBQUM7NENBQ2hCLE1BQU0sQ0FBQyxJQUFJLENBQ1QsdUVBQXVFLE1BQU0sQ0FBQyxhQUFhLElBQUksTUFBTSxDQUFDLEVBQUUsVUFBVSxNQUFNLGFBQWEsY0FBYyxHQUFHLENBQ3ZKLENBQUM7d0NBQ0osQ0FBQztvQ0FDSCxDQUFDO2dDQUNILENBQUM7NEJBQ0gsQ0FBQzt3QkFDSCxDQUFDO3dCQUFDLE9BQU8sU0FBYyxFQUFFLENBQUM7NEJBQ3hCLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxnREFBZ0QsTUFBTSxDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzt3QkFDcEcsQ0FBQztvQkFDSCxDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUFDLE9BQU8sYUFBa0IsRUFBRSxDQUFDO1lBQzVCLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyw0Q0FBNEMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDdEYsQ0FBQztRQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsK0NBQStDLGFBQWEsY0FBYyxDQUFDLENBQUM7SUFDMUYsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsTUFBTSxDQUFDLEtBQUssQ0FBQyx5Q0FBeUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDekUsQ0FBQztBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBRztJQUNwQixJQUFJLEVBQUUsNEJBQTRCO0lBQ2xDLHdCQUF3QjtJQUN4QixRQUFRLEVBQUUsY0FBYztDQUN6QixDQUFDIn0=