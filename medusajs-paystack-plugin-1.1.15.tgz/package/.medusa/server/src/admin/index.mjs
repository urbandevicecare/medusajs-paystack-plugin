import { jsxs, jsx } from "react/jsx-runtime";
import { defineWidgetConfig, defineRouteConfig } from "@medusajs/admin-sdk";
import { Container, Heading, Text, Label, Input, Button, Tabs, Select, toast, Table, Badge } from "@medusajs/ui";
import * as React from "react";
import { useState, useEffect, useRef } from "react";
import Medusa from "@medusajs/js-sdk";
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Bar } from "recharts";
import "@medusajs/admin-shared";
const sdk$2 = new Medusa({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const OrderPaystackWidget = ({ data }) => {
  const initialPhone = data?.shipping_address?.phone || data?.billing_address?.phone || data?.customer?.phone || "";
  const [phone, setPhone] = useState(initialPhone);
  const [amount, setAmount] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [balanceInfo, setBalanceInfo] = useState(null);
  const currencyCode = data?.currency_code?.toUpperCase() || "KES";
  useEffect(() => {
    sdk$2.client.fetch(`/admin/paystack/balance`, { method: "GET" }).then((res) => {
      if (res?.data?.balance && res.data.balance.length > 0) {
        const matched = res.data.balance.find(
          (b) => (b.currency || "").toUpperCase() === currencyCode
        ) || res.data.balance[0];
        if (matched) {
          setBalanceInfo(`${matched.currency} ${matched.formatted || (Number(matched.balance) / 100).toFixed(2)}`);
        }
      }
    }).catch(() => {
    });
  }, [currencyCode]);
  const handleStkPush = async () => {
    if (!phone) return;
    setIsLoading(true);
    setFeedback(null);
    try {
      const payload = {
        order_id: data.id,
        phone
      };
      if (amount && Number(amount) > 0) {
        payload.amount = Number(amount);
      }
      const res = await sdk$2.client.fetch(`/admin/paystack/stk-push`, {
        method: "POST",
        body: payload
      });
      const displayMsg = res?.message || `STK push initiated to ${phone}`;
      setFeedback({ type: "success", message: displayMsg });
    } catch (e) {
      console.error("STK Push error:", e);
      const errorMsg = e?.data?.message || e?.response?.data?.message || e?.data?.data?.message || e?.message || "Failed to initiate STK Push";
      setFeedback({ type: "error", message: errorMsg });
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Paystack - STK Push" }),
        /* @__PURE__ */ jsxs(Text, { as: "span", size: "small", className: "text-ui-fg-subtle block", children: [
          "Prompt customer for payment via M-Pesa / Mobile Money (",
          currencyCode,
          ")."
        ] })
      ] }),
      balanceInfo && /* @__PURE__ */ jsxs("div", { className: "text-right hidden sm:block", children: [
        /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle block", children: "Paystack Live Balance" }),
        /* @__PURE__ */ jsx(Text, { size: "small", className: "font-semibold text-ui-fg-base", children: balanceInfo })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-4 px-6 py-4", children: [
      feedback && /* @__PURE__ */ jsx(
        "div",
        {
          className: `p-3 rounded-md text-sm ${feedback.type === "success" ? "bg-ui-bg-subtle-pressed text-ui-fg-interactive border border-ui-border-interactive" : "bg-ui-bg-error-subtle text-ui-fg-error border border-ui-border-error"}`,
          children: feedback.message
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { size: "xsmall", className: "text-ui-fg-subtle mb-1 block", children: "Phone Number" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              placeholder: "e.g. 0712345678 or +254...",
              value: phone,
              onChange: (e) => setPhone(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs(Label, { size: "xsmall", className: "text-ui-fg-subtle mb-1 block", children: [
            "Amount (",
            currencyCode,
            ", leave blank for full)"
          ] }),
          /* @__PURE__ */ jsx(
            Input,
            {
              type: "number",
              placeholder: `Order Total: ${data?.total || 0}`,
              value: amount,
              onChange: (e) => setAmount(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(
        Button,
        {
          variant: "primary",
          size: "small",
          onClick: handleStkPush,
          isLoading,
          disabled: !phone || isLoading,
          children: "Send STK Push Prompt"
        }
      ) })
    ] })
  ] });
};
defineWidgetConfig({
  zone: ["order.details", "order.details.after"]
});
var __defProp = Object.defineProperty;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __objRest = (source, exclude) => {
  var target = {};
  for (var prop in source)
    if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
      target[prop] = source[prop];
  if (source != null && __getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(source)) {
      if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
        target[prop] = source[prop];
    }
  return target;
};
const CreditCard = React.forwardRef(
  (_a, ref) => {
    var _b = _a, { color = "currentColor" } = _b, props = __objRest(_b, ["color"]);
    return /* @__PURE__ */ React.createElement(
      "svg",
      __spreadValues({
        xmlns: "http://www.w3.org/2000/svg",
        width: 15,
        height: 15,
        viewBox: "0 0 15 15",
        fill: "none",
        ref
      }, props),
      /* @__PURE__ */ React.createElement(
        "g",
        {
          stroke: color,
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: 1.5,
          clipPath: "url(#a)"
        },
        /* @__PURE__ */ React.createElement("path", { d: "M1.056 5.944h12.888M2.833 12.167h9.334c.982 0 1.777-.796 1.777-1.778V4.61c0-.982-.796-1.778-1.777-1.778H2.833c-.981 0-1.777.796-1.777 1.778v5.778c0 .982.796 1.778 1.777 1.778M3.278 9.5h2.666M10.833 9.5h.89" })
      ),
      /* @__PURE__ */ React.createElement("defs", null, /* @__PURE__ */ React.createElement("clipPath", { id: "a" }, /* @__PURE__ */ React.createElement("path", { fill: "#fff", d: "M0 0h15v15H0z" })))
    );
  }
);
CreditCard.displayName = "CreditCard";
const sdk$1 = new Medusa({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const PaystackBalanceWidget = () => {
  const [balance, setBalance] = useState(null);
  const [balanceError, setBalanceError] = useState(null);
  const [loading, setLoading] = useState(true);
  const fetchBalance = async () => {
    setLoading(true);
    try {
      const res = await sdk$1.client.fetch(`/admin/paystack/balance`, { method: "GET" });
      if (res?.data?.balance) {
        setBalance(res.data.balance);
        setBalanceError(null);
      } else if (res?.data?.balanceError) {
        setBalanceError(res.data.balanceError);
      }
    } catch (e) {
      setBalanceError(e?.message || "Failed to load Paystack balance");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchBalance();
  }, []);
  return /* @__PURE__ */ jsx(Container, { className: "p-4 mb-4 border border-ui-border-base rounded-lg bg-ui-bg-subtle", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-3", children: [
      /* @__PURE__ */ jsx("div", { className: "p-2 rounded-md bg-ui-bg-base border border-ui-border-base text-ui-fg-interactive", children: /* @__PURE__ */ jsx(CreditCard, {}) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle uppercase tracking-wider font-medium", children: "Live Paystack Balance" }),
        loading ? /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted", children: "Fetching balance..." }) : balance && balance.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-baseline gap-2", children: [
          /* @__PURE__ */ jsxs(Heading, { level: "h3", className: "text-ui-fg-base", children: [
            balance[0].currency,
            " ",
            balance[0].formatted || (Number(balance[0].balance) / 100).toFixed(2)
          ] }),
          balance.length > 1 && /* @__PURE__ */ jsx("div", { className: "flex gap-1.5", children: balance.slice(1).map((b) => /* @__PURE__ */ jsxs(
            "span",
            {
              className: "text-xs px-1.5 py-0.5 rounded bg-ui-bg-base border text-ui-fg-subtle",
              children: [
                b.currency,
                ": ",
                b.formatted || (Number(b.balance) / 100).toFixed(2)
              ]
            },
            b.currency
          )) })
        ] }) : balanceError ? /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: balanceError }) : /* @__PURE__ */ jsx(Heading, { level: "h3", className: "text-ui-fg-muted", children: "0.00" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(
      Button,
      {
        variant: "transparent",
        size: "small",
        onClick: fetchBalance,
        isLoading: loading,
        className: "text-ui-fg-muted hover:text-ui-fg-base text-xs",
        children: "Refresh"
      }
    )
  ] }) });
};
defineWidgetConfig({
  zone: ["order.list", "order.list.before"]
});
const sdk = new Medusa({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const PaystackDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [graphView, setGraphView] = useState("monthlyGraph");
  const [activeTab, setActiveTab] = useState("analytics");
  const [refreshingBalance, setRefreshingBalance] = useState(false);
  const [refreshingTransactions, setRefreshingTransactions] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("success");
  const [visibleCount, setVisibleCount] = useState(20);
  const loadMoreRef = useRef(null);
  const [settings, setSettings] = useState({ companyName: "", storefrontUrl: "", secretKey: "" });
  const [saving, setSaving] = useState(false);
  const [loadingSettings, setLoadingSettings] = useState(true);
  const MAX_ROWS = 100;
  const allTransactions = data?.transactions || data?.payments || [];
  const filteredTransactions = allTransactions.filter((tx) => {
    if (statusFilter !== "all" && (tx.status || "").toLowerCase() !== statusFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const ref = (tx.reference || tx.id || "").toLowerCase();
    const email = (tx.customer?.email || "").toLowerCase();
    const phone = (tx.customer?.phone || "").toLowerCase();
    const orderDisplay = String(tx.order?.display_id ?? tx.payment_collection?.order?.display_id ?? "").toLowerCase();
    const repairTicket = String(tx.repair?.ticket_number || tx.repair?.id || "").toLowerCase();
    return ref.includes(q) || email.includes(q) || phone.includes(q) || orderDisplay.includes(q) || repairTicket.includes(q);
  });
  const cappedTransactions = filteredTransactions.slice(0, MAX_ROWS);
  const visibleTransactions = cappedTransactions.slice(0, visibleCount);
  useEffect(() => {
    setVisibleCount(20);
  }, [searchQuery, statusFilter, data]);
  useEffect(() => {
    if (!loadMoreRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleCount((prev) => {
            if (prev < cappedTransactions.length) {
              return Math.min(prev + 20, cappedTransactions.length);
            }
            return prev;
          });
        }
      },
      { rootMargin: "120px" }
    );
    observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [cappedTransactions.length]);
  const loadDashboardData = async () => {
    try {
      const res = await sdk.client.fetch(`/admin/paystack/dashboard`, { method: "GET" });
      if (res?.data) {
        setData(res.data);
      }
    } catch (e) {
      console.error("Failed to load dashboard data", e);
    } finally {
      setLoading(false);
    }
  };
  const handleRefreshBalance = async () => {
    setRefreshingBalance(true);
    try {
      const res = await sdk.client.fetch(`/admin/paystack/balance`, { method: "GET" });
      if (res?.data) {
        setData((prev) => ({
          ...prev,
          balance: res.data.balance,
          balanceError: res.data.balanceError
        }));
        if (res.data.balanceError) {
          toast.error(res.data.balanceError);
        } else {
          toast.success("Paystack balance updated");
        }
      }
    } catch (err) {
      toast.error(err?.message || "Failed to refresh balance");
      await loadDashboardData();
    } finally {
      setRefreshingBalance(false);
    }
  };
  data?.transactions || data?.payments || [];
  useEffect(() => {
    loadDashboardData();
    sdk.client.fetch(`/admin/paystack/settings`, { method: "GET" }).then((res) => {
      if (res.data) {
        setSettings(res.data);
      }
    }).catch((e) => console.error("Failed to load settings", e)).finally(() => setLoadingSettings(false));
  }, []);
  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      await sdk.client.fetch(`/admin/paystack/settings`, {
        method: "POST",
        body: settings
      });
      toast.success("Settings saved successfully");
      loadDashboardData();
    } catch (e) {
      toast.error("Failed to save settings");
      console.error(e);
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-4", children: /* @__PURE__ */ jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, children: [
    /* @__PURE__ */ jsxs(Tabs.List, { className: "mb-4", children: [
      /* @__PURE__ */ jsx(Tabs.Trigger, { value: "analytics", children: "Analytics" }),
      /* @__PURE__ */ jsx(Tabs.Trigger, { value: "settings", children: "Settings" })
    ] }),
    /* @__PURE__ */ jsxs(Tabs.Content, { value: "analytics", className: "flex flex-col gap-y-4", children: [
      /* @__PURE__ */ jsxs(Container, { className: "p-6 flex flex-col gap-y-4", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h1", children: "Paystack Dashboard" }),
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "View your Paystack transaction analytics and manage your payment settings here." }),
        loading ? /* @__PURE__ */ jsx(Text, { size: "small", children: "Loading dashboard data..." }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-8 mt-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-4 border rounded-lg flex-1", children: [
              /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Total Paystack Revenue" }),
              /* @__PURE__ */ jsx(Heading, { level: "h2", children: data?.totalRevenue != null ? Number(data.totalRevenue).toFixed(2) : "0.00" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-4 border rounded-lg flex-1 flex flex-col justify-between", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Live Paystack Balance" }),
                /* @__PURE__ */ jsx(
                  Button,
                  {
                    variant: "transparent",
                    size: "small",
                    onClick: handleRefreshBalance,
                    isLoading: refreshingBalance,
                    className: "text-ui-fg-muted hover:text-ui-fg-base h-6 px-2 text-xs",
                    children: "Refresh"
                  }
                )
              ] }),
              data?.balance && data.balance.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-baseline gap-3 mt-1", children: [
                /* @__PURE__ */ jsxs(Heading, { level: "h2", children: [
                  data.balance[0].currency,
                  " ",
                  data.balance[0].formatted || (Number(data.balance[0].balance) / 100).toFixed(2)
                ] }),
                data.balance.length > 1 && /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: data.balance.slice(1).map((b) => /* @__PURE__ */ jsxs(
                  "span",
                  {
                    className: "inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-ui-bg-subtle text-ui-fg-subtle border border-ui-border-base",
                    children: [
                      b.currency,
                      ": ",
                      b.formatted || (Number(b.balance) / 100).toFixed(2)
                    ]
                  },
                  b.currency
                )) })
              ] }) : data?.balanceError ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1 mt-1", children: [
                /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: data.balanceError }),
                /* @__PURE__ */ jsx(
                  Button,
                  {
                    variant: "secondary",
                    size: "small",
                    className: "w-fit text-xs mt-1",
                    onClick: () => setActiveTab("settings"),
                    children: "Configure in Settings"
                  }
                )
              ] }) : /* @__PURE__ */ jsx(Heading, { level: "h2", className: "text-ui-fg-muted mt-1", children: "0.00" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Revenue Chart" }),
              /* @__PURE__ */ jsx("div", { className: "w-[150px]", children: /* @__PURE__ */ jsxs(Select, { value: graphView, onValueChange: (v) => setGraphView(v), children: [
                /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                /* @__PURE__ */ jsxs(Select.Content, { children: [
                  /* @__PURE__ */ jsx(Select.Item, { value: "dailyGraph", children: "Daily" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "weeklyGraph", children: "Weekly" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "monthlyGraph", children: "Monthly" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "yearlyGraph", children: "Yearly" })
                ] })
              ] }) })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "w-full h-[300px]", children: data?.[graphView] && data[graphView].length > 0 ? /* @__PURE__ */ jsx(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxs(BarChart, { data: data[graphView], children: [
              /* @__PURE__ */ jsx(CartesianGrid, { strokeDasharray: "3 3", vertical: false, stroke: "#E5E7EB" }),
              /* @__PURE__ */ jsx(XAxis, { dataKey: "name", axisLine: false, tickLine: false, tick: { fontSize: 12, fill: "#6B7280" }, dy: 10 }),
              /* @__PURE__ */ jsx(YAxis, { axisLine: false, tickLine: false, tick: { fontSize: 12, fill: "#6B7280" }, dx: -10 }),
              /* @__PURE__ */ jsx(Tooltip, { cursor: { fill: "#F3F4F6" }, contentStyle: { borderRadius: "8px", border: "1px solid #E5E7EB", boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)" } }),
              /* @__PURE__ */ jsx(Bar, { dataKey: "total", fill: "#3B82F6", radius: [4, 4, 0, 0] })
            ] }) }) : /* @__PURE__ */ jsx("div", { className: "w-full h-full flex items-center justify-center bg-gray-50 rounded-lg", children: /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-muted", children: "No data available for this view." }) }) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Container, { className: "p-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-6 border-b border-ui-border-base flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Recent Transactions" }),
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mt-0.5", children: "Live payments processed via Paystack (synced with Medusa orders & Mobile Money)." })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx(
            Button,
            {
              variant: "secondary",
              size: "small",
              onClick: async () => {
                setRefreshingTransactions(true);
                await loadDashboardData();
                setRefreshingTransactions(false);
                toast.success("Transactions refreshed");
              },
              isLoading: refreshingTransactions,
              children: "Refresh Transactions"
            }
          ) })
        ] }),
        data?.transactionsError && /* @__PURE__ */ jsxs("div", { className: "p-4 m-6 rounded-md bg-ui-bg-error-subtle border border-ui-border-error flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-error", children: [
            "Paystack Notice: ",
            data.transactionsError
          ] }),
          /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: () => setActiveTab("settings"), children: "Check Settings" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "px-6 py-3 border-b border-ui-border-base bg-ui-bg-subtle flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "flex-1 max-w-sm", children: /* @__PURE__ */ jsx(
            Input,
            {
              placeholder: "Search reference, email, phone, or order #",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              size: "small"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle whitespace-nowrap", children: "Filter Status:" }),
            /* @__PURE__ */ jsx("div", { className: "w-[130px]", children: /* @__PURE__ */ jsxs(Select, { value: statusFilter, onValueChange: (val) => setStatusFilter(val), children: [
              /* @__PURE__ */ jsx(Select.Trigger, { size: "small", children: /* @__PURE__ */ jsx(Select.Value, {}) }),
              /* @__PURE__ */ jsxs(Select.Content, { children: [
                /* @__PURE__ */ jsx(Select.Item, { value: "all", children: "All Statuses" }),
                /* @__PURE__ */ jsx(Select.Item, { value: "success", children: "Success" }),
                /* @__PURE__ */ jsx(Select.Item, { value: "failed", children: "Failed" }),
                /* @__PURE__ */ jsx(Select.Item, { value: "abandoned", children: "Abandoned" })
              ] })
            ] }) })
          ] })
        ] }),
        !loading && filteredTransactions.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "p-8 text-center flex flex-col items-center", children: [
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted italic", children: searchQuery || statusFilter !== "all" ? `No ${statusFilter !== "all" ? statusFilter : ""} transactions match your search or filter criteria.` : "No transactions found on this Paystack account." }),
          statusFilter !== "all" && /* @__PURE__ */ jsx(
            Button,
            {
              variant: "secondary",
              size: "small",
              className: "mt-3",
              onClick: () => setStatusFilter("all"),
              children: "View All Statuses"
            }
          )
        ] }) : /* @__PURE__ */ jsxs("div", { className: "overflow-x-auto", children: [
          /* @__PURE__ */ jsxs(Table, { children: [
            /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
              /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Reference" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Order / Repair" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Customer" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Channel" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Status" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Amount" }),
              /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Date" })
            ] }) }),
            /* @__PURE__ */ jsx(Table.Body, { children: visibleTransactions.map((tx) => {
              const orderDisplayId = tx.order?.display_id ?? tx.payment_collection?.order?.display_id;
              const orderId = tx.order?.id ?? tx.payment_collection?.order?.id;
              const repairTicketNumber = tx.repair?.ticket_number;
              const repairId = tx.repair?.id;
              return /* @__PURE__ */ jsxs(Table.Row, { children: [
                /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(Text, { size: "small", className: "font-mono text-ui-fg-base font-medium", children: tx.reference || tx.id }) }),
                /* @__PURE__ */ jsx(Table.Cell, { children: repairTicketNumber ? /* @__PURE__ */ jsx(
                  "a",
                  {
                    href: `/repairs/${repairId || ""}`,
                    className: "inline-flex items-center gap-1 font-medium text-sm text-ui-fg-interactive hover:underline",
                    children: /* @__PURE__ */ jsxs(Badge, { color: "blue", size: "small", children: [
                      "Repair #",
                      repairTicketNumber
                    ] })
                  }
                ) : orderDisplayId != null ? /* @__PURE__ */ jsx(
                  "a",
                  {
                    href: `/orders/${orderId || ""}`,
                    className: "inline-flex items-center gap-1 font-medium text-sm text-ui-fg-interactive hover:underline",
                    children: /* @__PURE__ */ jsxs(Badge, { color: "grey", size: "small", children: [
                      "#",
                      orderDisplayId
                    ] })
                  }
                ) : /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle italic", children: "Direct / Standalone" }) }),
                /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-base font-medium truncate max-w-[180px]", children: tx.customer?.email || tx.customer?.name || "—" }),
                  tx.customer?.phone && /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle", children: tx.customer.phone })
                ] }) }),
                /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx("span", { className: "text-xs font-medium text-ui-fg-subtle capitalize", children: tx.channel === "mobile_money" ? "M-Pesa / Mobile Money" : tx.channel === "card" ? "Card" : tx.channel === "bank_transfer" ? "Bank Transfer" : tx.channel || "Paystack" }) }),
                /* @__PURE__ */ jsx(Table.Cell, { children: tx.status === "success" ? /* @__PURE__ */ jsx(Badge, { color: "green", size: "small", children: "Success" }) : tx.status === "failed" ? /* @__PURE__ */ jsx(Badge, { color: "red", size: "small", children: "Failed" }) : /* @__PURE__ */ jsx(Badge, { color: "grey", size: "small", children: tx.status || "Pending" }) }),
                /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: /* @__PURE__ */ jsxs(Text, { size: "small", className: "font-semibold text-ui-fg-base", children: [
                  tx.currency_code?.toUpperCase(),
                  " ",
                  Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                ] }) }),
                /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle whitespace-nowrap", children: tx.created_at ? new Date(tx.created_at).toLocaleString() : "—" }) })
              ] }, tx.id || tx.reference);
            }) })
          ] }),
          visibleCount < cappedTransactions.length ? /* @__PURE__ */ jsx("div", { ref: loadMoreRef, className: "py-4 text-center border-t border-ui-border-base bg-ui-bg-subtle/40", children: /* @__PURE__ */ jsxs(Text, { size: "xsmall", className: "text-ui-fg-muted animate-pulse font-medium", children: [
            "Loading more transactions (",
            visibleTransactions.length,
            " of ",
            cappedTransactions.length,
            ")..."
          ] }) }) : cappedTransactions.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "py-3 px-6 bg-ui-bg-subtle border-t border-ui-border-base flex items-center justify-between text-ui-fg-subtle", children: [
            /* @__PURE__ */ jsxs(Text, { size: "xsmall", children: [
              "Showing all ",
              cappedTransactions.length,
              " transaction",
              cappedTransactions.length === 1 ? "" : "s",
              filteredTransactions.length > MAX_ROWS ? ` (capped at top ${MAX_ROWS})` : ""
            ] }),
            filteredTransactions.length > MAX_ROWS && /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "italic text-ui-fg-muted", children: "Capped at top 100 recent transactions" })
          ] }) : null
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Tabs.Content, { value: "settings", children: /* @__PURE__ */ jsxs(Container, { className: "p-6 flex flex-col gap-y-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Heading, { level: "h1", children: "Plugin Settings" }),
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mt-1", children: "Configure your company details and storefront URLs for payment link generation. If left blank, these will default to your .env variables (STORE_NAME and STOREFRONT_URL)." })
      ] }),
      loadingSettings ? /* @__PURE__ */ jsx(Text, { size: "small", children: "Loading settings..." }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-4 max-w-[600px]", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "companyName", children: "Company Name" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "companyName",
              placeholder: "e.g. Urban Device Care",
              value: settings.companyName || "",
              onChange: (e) => setSettings({ ...settings, companyName: e.target.value })
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted", children: "This name appears in email and SMS payment notifications." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "storefrontUrl", children: "Storefront URL" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "storefrontUrl",
              placeholder: "e.g. https://my-store.com",
              value: settings.storefrontUrl || "",
              onChange: (e) => setSettings({ ...settings, storefrontUrl: e.target.value })
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted", children: "The base URL where the payment link points (e.g., https://my-store.com)." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 mt-4 pt-4 border-t border-ui-border-base", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "secretKey", children: "Paystack Secret Key" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "secretKey",
              type: "password",
              placeholder: "sk_test_...",
              value: settings.secretKey || "",
              onChange: (e) => setSettings({ ...settings, secretKey: e.target.value })
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted", children: "Overrides the PAYSTACK_SECRET_KEY in your .env file. Useful for rotating keys without restarting the server. Leave blank to use .env value." })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end mt-4", children: /* @__PURE__ */ jsx(Button, { variant: "primary", onClick: handleSaveSettings, isLoading: saving, children: "Save Settings" }) })
      ] })
    ] }) })
  ] }) });
};
const config = defineRouteConfig({
  label: "Paystack",
  icon: CreditCard
});
const widgetModule = { widgets: [
  {
    Component: OrderPaystackWidget,
    zone: ["order.details", "order.details.after"],
    widgetId: "Widget-f5d3"
  },
  {
    Component: PaystackBalanceWidget,
    zone: ["order.list", "order.list.before"],
    widgetId: "Widget-2526"
  }
] };
const routeModule = {
  routes: [
    {
      Component: PaystackDashboard,
      path: "/paystack",
      handle: { label: config.label, translationNs: config.translationNs }
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config.label,
      icon: config.icon,
      path: "/paystack",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: {} };
const cellRendererModule = {};
const layoutModule = { layouts: [] };
const searchEntityModule = {};
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule,
  cellRendererModule,
  layoutModule,
  searchEntityModule
};
export {
  plugin as default
};
